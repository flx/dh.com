# flywheelcad-format: 1
# FlywheelCAD showcase 2 of 5 — Body creation: extrude + revolve in one part
# ============================================================================
# One coherent object — a machine hand-knob — built from BOTH body operations:
#
#   * a REVOLVE makes the dished, flared body (a profile spun about the axis)
#   * an EXTRUDE raises a central boss, another cuts the shaft bore
#   * a ring of extruded cylinders is UNIONED then DIFFERENCED to scallop the
#     rim into finger grips
#
# Along the way it shows the handy body options: `edge_radius` (rounds the
# edges of a body), `offset` (shifts an extrude along the plane normal so a cut
# can start below the face), and boolean union / difference.
# ============================================================================

from flywheelcad import *

cad = FlywheelCAD()

R      = 22.0    # knob radius (mm)
H      = 16.0    # knob height (mm)
BORE_D = 8.0     # shaft-bore diameter (mm)
GRIPS  = 10      # number of finger scallops around the rim

import math

# ---- 1. Body: a revolve -----------------------------------------------------
# The profile is drawn on the ZX plane as (radius, height): sketch-right is
# radius out from the axis, sketch-up is world +Z. The closing edge runs down
# the axis at radius 0, and that same edge is the revolve axis.
cad.with_sketch("zx")
p0 = cad.point2d(0.0, 0.0)        # axis, base
p1 = cad.point2d(R, 0.0)          # rim, base
p2 = cad.point2d(R, 5.0)          # up the flared rim
p3 = cad.point2d(R - 4.0, 9.0)    # shoulder, tapering in
p4 = cad.point2d(R - 8.0, H)      # top lip
p5 = cad.point2d(7.0, H - 5.0)    # dished centre (below the lip → concave top)
p6 = cad.point2d(0.0, H - 5.0)    # axis, dish bottom

edges = [
    cad.line2d(p0, p1), cad.line2d(p1, p2), cad.line2d(p2, p3),
    cad.line2d(p3, p4), cad.line2d(p4, p5), cad.line2d(p5, p6),
]
axis = cad.line2d(p6, p0)         # closing edge, down the axis (radius 0)

body = cad.revolve(
    "zx",
    cad.region(loop=edges + [axis], inside=(R / 2.0, 2.0)),
    axis_line=axis, angle=360.0,
    edge_radius=1.5,              # round the revolved edges (rim + shoulder)
    export=False,
)

# ---- 2. A raised central boss: an extrude, unioned on -----------------------
cad.with_sketch("xy")
boss_c = cad.circle2d(cad.point2d(0.0, 0.0), 9.0)
boss = cad.extrude(
    "xy", cad.region(loop=[boss_c], inside=(0.0, 0.0)),
    H - 2.0,
    edge_radius=1.0,             # softened top edge on the boss
    export=False,
)
knob = cad.bool_union(body, boss, export=False)

# ---- 3. Finger scallops: a ring of cylinders, unioned then subtracted -------
# Each grip is a full-height cylinder sitting on the rim; `offset=-3` starts it
# below the base so the cut breaks cleanly through top and bottom.
cutters = []
for k in range(GRIPS):
    a = 2.0 * math.pi * k / GRIPS
    cx, cy = R * math.cos(a), R * math.sin(a)
    cad.with_sketch("xy")
    scallop = cad.circle2d(cad.point2d(cx, cy), 5.0)
    cutters.append(cad.extrude(
        "xy", cad.region(loop=[scallop], inside=(cx, cy)),
        H + 6.0, offset=-3.0, export=False,
    ))
grip_tool = cad.bool_union(*cutters, export=False)
knob = cad.bool_difference(knob, grip_tool, export=False)

# ---- 4. Shaft bore: an extruded cylinder, differenced out -------------------
# `offset=-1` drops the bore 1 mm below the base so it is a clean through/blind
# cut rather than a coincident face. It stops short of the dished top.
cad.with_sketch("xy")
bore_c = cad.circle2d(cad.point2d(0.0, 0.0), BORE_D / 2.0)
bore = cad.extrude(
    "xy", cad.region(loop=[bore_c], inside=(0.0, 0.0)),
    H - 3.0, offset=-1.0, export=False,
)
knob = cad.bool_difference(knob, bore)

cad.set_color(knob, "#455A64", finish="glossy")
