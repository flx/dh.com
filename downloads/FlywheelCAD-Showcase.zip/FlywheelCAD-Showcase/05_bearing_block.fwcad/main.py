# flywheelcad-format: 1
# FlywheelCAD showcase 5 of 5 — Library insertion + mating
# ============================================================================
# A pillow-style bearing block: a machined block with a 608 ball bearing
# pressed into its bore and four cap screws holding it down. The parts that
# matter here are CATALOG PARTS pulled straight from the standard library:
#
#   * `from lib.standard.bearings import bearing`
#   * `from lib.standard.fasteners import cap_screw`
#
# The library modules are VENDORED into this folder's lib/standard/ (copy-on-
# use), so the sample is self-contained. Each catalog part is a component with
# named anchors; we place the screws by MATING their `under_head` anchor onto
# anchors the block component exports — change the block and the screws follow.
#
# This is the same workflow the app's "Insert Component from Library…" button
# performs; here it is spelled out in script form.
# ============================================================================

from flywheelcad import *

cad = FlywheelCAD()

from lib.standard.bearings import bearing
from lib.standard.fasteners import cap_screw

BLOCK = 54.0     # block is BLOCK x BLOCK in plan
THICK = 10.0     # block thickness
SEAT_D = 22.0    # 608 outer diameter — a press-fit seat bore
SCREW_XY = 20.0  # corner screws at (+-20, +-20)
CORNERS = [(SCREW_XY, SCREW_XY), (-SCREW_XY, SCREW_XY),
           (-SCREW_XY, -SCREW_XY), (SCREW_XY, -SCREW_XY)]

# ---- The block: a fixed component that exports its mounting anchors ---------
with cad.component("block", label="Bearing block 54mm"):
    cad.with_sketch("xy")
    h = BLOCK / 2.0
    a = cad.point2d(-h, -h)
    b = cad.point2d(h, -h)
    c = cad.point2d(h, h)
    d = cad.point2d(-h, h)
    outline = [cad.line2d(a, b), cad.line2d(b, c), cad.line2d(c, d), cad.line2d(d, a)]
    seat = cad.circle2d(cad.point2d(0.0, 0.0), SEAT_D / 2.0)        # bearing bore
    screw_holes = [cad.circle2d(cad.point2d(cx, cy), 1.7) for (cx, cy) in CORNERS]  # M3 clearance
    body = cad.extrude(
        "xy",
        cad.region(loop=outline,
                   holes=[[seat]] + [[c] for c in screw_holes],
                   inside=(h - 4.0, h - 4.0)),
        THICK,
    )
    cad.set_color(body, "#607D8B", finish="metallic")
    cad.component_export(body)
    # Anchors on the TOP face: one per corner screw, plus the bore centre.
    for i, (cx, cy) in enumerate(CORNERS):
        cad.component_export_point(f"hole_{i}", cad.point(cx, cy, THICK))
    cad.component_export_point("bore", cad.point(0.0, 0.0, 0.0))

block = cad.instance("block")

# ---- Press a 608 bearing into the bore -------------------------------------
# The bearing's axis is +Z with face_a at z=0; seat it 1.5 mm proud of the top.
brg = cad.instance(bearing(cad, designation="608"), translate=(0.0, 0.0, 1.5))

# ---- Four M3 cap screws, mated onto the block's corner anchors -------------
# One factory call → one reusable component; four instances mated to anchors.
m3 = cap_screw(cad, thread="M3", length=10.0)
for i in range(4):
    s = cad.instance(m3)
    cad.mate_coincident(s, "under_head", getattr(block, f"hole_{i}"))
