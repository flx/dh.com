# flywheelcad-format: 1
# FlywheelCAD showcase 1 of 5 — Sketching, constraints & dimensions
# ============================================================================
# The teaching point of this sample is the 2D CONSTRAINT SOLVER, not the body.
#
# We draw a flat mounting bracket as a rough sketch, then pin its shape with
# geometric constraints (horizontal / vertical / parallel / perpendicular) and
# dimensions that are BOUND TO SHARED VARIABLES. Because the dimensions read
# their values from `cad.variable`s, the whole part is parametric: open the
# Variables panel, change WIDTH (or HEIGHT, HOLE_DIA, SLANT), and the sketch
# re-solves — every dependent point, the fillet, and the hole follow.
#
# A light extrude at the end just lets the profile read in 3D.
# ============================================================================

from flywheelcad import *

cad = FlywheelCAD()

# ---- Driving variables ------------------------------------------------------
# `driving=True` variables are held at their value during a solve (so they
# drive the geometry) but stay editable in the Variables panel. Edit one and
# the constraints re-solve the sketch around the new value.
WIDTH    = cad.variable(80.0, driving=True)   # overall bracket width  (mm)
HEIGHT   = cad.variable(50.0, driving=True)   # overall bracket height (mm)
SLANT    = cad.variable(105.0, driving=True)  # angle of the right edge (deg)
HOLE_DIA = cad.variable(9.0, driving=True)    # mounting-hole diameter (mm)
FILLET_R = 8.0                                # top-left corner radius (mm)

cad.with_sketch("xy")

# ---- Rough outline ----------------------------------------------------------
# A trapezoid: level bottom + top, vertical left edge, and a right edge that
# leans in. Coordinates here are only a STARTING GUESS — the solver moves the
# points to satisfy the constraints and dimensions below.
A = cad.point2d(0.0, 0.0)     # bottom-left  (origin corner)
B = cad.point2d(80.0, 0.0)    # bottom-right
C = cad.point2d(68.0, 50.0)   # top-right (pulled in by the slant)
D = cad.point2d(0.0, 50.0)    # top-left  (this corner gets filleted)

l_bottom = cad.line2d(A, B)   # consecutive lines SHARE a point ref, so their
l_right  = cad.line2d(B, C)   # touching ends are coincident by construction —
l_top    = cad.line2d(C, D)   # no explicit coincidence constraint needed.
l_left   = cad.line2d(D, A)

# ---- Geometric constraints --------------------------------------------------
# Each line's orientation is fixed exactly once, so nothing fights:
cad.horizontal(l_bottom)              # bottom edge is level …
cad.parallel(l_top, l_bottom)         # … and the top edge is parallel to it
cad.vertical(l_left)                  # left edge is plumb …
cad.perpendicular(l_left, l_bottom)   # … and square to the bottom
# (the right edge is left free here — its lean is set by the ANGLE dimension)

# ---- Dimensional constraints, bound to the shared variables -----------------
# Point-to-point DISTANCE dims set the overall size (they stay exact even after
# the top-left corner is filleted, because A/B/D are un-filleted corners):
cad.distance(A, B, WIDTH)             # bottom edge length  = WIDTH
cad.distance(A, D, HEIGHT)            # left edge length    = HEIGHT
# ANGLE dim leans the right edge relative to the bottom:
cad.angle(l_bottom, l_right, SLANT)

# ---- Mounting hole: a circle with a RADIUS dim + point/line DISTANCE dims ----
hc  = cad.point2d(40.0, 25.0)
hole = cad.circle2d(hc, 4.5)
cad.radius(hole, HOLE_DIA / 2.0)                 # radius dim = HOLE_DIA / 2
cad.point_line_distance(hc, l_bottom, HEIGHT / 2.0)  # centered top-to-bottom
cad.point_line_distance(hc, l_left, WIDTH * 0.35)    # 35% in from the left edge

# ---- Fillet the top-left corner --------------------------------------------
# `fillet` retracts both lines to their tangent points and drops in a tangent
# arc of the given radius — a TANGENCY constraint the solver maintains as the
# sketch changes. The l_top / l_left variables keep referring to the retracted
# lines, and the returned `corner` arc joins them in the boundary loop below.
corner = cad.fillet(l_top, l_left, FILLET_R)

cad.ensure_convergence()   # solve the sketch now, so a headless render is exact

# ---- Give it thickness ------------------------------------------------------
# The region's directed boundary walks the outline; the fillet arc replaces the
# sharp top-left corner between l_top and l_left. `holes=` cuts the bore.
plate = cad.extrude(
    "xy",
    cad.region(loop=[l_bottom, l_right, l_top, corner, l_left],
               holes=[[hole]],
               inside=(5.0, 5.0)),
    6.0,
    edge_radius=0.6,          # a whisper of an edge break so it reads as a part
)
cad.set_color(plate, "#4FC3F7", finish="metallic")
