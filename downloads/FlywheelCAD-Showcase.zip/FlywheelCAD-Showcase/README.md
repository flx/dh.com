# FlywheelCAD showcase samples

Five short, heavily-commented projects that teach the FlywheelCAD workflow one
concept at a time. Open each in order and read the comments top-to-bottom — they
are meant to be learned from, not just run. Each is self-contained; the library
sample carries its own vendored `lib/standard/`.

| # | Folder | Teaches |
|---|--------|---------|
| 1 | `01_sketch_bracket.fwcad/main.py` | Sketching with **constraints** (horizontal/vertical/parallel/perpendicular, fillet tangency) and **dimensions bound to driving variables** — edit a variable and the part re-solves. |
| 2 | `02_knob.fwcad/main.py` | **Body creation** from both **revolve** and **extrude**, plus **booleans** — with `edge_radius`, `offset`, and union/difference on one hand-knob. |
| 3 | `03_loft_duct.fwcad/main.py` | **Custom sketch planes** and **multi-level loft** — a transition fairing swept through four stations with a reusable `profiles.oval(...)` helper. |
| 4 | `04_standoff_kit.fwcad/main.py` | **Components** — a *fixed* base-plate component and a *parametric* standoff factory, instanced at several sizes and mated onto exported anchors. |
| 5 | `05_bearing_block.fwcad/main.py` | **Library insertion + mating** — catalog parts (`bearing`, `cap_screw`) pulled from the standard library and mated onto a block's anchors. |

## Verifying

Each sample renders headlessly and is covered by `SampleDocumentTests`:

```sh
<FlywheelCAD.app>/Contents/MacOS/FlywheelCAD render 01_sketch_bracket.fwcad/main.py -o /tmp/out.3mf
```

Preview quality can leave coarse-mesh "disconnected components" warnings on the
small holes; they clear at `--quality standard` or higher and do not affect the
exported solid.
