# FlywheelCAD showcase 4 of 5 — Components: fixed + parametric
# ============================================================================
# A little standoff kit: a base plate with four hex standoffs screwed into its
# corners. It contrasts the two ways to define reusable parts:
#
#   * a FIXED component  — `with cad.component("base_plate"):` builds one
#     specific part once and exports its body plus named ANCHOR POINTS.
#   * a PARAMETRIC factory — `standoff(...)` wraps its build in `cad.parametric`
#     so the SAME code makes an M3-12 or an M4-20 just by changing arguments.
#     Call it twice with different sizes and you get two components; call it
#     again with a size you already used and it is reused (memoised), not
#     rebuilt. That is why a parametric factory beats copy-pasting geometry.
#
# Instances are positioned by MATING their `base` anchor onto the plate's
# exported corner anchors, so moving the plate moves the whole stack.
# ============================================================================

from flywheelcad import *

cad = FlywheelCAD()

import math

PLATE_L, PLATE_W, PLATE_T = 60.0, 40.0, 4.0
CORNERS = [(24.0, 14.0), (-24.0, 14.0), (-24.0, -14.0), (24.0, -14.0)]


def _hexagon(af, cx=0.0, cy=0.0):
    """Hex outline (list of lines) from an across-flats width, flats top/bottom."""
    r = (af / 2.0) / math.cos(math.radians(30.0))     # across-corners radius
    pts = [cad.point2d(cx + r * math.cos(math.radians(60 * k + 30)),
                       cy + r * math.sin(math.radians(60 * k + 30))) for k in range(6)]
    return [cad.line2d(pts[i], pts[(i + 1) % 6]) for i in range(6)]


# ---- The PARAMETRIC part ----------------------------------------------------
def standoff(cad, length=12.0, across_flats=5.5, bore=3.2):
    """A hex standoff with a through bore. Anchors: base (z=0), top (z=length).

    Wrapped in cad.parametric so each (length, across_flats, bore) combination
    is built once and reused. Returns the component name for cad.instance(...)."""
    def build():
        cad.with_sketch("xy")
        outline = _hexagon(across_flats)
        hole = cad.circle2d(cad.point2d(0.0, 0.0), bore / 2.0)
        body = cad.extrude(
            "xy",
            cad.region(loop=outline, holes=[[hole]],
                       inside=(0.0, across_flats / 2.0 - 0.3)),
            length,
        )
        cad.set_color(body, "#B0BEC5", finish="metallic")
        cad.export(body)
        cad.export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.export_point("top", cad.point(0.0, 0.0, length))

    return cad.parametric("standoff", build,
                          length=length, af=across_flats, bore=bore,
                          label=f"Hex standoff {across_flats:g}AF x {length:g}")


# ---- The FIXED part ---------------------------------------------------------
# One specific plate. Everything inside the `with` block is scoped to this
# component; the exported anchors become <instance>.mount_k in the assembly.
with cad.component("base_plate", label="Base plate 60x40"):
    cad.with_sketch("xy")
    hx, hy = PLATE_L / 2.0, PLATE_W / 2.0
    a = cad.point2d(-hx, -hy)
    b = cad.point2d(hx, -hy)
    c = cad.point2d(hx, hy)
    d = cad.point2d(-hx, hy)
    outline = [cad.line2d(a, b), cad.line2d(b, c), cad.line2d(c, d), cad.line2d(d, a)]
    holes = [[cad.circle2d(cad.point2d(cx, cy), 1.6)] for (cx, cy) in CORNERS]
    plate = cad.extrude("xy",
                        cad.region(loop=outline, holes=holes, inside=(0.0, 0.0)),
                        PLATE_T)
    cad.set_color(plate, "#37474F", finish="matte")
    cad.export(plate)
    # Anchor at each corner, on the TOP face — a standoff's base mates here.
    for i, (cx, cy) in enumerate(CORNERS):
        cad.export_point(f"mount_{i}", cad.point(cx, cy, PLATE_T))

# ---- Assemble ---------------------------------------------------------------
plate_inst = cad.instance("base_plate")

# Front corners get short M3 standoffs; back corners get taller M4 standoffs.
# Two distinct parametric components, four instances — no copy-pasted geometry.
m3 = standoff(cad, length=12.0, across_flats=5.5, bore=3.2)
m4 = standoff(cad, length=20.0, across_flats=7.0, bore=4.3)
kit = [m3, m3, m4, m4]     # mount_0/1 = front, mount_2/3 = back
for i, part in enumerate(kit):
    post = cad.instance(part)
    cad.set_color(post, "#FFCA28", finish="metallic")
    cad.mate_coincident(post, "base", getattr(plate_inst, f"mount_{i}"))
