"""
empennage.py — a NESTED sub-assembly: the tail surfaces.

Three instances of one stabilizer component: a right and left horizontal
stabilizer (one mirrored) and a vertical fin (the same stabilizer rotated 90°
about the fore-aft axis). All three are re-exported, so the airplane sees the
empennage as a body-group of three parts plus a `mount` anchor.
"""

from flywheelcad import *
cad = FlyWheelCAD()

from stabilizer import stabilizer

_STAB = stabilizer(span=14, chord=9)   # define the stabilizer component

with cad.component("empennage"):
    h_right = cad.instance(_STAB)                          # horizontal, +y
    h_left = cad.instance(_STAB, mirror="zx")             # horizontal, -y (mirrored)
    fin = cad.instance(_STAB, axis=(1, 0, 0), angle=90)   # rotated up → vertical fin
    cad.export(h_right)
    cad.export(h_left)
    cad.export(fin)
    cad.export_point("mount", cad.point(0, 0, 0))
