"""
powered_wing.py — a NESTED sub-assembly: a wing with an engine slung under it.

Demonstrates nesting + selective re-export. The wing and engine leaf components
are instanced INSIDE this component; only what is re-exported surfaces to the
airplane. Because an instance is a body-group, the airplane sees three distinct
parts (wing panel, nacelle, spinner) — not a fused blob — plus the promoted wing
`root`/`tip` anchors for mating.

Note: the wing and engine components are defined at module top level (before the
`with cad.component` block) and merely INSTANCED inside it — components are
defined flat and nested by reference, never by nesting `with` blocks.
"""

from flywheelcad import *
cad = FlyWheelCAD()

import engine                  # defines the "engine" component on import
from wing import wing          # parametric wing factory

_WING = wing(span=46, root_chord=18, tip_chord=9, sweep=6)   # define the wing component

with cad.component("powered_wing"):
    panel = cad.instance(_WING)                              # the lifting surface
    motor = cad.instance("engine", translate=(-2, 16, -5))  # engine under the wing
    cad.export(panel)                       # re-export → flattens the wing's part
    cad.export(motor)                       # re-export → flattens nacelle + spinner
    cad.export_point("root", panel.root)    # promote the wing root for assembly mating
    cad.export_point("tip", panel.tip)
