"""
engine.py — engine leaf component (two bodies).

A nacelle (pod) and a spinner cone, each revolved 360° about the fore-aft axis.
A multi-body component: an instance places both as distinct parts. Exports both
bodies plus `mount` (top, attaches under a wing) and `front` (spinner tip).
"""

from flywheelcad import *
cad = FlyWheelCAD()

with cad.component("engine"):
    # --- Nacelle: a streamlined pod, x = length, y = radius, revolved about x ---
    cad.with_sketch("xy")
    n0 = cad.point2d(0, 0)       # front (on axis)
    n1 = cad.point2d(2, 3)
    n2 = cad.point2d(11, 4)
    n3 = cad.point2d(16, 3)
    n4 = cad.point2d(16, 0)      # back (on axis)
    nl0 = cad.line2d(n0, n1)
    nl1 = cad.line2d(n1, n2)
    nl2 = cad.line2d(n2, n3)
    nl3 = cad.line2d(n3, n4)
    naxis = cad.line2d(n4, n0)
    nacelle = cad.revolve("xy",
                          cad.region(loop=[nl0, nl1, nl2, nl3, naxis], inside=(8, 2)),
                          naxis, 360)
    cad.set_color(nacelle, "#37474F", finish="metallic")   # gunmetal nacelle
    cad.export(nacelle)

    # --- Spinner: a cone in front of the nacelle, revolved about x ---
    cad.with_sketch("xy")
    s0 = cad.point2d(-3, 0)      # spinner tip (on axis)
    s1 = cad.point2d(0, 2)
    s2 = cad.point2d(0, 0)       # base center (on axis)
    sl0 = cad.line2d(s0, s1)
    sl1 = cad.line2d(s1, s2)
    saxis = cad.line2d(s2, s0)
    spinner = cad.revolve("xy",
                          cad.region(loop=[sl0, sl1, saxis], inside=(-1, 0.5)),
                          saxis, 360)
    cad.set_color(spinner, "#FBC02D", finish="glossy")   # gold spinner
    cad.export(spinner)

    cad.export_point("mount", cad.point(8, 0, 4))    # top of nacelle
    cad.export_point("front", cad.point(-3, 0, 0))   # spinner tip
