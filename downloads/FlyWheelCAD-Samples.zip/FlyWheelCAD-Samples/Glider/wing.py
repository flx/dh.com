"""
wing.py — parametric glider wing component (NACA 4412).

A high-aspect-ratio half-wing built from NACA 4412 cross-sections lofted along
the span as ONE smooth solid (`multi_loft`, no seams). Both the planform and the
twist vary NON-LINEARLY along the span:

  - span stations are cosine-spaced (denser near root and tip),
  - the chord tapers with a power law (reduction accelerates toward the tip),
  - the angle of attack washes out with a power law (more washout near the tip),
  - a small constant dihedral raises the sections toward the tip.

Built in its own frame: root at world origin, spanning +Y; chord along +X (local
plane u), lift along +Z (local plane v). The assembly instances it on each side
(the left wing mirrored across zx). `wing(...)` returns the component name.
"""

from flywheelcad import *
from profiles import naca_4412
import math

cad = FlyWheelCAD()


def wing(span=2200.0, root_chord=260.0, tip_chord=110.0,
         root_aoa=3.0, tip_aoa=-1.5, taper_exp=1.7, twist_exp=1.6,
         dihedral_deg=2.5, n_stations=7, samples=10, te_thickness=3.0,
         quality="preview"):
    def build():
        dih = math.tan(math.radians(dihedral_deg))
        planes, regions = [], []
        for k in range(n_stations):
            # Cosine-spaced station -> non-linear span distribution.
            s = 0.5 * (1 - math.cos(math.pi * k / (n_stations - 1)))
            y = span * s
            z = y * dih                                            # dihedral
            chord = root_chord - (root_chord - tip_chord) * (s ** taper_exp)   # non-linear taper
            aoa = root_aoa + (tip_aoa - root_aoa) * (s ** twist_exp)           # non-linear washout

            origin = cad.point(0, y, z)
            along_chord = cad.point(1, y, z)      # local u = +X (chord)
            along_lift = cad.point(0, y, z + 1)   # local v = +Z (lift)
            plane = cad.create_sketch_plane(origin, along_chord, along_lift,
                                            name="wing_%d" % k)

            cad.with_sketch(plane)
            outline = naca_4412(chord=chord, aoa_deg=aoa, n=samples,
                                te_thickness=te_thickness / chord)
            pts = [cad.point2d(px, py) for (px, py) in outline]
            section = cad.spline2d(pts, closed=True)

            planes.append(plane)
            regions.append(cad.region(loop=[section], inside=(0, 0)))

        body = cad.multi_loft(planes, regions, quality=quality)
        cad.set_color(body, "#E9E1CE", finish="matte")   # warm cream
        cad.export(body)
        cad.export_point("root", cad.point(0, 0, 0))
        cad.export_point("tip", cad.point(0, span, span * dih))

    return cad.parametric("wing", build,
                          span=span, root_chord=root_chord, tip_chord=tip_chord,
                          root_aoa=root_aoa, tip_aoa=tip_aoa,
                          taper_exp=taper_exp, twist_exp=twist_exp,
                          dihedral_deg=dihedral_deg, n_stations=n_stations,
                          samples=samples)
