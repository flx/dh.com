"""
flying_wing.py — a Prandtl bell-spanload flying wing (open this file).

A tailless flying wing after NASA's Prandtl-D research aircraft. The wing
twist follows Ludwig Prandtl's 1933 BELL-shaped lift distribution (the exact
NASA twist table lives in wing.py): roughly +8.9° of incidence over the inner
wing washing out to -1.7° at the tips. Because the tips fly at NEGATIVE angle
of attack in the bell spanload's upwash field, they generate induced THRUST —
yaw follows roll the right way (proverse yaw), so the aircraft needs no
vertical fin at all. Prandtl showed the bell spanload cuts induced drag ~11%
versus an elliptical wing of equal structural weight (at 22% more span).

Sections are NACA 4412 at the center per the design brief (the real
Prandtl-D flies custom Eppler sections). Planform per the Prandtl-D:
24° leading-edge sweep, straight taper to 25%, 2.5° dihedral, span ~3750.
Elevons per the paper: outboard 14% of each wing, trailing 25% of chord —
built RC-style as V-groove cutouts hinged at the upper skin (tape hinge),
with an embedded servo, control horn and pushrod. The center pod carries an
electric motor driving a two-blade PUSHER prop behind the trailing edge.

Frame: +X aft, +Y right span, +Z up. Nose of the center pod at the origin.
"""

from flywheelcad import *

cad = FlyWheelCAD()

import pod                       # slim center blister ("pod")
from wing import bell_wing       # Prandtl bell-spanload half-wing factory

WING = bell_wing(semispan=1875.0, root_chord=480.0, taper=0.25,
                 sweep_deg=24.0, dihedral_deg=2.5,
                 n_stations=9, te_thickness=5.0)

# The wing root's 30%-chord spar sits at x = 0 in the wing frame; place it so
# the pod (nose at origin, 620 long, fattest at ~30% length) wraps the deep
# center section.
WING_X, WING_Z = 310.0, 30.0

pod_i = cad.instance("pod")
wing_r = cad.instance(WING, translate=(WING_X, 0, WING_Z))
wing_l = cad.instance(WING, mirror="zx", translate=(WING_X, 0, WING_Z))
