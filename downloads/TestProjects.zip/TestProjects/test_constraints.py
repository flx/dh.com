from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates all constraint types available in FlyWheelCAD.

cad.with_sketch("xy")

# --- Parallel & perpendicular ---
p1 = cad.point2d(0, 0)
p2 = cad.point2d(30, 0)
p3 = cad.point2d(5, 15)
p4 = cad.point2d(35, 15)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p3, p4)
cad.horizontal(l1)
cad.parallel(l1, l2)
cad.length(l1, 30)
cad.length(l2, 30)

p5 = cad.point2d(0, 0)
p6 = cad.point2d(0, 20)
l3 = cad.line2d(p5, p6)
cad.perpendicular(l1, l3)
cad.length(l3, 20)

# --- Collinear ---
p7 = cad.point2d(40, 0)
p8 = cad.point2d(60, 0)
l4 = cad.line2d(p7, p8)
cad.collinear(l1, l4)

# --- Equal length lines ---
p9 = cad.point2d(70, 5)
p10 = cad.point2d(70, 25)
l5 = cad.line2d(p9, p10)
cad.equallines(l3, l5)

# --- Point-on-line ---
p_mid = cad.point2d(15, 0)
cad.pointlinecoincident(p_mid, l1)

# --- Point-line distance ---
p_off = cad.point2d(15, 10)
cad.pointlinedistance(p_off, l1, 10)

# --- Angle between lines ---
p11 = cad.point2d(0, 0)
p12 = cad.point2d(20, 10)
l6 = cad.line2d(p11, p12)
cad.angle(l1, l6, 30)

# --- Distance between points ---
cad.distance(p1, p3, 15)

# --- Circles: concentric, equal radius, tangent ---
c_center = cad.point2d(-40, 30)
c1 = cad.circle2d(c_center, 10)
c2 = cad.circle2d(c_center, 20)
cad.concentric(c1, c2)
cad.radius(c1, 10)

c3_center = cad.point2d(-80, 30)
c3 = cad.circle2d(c3_center, 10)
cad.equalradius(c1, c3)

# Circle tangent to line
tang_p1 = cad.point2d(-50, 0)
tang_p2 = cad.point2d(-30, 0)
tang_line = cad.line2d(tang_p1, tang_p2)
cad.horizontal(tang_line)
c_tang = cad.circle2d(cad.point2d(-40, 8), 8)
tang_anchor = cad.circletangentline(c_tang, tang_line)

# Circle tangent to circle
c4_center = cad.point2d(-40, 55)
c4 = cad.circle2d(c4_center, 5)
cad.circletangentcircle(c2, c4)

# --- Point on circle ---
p_on_c = cad.point2d(-30, 30)
cad.pointoncircle(p_on_c, c2)

# --- Ellipse + point on ellipse + tangent ---
ef1 = cad.point2d(-80, -20)
ef2 = cad.point2d(-60, -20)
ep = cad.point2d(-70, -12)
e1 = cad.ellipse2d(ef1, ef2, ep)
p_on_e = cad.point2d(-70, -28)
cad.pointonellipse(p_on_e, e1)

etang_p1 = cad.point2d(-85, -30)
etang_p2 = cad.point2d(-55, -30)
etang_line = cad.line2d(etang_p1, etang_p2)
etang_anchor = cad.ellipsetangentline(e1, etang_line)

# --- Symmetry line ---
sym_p1 = cad.point2d(50, 30)
sym_p2 = cad.point2d(50, 50)
sym_axis = cad.line2d(sym_p1, sym_p2, construction=True)
cad.vertical(sym_axis)

pa = cad.point2d(40, 40)
pb = cad.point2d(60, 40)
cad.symmetryline(p1=pa, p2=pb, symmetryLine=sym_axis)

# --- Variable + dimension expression ---
width = cad.variable(50, fixed=True)
vp1 = cad.point2d(100, 0)
vp2 = cad.point2d(150, 0)
vl = cad.line2d(vp1, vp2)
cad.length(vl, width)

# --- Merge points ---
mp1 = cad.point2d(100, 30)
mp2 = cad.point2d(100, 30)
cad.merge_points(mp1, mp2)

# --- Spline tangent to line ---
sp1 = cad.point2d(90, -10)
sp2 = cad.point2d(100, -20)
sp3 = cad.point2d(110, -10)
spl = cad.spline2d([sp1, sp2, sp3])
st_p1 = cad.point2d(110, -10)
st_p2 = cad.point2d(120, -10)
st_line = cad.line2d(st_p1, st_p2)
cad.splinetangentline(spl, st_line)

cad.ensure_convergence()

l9 = cad.line2d(p7, p8)
p17 = cad.point2d(15, 10)
p18 = cad.point2d(0, 0)
p19 = cad.point2d(20, 10)
l20 = cad.line2d(p18, p19)
p21 = cad.point2d(-40, 30)
c22 = cad.circle2d(p21, 10)
p48 = cad.point2d(100, 0)
p49 = cad.point2d(150, 0)
l50 = cad.line2d(p48, p49)
