from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates edge_radius across the three body types: extrude, revolve, loft.
# A single edge_radius fillets every sharp edge of the body uniformly — for the
# box below that means the four vertical corners as well as the top/bottom rims.
# (For a focused before/after on an extrude, see test_extrude_rounded_corners.py.)

# --- Rounded extrusion: box with every edge filleted ---

cad.with_sketch("xy")

p1 = cad.point2d(-15, -15)
p2 = cad.point2d(15, -15)
p3 = cad.point2d(15, 15)
p4 = cad.point2d(-15, 15)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 30)
cad.length(l2, 30)

box_region = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))

# Sharp box for comparison (shifted left)
sharp_box = cad.extrude("xy", box_region, 20)

# Rounded box (same geometry, with edge_radius)
rounded_box = cad.extrude("xy", box_region, 20, edge_radius=3.0, quality="ultra")

# --- Rounded partial revolve ---

cad.with_sketch("xy")

# Axis
ax1 = cad.point2d(50, -20)
ax2 = cad.point2d(50, 20)
axis = cad.line2d(ax1, ax2, construction=True)
cad.vertical(axis)

# Profile: small rectangle to the right of axis
rp1 = cad.point2d(58, -8)
rp2 = cad.point2d(72, -8)
rp3 = cad.point2d(72, 8)
rp4 = cad.point2d(58, 8)
rl1 = cad.line2d(rp1, rp2)
rl2 = cad.line2d(rp2, rp3)
rl3 = cad.line2d(rp3, rp4)
rl4 = cad.line2d(rp4, rp1)
cad.horizontal(rl1)
cad.horizontal(rl3)
cad.vertical(rl2)
cad.vertical(rl4)

rev_region = cad.region(loop=[rl1, rl2, rl3, rl4], inside=(65, 0))
rounded_rev = cad.revolve("xy", rev_region, axis, 180.0, edge_radius=2.0, quality="ultra")
