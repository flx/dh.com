from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates section, project, and project_point operations.

# --- Create a box to slice/project ---
cad.with_sketch("xy")
p1 = cad.point2d(-20, -12)
p2 = cad.point2d(20, -12)
p3 = cad.point2d(20, 12)
p4 = cad.point2d(-20, 12)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 40)
cad.length(l2, 24)

box_region = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))
box = cad.extrude("xy", box_region, 18)

# --- Section: cross-section on YZ plane ---
# Slices the box at the YZ plane, producing a closed spline on YZ.
sec = cad.section(box, "yz")

# --- Project: silhouette projection onto YZ plane ---
# Projects the box silhouette along the YZ normal onto the YZ sketch.
proj = cad.project(box, "yz")

# --- Project point: topology vertex onto ZX plane ---
pp = cad.project_point(box.v0, "zx")
