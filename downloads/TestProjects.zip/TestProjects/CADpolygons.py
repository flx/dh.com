from flywheelcad import *
import math

cad = FlyWheelCAD()


def regular_polygon(center_x, center_y, side_count, radius, plane_name="xy", start_deg=0.0, construction=False):
    """Create a regular polygon as explicit line segments."""
    if side_count < 3:
        raise ValueError("side_count must be >= 3")
    if radius <= 0:
        raise ValueError("radius must be > 0")

    cad.with_sketch(plane_name)

    points = []
    step_deg = 360.0 / float(side_count)
    for i in range(side_count):
        angle = math.radians(start_deg + i * step_deg)
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)
        points.append(cad.point2d(x, y))

    lines = []
    for i in range(side_count):
        lines.append(cad.line2d(points[i], points[(i + 1) % side_count], construction=construction))

    return {"points": points, "lines": lines}


def nested_polygons(center_x, center_y, side_count, radius_start, levels, radius_step,
                    plane_name="xy", start_deg=0.0):
    """Create concentric rotated polygons for pattern examples."""
    if levels < 1:
        raise ValueError("levels must be >= 1")

    created = []
    for level in range(levels):
        radius = radius_start + level * radius_step
        created.append(
            regular_polygon(
                center_x=center_x,
                center_y=center_y,
                side_count=side_count,
                radius=radius,
                plane_name=plane_name,
                start_deg=start_deg + level * (180.0 / max(side_count, 3)),
            )
        )

    return created


def polygon_spokes(center_x, center_y, side_count, radius, plane_name="xy"):
    """Create radial spokes from center to polygon vertices."""
    polygon = regular_polygon(center_x, center_y, side_count, radius, plane_name=plane_name)
    cad.with_sketch(plane_name)
    center = cad.point2d(center_x, center_y)
    spokes = [cad.line2d(center, p) for p in polygon["points"]]
    return {"center": center, "polygon": polygon, "spokes": spokes}
