from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates the offset (shell) command.
# Positive distance expands the body outward.
# Negative distance shrinks it inward.

cad.with_sketch("xy")

# Base body: small box
p1 = cad.point2d(-10, -10)
p2 = cad.point2d(10, -10)
p3 = cad.point2d(10, 10)
p4 = cad.point2d(-10, 10)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 20)
cad.length(l2, 20)

box_region = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))
box = cad.extrude("xy", box_region, 20)

# Expanded shell: 2 units larger in every direction
expanded = cad.offset(box, distance=2.0)

# Hollow shell: subtract shrunk body from expanded body
shrunk = cad.offset(box, distance=-2.0)
shell = cad.bool_difference(expanded, shrunk, quality="high")
