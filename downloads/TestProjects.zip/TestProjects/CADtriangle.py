from flywheelcad import *
cad = FlyWheelCAD()


def triangleCAD(insertpoint, plane_name, len):
    cad.with_sketch(plane_name)
    c1 = cad.circle2d(insertpoint, 163.4)
    p2 = cad.point2d(-337.21, -173.12)
    p3 = cad.point2d(25.92, 355.06)
    l4 = cad.line2d(p2, p3)
    p5 = cad.point2d(317.08, -187.11)
    l6 = cad.line2d(p3, p5)
    l7 = cad.line2d(p5, p2)

    cad.circletangentline(circle=c1, line=l7)
    cad.circletangentline(circle=c1, line=l6)
    cad.circletangentline(circle=c1, line=l4)
    cad.horizontal(line=l7)
    cad.equallines(line1=l7, line2=l4)
    cad.equallines(line1=l4, line2=l6)
    cad.length(line=l7, length=len)