from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates lofting between two parallel sketch planes.
# A rectangle on XY lofted to a circle on a custom plane above it.

# --- Bottom profile: rectangle on XY ---
cad.with_sketch("xy")
p1 = cad.point2d(-15, -10)
p2 = cad.point2d(15, -10)
p3 = cad.point2d(15, 10)
p4 = cad.point2d(-15, 10)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 30)
cad.length(l2, 20)

# Extrude to get topology points for the custom plane
box = cad.extrude("xy", cad.region(loop=[l1, l2, l3, l4], inside=(0, 0)), 25, export=False)

# Create a parallel plane at the top of the box using 3 topology points
top_plane = cad.create_sketch_plane(box.v0, box.v1, box.v2)

# --- Top profile: circle on the custom plane ---
cad.with_sketch(top_plane)
tc = cad.point2d(0, 0)
top_circle = cad.circle2d(tc, 8)
cad.radius(top_circle, 8)

# --- Loft from rectangle to circle ---
bottom_region = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))
top_region = cad.region(loop=[top_circle], inside=(0, 0))
lofted = cad.loft(
    start_plane="xy",
    start_region=bottom_region,
    end_plane=top_plane,
    end_region=top_region,
    quality = "ultra"
)
