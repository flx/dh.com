from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates smooth and chamfer boolean blends.
# Smooth blend produces a rounded fillet at the seam.
# Chamfer blend produces a flat 45-degree bevel.

cad.with_sketch("xy")

# --- Body A: centered box ---
pa1 = cad.point2d(-15, -15)
pa2 = cad.point2d(15, -15)
pa3 = cad.point2d(15, 15)
pa4 = cad.point2d(-15, 15)
la1 = cad.line2d(pa1, pa2)
la2 = cad.line2d(pa2, pa3)
la3 = cad.line2d(pa3, pa4)
la4 = cad.line2d(pa4, pa1)
cad.horizontal(la1)
cad.horizontal(la3)
cad.vertical(la2)
cad.vertical(la4)
cad.length(la1, 30)
cad.length(la2, 30)

region_a = cad.region(loop=[la1, la2, la3, la4], inside=(0, 0))
box = cad.extrude("xy", region_a, 20)

# --- Body B: cylinder overlapping box corner ---
cc = cad.point2d(15, 15)
ccirc = cad.circle2d(cc, 10)
cad.radius(ccirc, 10)
region_b = cad.region(loop=[ccirc], inside=(15, 15))
cyl = cad.extrude("xy", region_b, 20)

# --- Smooth union: rounded fillet at the seam ---
smooth_union = cad.bool_union(box, cyl, blend="smooth", radius=3.0, quality="ultra")

# --- Body C: hole cylinder for chamfer difference ---
hc = cad.point2d(0, 0)
hcirc = cad.circle2d(hc, 6)
cad.radius(hcirc, 6)
region_c = cad.region(loop=[hcirc], inside=(0, 0))
hole_cyl = cad.extrude("xy", region_c, 20)

# --- Chamfer difference: beveled edge around the hole ---
chamfer_diff = cad.bool_difference(smooth_union, hole_cyl, blend="chamfer", radius=2.0, quality="ultra")
