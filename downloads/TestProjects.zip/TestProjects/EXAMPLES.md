# TestProjects — FlyWheelCAD Example Scripts

These example files are intended to be opened and replayed as small, focused demonstrations of specific FlyWheelCAD features.

Most files are self-contained. `test_gears.py` imports helper functions from `CADgears.py`.

## Sketching & Geometry

### `test_drawing.py` — Symmetric house sketch
This file builds a simple house drawing on the `xy` sketch plane.

What happens:
- A vertical construction line is created as the symmetry axis.
- The right half of the house outline is drawn explicitly.
- A rectangular window, a half-door, a door-handle circle, and a roof-window ellipse are added.
- The main right-side linework is mirrored across the symmetry axis to create the left half.

Key APIs used:
`with_sketch`, `point2d`, `line2d`, `circle2d`, `ellipse2d`, `construction`, `horizontal`, `vertical`, `length`, `update`, `mirror`

### `test_constraints.py` — Constraint and dimension sampler
This file is a broad sampler of the currently exercised 2D constraints and dimensions. It is not literally every available constraint in the app, but it covers most of the common ones.

What happens:
- Horizontal, parallel, perpendicular, collinear, equal-length, and point-on-line relationships are applied to lines and points.
- Point-to-line distance, point-to-point distance, and line angle dimensions are added.
- Circles are used for concentric, equal-radius, point-on-circle, circle-line tangent, and circle-circle tangent examples.
- An ellipse is used for point-on-ellipse and ellipse-line tangent examples.
- A symmetry-line example is created around a construction axis.
- A variable-driven line length is added.
- A point merge and a spline-line tangent example are included.
- `ensure_convergence()` is called at the end to explicitly solve the sketch.

Key APIs used:
`horizontal`, `parallel`, `perpendicular`, `collinear`, `equallines`, `pointlinecoincident`, `pointlinedistance`, `angle`, `distance`, `concentric`, `radius`, `equalradius`, `circletangentline`, `circletangentcircle`, `pointoncircle`, `pointonellipse`, `ellipsetangentline`, `symmetryline`, `variable`, `merge_points`, `spline2d`, `splinetangentline`, `ensure_convergence`

### `test_trim.py` — Trim on line and circle
This file demonstrates trimming in-place and the split-element behavior that trim can produce.

What happens:
- Two crossing lines are created and the horizontal one is trimmed near its right end, leaving the left segment as the primary result.
- A circle is crossed by a horizontal line and then trimmed near its top, producing two arcs.
- The script keeps both returned references from `trim(...)` to show how the surviving and split pieces can be reused.

Key APIs used:
`trim`

## 3D Bodies

### `test_extrude_revolve.py` — Extrude with hole and partial revolve
This file demonstrates two basic body operations from sketch regions.

What happens:
- On `xy`, a rectangle with a circular hole is built and extruded as a plate.
- On `xy`, a second sketch creates a semicircular profile from an arc plus a closing line.
- That second profile is revolved around a construction axis through `75` degrees.

Key APIs used:
`extrude`, `revolve`, `arc2d`, `region`, `radius`

### `test_boolean.py` — Box minus cylinder
This file demonstrates a simple subtraction workflow.

What happens:
- A rectangle is extruded into a box.
- A circle is extruded into a cylinder.
- The cylinder is subtracted from the box with `bool_difference`.

Key APIs used:
`extrude`, `bool_difference`

### `test_boolean_ops.py` — Union, intersection, subtraction
This file demonstrates all three boolean operations on reused input bodies.

What happens:
- Two overlapping extruded boxes are created.
- A cylinder is extruded through the overlap area.
- The script produces:
  - a union of the two boxes,
  - an intersection of the two boxes,
  - a subtraction of the cylinder from the unioned body.

Key APIs used:
`bool_union`, `bool_intersection`, `bool_difference`

### `test_loft.py` — Rectangle to circle loft
This file demonstrates lofting between two parallel sketch planes.

What happens:
- A rectangle is created on `xy`.
- That rectangle is temporarily extruded so its top-face topology points can be referenced.
- A custom sketch plane is created from three top-face topology points.
- A circle is created on the custom plane.
- A loft is created from the rectangular region to the circular region.

Key APIs used:
`extrude`, `create_sketch_plane`, `with_sketch`, `loft`, topology-point access such as `box.v0`

## Multi-Plane & Analysis

### `test_sketch_planes.py` — Standard planes plus custom plane
This file demonstrates sketching across multiple planes and creating a derived sketch plane from body topology.

What happens:
- A constrained rectangle is drawn on `xy` and extruded into a box.
- A separate line is drawn on `yz`.
- A custom oblique plane is defined from three topology points of the box.
- A circle is drawn on that custom plane and extruded.

Key APIs used:
`with_sketch`, `extrude`, `create_sketch_plane`

### `test_section_project.py` — Section, project, project_point
This file demonstrates analysis-style geometry generation from an existing body.

What happens:
- A box is created by extruding a rectangle on `xy`.
- `section(...)` slices the body with the `yz` plane.
- `project(...)` creates a silhouette-style projection onto the `yz` plane.
- `project_point(...)` projects a topology point from the box onto the `zx` plane.

Key APIs used:
`section`, `project`, `project_point`

## Gears

### `test_gears.py` — Single gear, meshing pair, and keyway cut
This file demonstrates a heavier scripted workflow with imported helpers and mixed sketch planes.

What happens:
- A single involute-style gear profile is generated on `xy` and extruded.
- A meshing gear pair is generated on `yz` and both ring regions are extruded there.
- A rectangular keyway sketch is created on `yz`, extruded as a cutter, and subtracted from one of the gear bodies.

Key APIs used:
`gear_outline`, `gear_pair`, `extrude`, `bool_difference`, `region`

### `CADgears.py` — Gear-profile helper
This helper file generates gear-like closed profiles from line-segment approximations of involute tooth flanks.

What happens:
- `gear_outline(...)` computes a polyline boundary for one spur-gear profile.
- It emits a center point, many boundary points, connecting profile edges, and a bore circle.
- It builds two reusable region intents:
  - `region_ring` for the gear annulus,
  - `region_bore` for the central hole.
- `gear_pair(...)` places two gears at the correct pitch-center distance and rotates the second gear for meshing.

This helper is intentionally more algorithmic than the other examples. It exists to show that FlyWheelCAD scripts can generate large sketches programmatically, not just hand-authored geometry.

## Capability Coverage

| Capability | Example files |
|---|---|
| Points and lines | `test_drawing.py`, `test_constraints.py`, `test_trim.py` |
| Circles | `test_drawing.py`, `test_constraints.py`, `test_boolean.py`, `test_gears.py` |
| Ellipses | `test_drawing.py`, `test_constraints.py` |
| Arcs | `test_trim.py`, `test_extrude_revolve.py` |
| Splines | `test_constraints.py` |
| Construction geometry | `test_drawing.py`, `test_constraints.py`, `test_extrude_revolve.py` |
| Mirror | `test_drawing.py` |
| Trim | `test_trim.py` |
| Constraint solving | `test_constraints.py` |
| Variables and expressions | `test_constraints.py` |
| Merge points | `test_constraints.py` |
| Extrude | `test_extrude_revolve.py`, `test_boolean.py`, `test_boolean_ops.py`, `test_loft.py`, `test_sketch_planes.py`, `test_section_project.py`, `test_gears.py` |
| Revolve | `test_extrude_revolve.py` |
| Loft | `test_loft.py` |
| Boolean operations | `test_boolean.py`, `test_boolean_ops.py`, `test_gears.py` |
| Custom sketch planes | `test_loft.py`, `test_sketch_planes.py` |
| Topology-point references | `test_loft.py`, `test_sketch_planes.py`, `test_section_project.py` |
| Section and projection | `test_section_project.py` |
| Region intents | `test_extrude_revolve.py`, `test_boolean.py`, `test_boolean_ops.py`, `test_loft.py`, `test_sketch_planes.py`, `test_section_project.py`, `test_gears.py` |
| Programmatic geometry generation from helper code | `test_gears.py`, `CADgears.py` |
