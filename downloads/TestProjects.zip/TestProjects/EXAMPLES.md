# Imported Python Geometry Examples

This folder now contains progressively more complex examples that use helper
Python modules imported from the same project folder as the `.fwcad` file.

## Files

- `CADtriangle.py`
  - Existing triangle helper (constraint-driven triangle around a circle).
- `CADpolygons.py`
  - `regular_polygon(...)`
  - `nested_polygons(...)`
  - `polygon_spokes(...)`
- `CADgears.py`
  - `gear_outline(...)` (gear-like closed spline + bore circle)
  - `gear_pair(...)` (two gear-like profiles at meshing center distance)

## Entry scripts

- `test.fwcad`
  - Existing triangle import example.
- `test_polygons.fwcad`
  - Basic to intermediate imported polygon patterns.
- `test_gears.fwcad`
  - Gear-like sketch generation, extrusion, and boolean bore subtraction.
- `test_showcase.fwcad`
  - Combined example: triangle import + polygon import + gear import + custom sketch plane + follow-up extrusion.

All scripts assume canonical plane names (`xy`, `yz`, `zx`) and import helper modules from this same folder.
