from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates the fixed `edge_radius` rounding on extrude.
# Previously edge_radius only filleted the top/bottom cap RIMS and left the
# VERTICAL corner edges sharp. Now a single edge_radius fillets ALL edges of the
# prism uniformly — the four vertical corners as well as the top/bottom rims.
# An L-shaped profile makes this obvious: it has both convex and concave
# vertical corners, and every one is now rounded.

cad.with_sketch("xy")

# L-shaped profile (6 corners), traced counter-clockwise.
a = cad.point2d(-15, -15)
b = cad.point2d(15, -15)
c = cad.point2d(15, 0)
d = cad.point2d(0, 0)
e = cad.point2d(0, 15)
f = cad.point2d(-15, 15)
l1 = cad.line2d(a, b)
l2 = cad.line2d(b, c)
l3 = cad.line2d(c, d)
l4 = cad.line2d(d, e)
l5 = cad.line2d(e, f)
l6 = cad.line2d(f, a)
cad.horizontal(l1)
cad.vertical(l2)
cad.horizontal(l3)
cad.vertical(l4)
cad.horizontal(l5)
cad.vertical(l6)

l_region = cad.region(loop=[l1, l2, l3, l4, l5, l6], inside=(-10, -10))

# Sharp L for comparison.
sharp = cad.extrude("xy", l_region, 16)

# Rounded L: every edge (rims + all vertical corners) filleted by 3 mm.
rounded = cad.extrude("xy", l_region, 16, edge_radius=3.0, quality="ultra")
