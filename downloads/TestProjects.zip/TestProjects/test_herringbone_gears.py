from flywheelcad import *
from CADgears import gear_outline, gear_pair, helix_twist_degrees

cad = FlyWheelCAD()

# Herringbone (double-helical) gears. A herringbone tooth is two OPPOSITE-hand
# helical halves meeting in a chevron. The key is that the two halves must twist
# in opposite senses: a single twist extrude (even a symmetric one) only ever
# produces rotation = rate*z, i.e. one continuous helix whose un-twisted band
# merely sits in the middle — NOT a "V". To get a real chevron the rotation must
# be rate*|z|, so we build each gear from two half-height extrudes: the upper
# half twists +theta going up and the lower half twists -theta going down. Both
# share the un-twisted profile at z=0, so unioning them gives a "V" apex there.
#
# Real herringbone gears have a relief groove at the apex (so the cutting tool
# can run out), turning the sharp "V" into a "\/" with a small gap. We reproduce
# that by subtracting a thin ring at the mid-plane (bool_difference): it
# interrupts the teeth over a small axial gap while leaving the central hub
# solid, so the two helical halves stay one connected part.

MODULE = 5.0
FACE_WIDTH = 30.0       # total axial height of each gear
HELIX_ANGLE = 22.0      # helix angle at the pitch radius, degrees
GROOVE_GAP = 4.0        # axial width of the relief gap at the apex
TEETH_PINION = 18
TEETH_WHEEL = 30


def herringbone(gear, hand, cut_name):
    """Build `gear` as a herringbone (double-helical) body with a relief groove.

    `hand` (+1 / -1) selects the helical hand; meshing gears use opposite hands.
    """
    cx, cy = gear["center_xy"]
    half = 0.5 * FACE_WIDTH

    # Per-half twist that realises HELIX_ANGLE at the pitch radius. `twist` is
    # the rotation at the FAR end relative to the un-twisted base (always z=0),
    # so for a chevron BOTH halves take the same twist sign: the upper far end
    # (z=+half) and the lower far end (z=-half) then rotate the same way while
    # the shared z=0 profile stays put -> rotation rate*|z|, a "V". (Opposite
    # signs would line the halves up into one continuous helix instead.)
    theta = helix_twist_degrees(half, HELIX_ANGLE, gear["pitch_radius"])
    upper = cad.extrude(
        "xy", gear["region_ring"], half,
        direction="positive", twist=+hand * theta, twist_center=(cx, cy),
        export=False,
    )
    lower = cad.extrude(
        "xy", gear["region_ring"], half,
        direction="negative", twist=+hand * theta, twist_center=(cx, cy),
        export=False,
    )
    chevron = cad.bool_union(upper, lower, export=False)

    # Build the relief cutter on its OWN sketch plane, coincident with xy but
    # with its origin AT the gear centre. That keeps the ring on a clean sketch
    # (the gear's tooth edges would otherwise fragment it during region
    # detection), and makes local (0, 0) map to the gear axis in world space.
    # We reuse the gear centre + two profile points to define the plane, so no
    # duplicate points land on the xy sketch.
    pts = gear["profile_points"]
    cad.create_sketch_plane(gear["center"], pts[0], pts[1], name=cut_name)
    cad.with_sketch(cut_name)

    local_center = cad.point2d(0, 0)            # = gear centre in world
    # Outer radius clears the tooth tips; inner radius sits just BELOW the root
    # circle so the groove floor doesn't coincide with the gear's root surface
    # (an exact coincidence makes the CSG produce non-manifold sliver edges).
    inner_r = gear["root_radius"] - 0.5 * MODULE
    r_mid = 0.5 * (inner_r + gear["addendum_radius"])
    outer = cad.circle2d(local_center, gear["addendum_radius"] + 0.5 * MODULE)
    inner = cad.circle2d(local_center, inner_r)
    ring = cad.region(loop=[outer], holes=[[inner]], inside=(r_mid, 0))

    # Thin disk-ring centred on the mid-plane (symmetric => z in [-gap/2, gap/2]).
    cutter = cad.extrude(cut_name, ring, GROOVE_GAP, direction="symmetric", export=False)

    return cad.bool_difference(chevron, cutter)


# Two herringbone gears placed at the meshing centre distance, with enough
# clearance that their tips stay apart — close enough to mesh, far enough to
# read as two distinct gears. Meshing double-helical gears share the helix angle
# with OPPOSITE hands, so the pinion twists +T and the wheel -T.
pair = gear_pair(
    center_x=0, center_y=0,
    teeth_a=TEETH_PINION, teeth_b=TEETH_WHEEL, module=MODULE,
    pressure_angle_deg=20.0, gap=15.0,
)
pinion = pair["gear_a"]
wheel = pair["gear_b"]

pinion_body = herringbone(pinion, +1, "cut_pinion")
wheel_body = herringbone(wheel, -1, "cut_wheel")
