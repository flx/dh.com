"""
twisted_NACA_4412.py — a tapered, twisted NACA 4412 wing.

A 2 m (2000 unit) half-wing built from NACA 4412 cross-sections:
  - chord 400 (40 cm) at the root, 200 (20 cm) at the tip, with the taper
    accelerating toward the tip (non-linear),
  - 5° angle of attack at the root washing out to -2° at the tip (twist).

Each cross-section is drawn on its own sketch plane (perpendicular to the span,
pinned through the spar at 30% chord). Consecutive sections are lofted, and the
loft segments are joined with a boolean union into one wing body.

The airfoil profile comes from the sibling module naca_4412.py.

Note: the span (2000) is large relative to the ~50-unit section thickness, so the
union's dual-contouring grid is the resolution bottleneck — raise the document's
mesh quality (or scale the model down) for a finer surface.
"""

from flywheelcad import *
from naca_4412 import naca_4412

cad = FlyWheelCAD()

# ---- Wing parameters (1 unit = 1 mm) ----
SPAN = 2000.0          # 2 m half-span
ROOT_CHORD = 400.0     # 40 cm
TIP_CHORD = 200.0      # 20 cm
ROOT_AOA = 15.0         # degrees (lift)
TIP_AOA = -12.0         # degrees (washout)
TAPER_EXP = 2.0        # > 1 → chord reduction accelerates toward the tip
NUM_STATIONS = 10      # cross-section planes from root to tip (fewer = faster)
SECTION_SAMPLES = 32   # cosine samples per surface → 2N spline control points.
                       # The skin is a smooth spline, so this is the curve-fidelity
                       # knob (how closely each section tracks the true NACA shape
                       # and how tight the trailing-edge round is), not a facet
                       # count — splines need fewer points than a polyline for the
                       # same smoothness. 16 ≈ fine, 32 ≈ very faithful.
TE_THICKNESS = 3.0     # blunt trailing-edge thickness, in model units (absolute,
                       # held constant along the span). A NACA TE tapers to a
                       # point; left sharp, that sub-cell wedge stair-steps into a
                       # jagged edge when the SDF body is dual-contoured. Blunting
                       # it to a flat TE this thick keeps the section thickness
                       # above the mesh grid pitch so the surface stays clean.
                       # Raise it if the TE still looks ragged at a coarse mesh
                       # quality; set 0 for a sharp (point) TE.
# The whole wing is one smooth multi_loft body; this is the build's dominant
# cost and scales with quality (preview → ultra), where a finer grid resolves
# the 2 m span at the cost of more vertices. (Surface smoothness comes from the
# spline sections and the C1 spanwise rulings; the grid only sets how finely
# that already-smooth surface is sampled.) NOTE: the multi-section loft meshes
# on the CPU for now, so high qualities are slower than the old GPU union.
WING_QUALITY = "ultra"


def chord_at(s):
    # s in [0, 1] (0 = root, 1 = tip). Non-linear taper: the reduction grows
    # toward the tip, so the planform is concave rather than straight.
    return ROOT_CHORD - (ROOT_CHORD - TIP_CHORD) * (s ** TAPER_EXP)


def aoa_at(s):
    # Linear twist (washout) from the root angle to the tip angle.
    return ROOT_AOA + (TIP_AOA - ROOT_AOA) * s


# ---- One sketch plane + airfoil profile per station ----
# Each plane has normal -Y (the span axis); its local axes are local-x = +X
# (chord) and local-y = +Z (lift). The plane origin sits on the spar line
# (world X = Z = 0), so the airfoil's spar maps to local (0, 0).
#
# Each section is a single closed spline through the airfoil points, so the
# skin is a genuinely smooth surface (the leading edge stays round; no facets
# between samples). The points are still cosine-spaced (SECTION_SAMPLES), which
# now sets how faithfully the spline tracks the true NACA curve rather than a
# visible facet count. The trailing edge is blunted to TE_THICKNESS (a flat
# face), so the thin TE wedge never tapers below the mesh grid pitch.
profiles = []   # (plane_ref, spline_ref) per station
for k in range(NUM_STATIONS):
    s = k / (NUM_STATIONS - 1)
    y = SPAN * s

    origin = cad.point(0, y, 0)
    along_chord = cad.point(1, y, 0)   # +X
    along_lift = cad.point(0, y, 1)    # +Z
    plane = cad.create_sketch_plane(origin, along_chord, along_lift,
                                    name="station_%d" % k)

    cad.with_sketch(plane)
    # te_thickness is a fraction of chord; divide the absolute TE_THICKNESS by
    # this station's chord so every section gets the SAME absolute blunt TE.
    outline = naca_4412(chord=chord_at(s), aoa_deg=aoa_at(s), n=SECTION_SAMPLES,
                        te_thickness=TE_THICKNESS / chord_at(s))
    pts = [cad.point2d(px, py) for (px, py) in outline]
    section = cad.spline2d(pts, closed=True)
    profiles.append((plane, section))

# ---- Smooth loft through all cross-sections as ONE body ----
# multi_loft interpolates the sections with C1 (Catmull-Rom) rulings, so the
# wing is a single smooth solid with no internal seams. (The old approach —
# lofting each adjacent pair into a separate segment and joining them with a
# boolean union — left a faint divot at every shared station, because two
# abutting bodies' coincident end caps make the union's SDF return zero across
# the seam plane. One body has no internal caps, so there is nothing to seam.)
planes = [plane for (plane, _section) in profiles]
regions = [cad.region(loop=[section], inside=(0, 0)) for (_plane, section) in profiles]
wing = cad.multi_loft(planes, regions, quality=WING_QUALITY)
