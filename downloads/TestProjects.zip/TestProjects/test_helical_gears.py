from flywheelcad import *
from CADgears import gear_outline, gear_pair, helix_twist_degrees

cad = FlyWheelCAD()

# Helical gears reuse the flat involute tooth profile from CADgears.py. The
# "helix" comes entirely from the extrude: passing twist=<degrees> rotates the
# cross-section as it rises, and twist_center=<axis> keeps that rotation about
# the gear centre. helix_twist_degrees() converts a helix angle (at the pitch
# radius) into the total twist over the face width: F * tan(beta) / r_pitch.

MODULE = 5.0
FACE_WIDTH = 30.0      # axial extrude height
HELIX_ANGLE = 20.0     # helix angle at the pitch radius, degrees

# 1) Right-hand helical gear (positive twist).
right = gear_outline(center_x=-220, center_y=0, tooth_count=24, module=MODULE, plane_name="xy")
right_twist = helix_twist_degrees(FACE_WIDTH, HELIX_ANGLE, right["pitch_radius"])
right_body = cad.extrude(
    "xy", right["region_ring"], FACE_WIDTH,
    twist=right_twist, twist_center=right["center_xy"], )

# 2) Left-hand helical gear: same helix angle, opposite hand -> negative twist.
left = gear_outline(center_x=20, center_y=0, tooth_count=24, module=MODULE, plane_name="xy")
left_twist = helix_twist_degrees(FACE_WIDTH, HELIX_ANGLE, left["pitch_radius"])
left_body = cad.extrude(
    "xy", left["region_ring"], FACE_WIDTH,
    twist=-left_twist, twist_center=left["center_xy"],
)

# 3) Meshing helical pair. External helical gears mesh when they share the helix
# angle but have OPPOSITE hands. Over the same face width each twists by
# F*tan(beta)/r, so the smaller pinion (smaller pitch radius) twists more.
pair = gear_pair(
    center_x=160, center_y=-220,
    teeth_a=18, teeth_b=30, module=MODULE,
    pressure_angle_deg=20.0, rotation_a_deg=6.0, gap=10.0,
)
pinion = pair["gear_a"]
wheel = pair["gear_b"]

pinion_twist = helix_twist_degrees(FACE_WIDTH, HELIX_ANGLE, pinion["pitch_radius"])
wheel_twist = helix_twist_degrees(FACE_WIDTH, HELIX_ANGLE, wheel["pitch_radius"])

pinion_body = cad.extrude(
    "xy", pinion["region_ring"], FACE_WIDTH,
    twist=pinion_twist, twist_center=pinion["center_xy"], 
)
wheel_body = cad.extrude(
    "xy", wheel["region_ring"], FACE_WIDTH,
    twist=-wheel_twist, twist_center=wheel["center_xy"],
)
