from flywheelcad import *

cad = FlyWheelCAD()

# Demonstrates the extrude `draft` (taper) parameter, in degrees.
#   draft = 0   -> straight walls (the default)
#   draft > 0   -> walls slope OUTWARD (far face larger than the sketch)
#   draft < 0   -> walls slope INWARD  (far face smaller than the sketch)
# The taper is measured from the base (sketch-side) face, which always keeps
# the original sketch profile size.

cad.with_sketch("xy")

# A reusable 20 x 20 square region, centered at the origin.
p1 = cad.point2d(-10, -10)
p2 = cad.point2d(10, -10)
p3 = cad.point2d(10, 10)
p4 = cad.point2d(-10, 10)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 20)
cad.length(l2, 20)

square = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))

# Straight reference prism.
straight = cad.extrude("xy", square, 20)

# Outward draft: a 10-degree taper widens the top (think a tapered plug).
outward = cad.extrude("xy", square, 20, draft=10)

# Inward draft: a -10-degree taper narrows the top (a truncated pyramid).
inward = cad.extrude("xy", square, 20, draft=-10)
