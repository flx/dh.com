from flywheelcad import *
import math

cad = FlyWheelCAD()


def _rotate_xy(x, y, angle):
    c = math.cos(angle)
    s = math.sin(angle)
    return (x * c - y * s, x * s + y * c)


def _involute_point(base_radius, t):
    x = base_radius * (math.cos(t) + t * math.sin(t))
    y = base_radius * (math.sin(t) - t * math.cos(t))
    return (x, y)


def _circumcenter(p0, p1, p2):
    """Center of the circle through three points; None if they are collinear."""
    ax, ay = p0
    bx, by = p1
    cx, cy = p2
    d = 2.0 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) < 1e-9:
        return None
    a2 = ax * ax + ay * ay
    b2 = bx * bx + by * by
    c2 = cx * cx + cy * cy
    ux = (a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d
    uy = (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d
    return (ux, uy)


def _arc_is_clockwise(center, start, mid, end):
    """True if the arc start→end that passes through `mid` sweeps clockwise.

    Matches Arc2D's convention (sketch space is y-up, so clockwise means
    decreasing polar angle).
    """
    cx, cy = center
    a_start = math.atan2(start[1] - cy, start[0] - cx)
    a_mid = math.atan2(mid[1] - cy, mid[0] - cx)
    a_end = math.atan2(end[1] - cy, end[0] - cx)
    two_pi = 2.0 * math.pi
    span_to_mid = (a_mid - a_start) % two_pi
    span_to_end = (a_end - a_start) % two_pi
    # If `mid` is reached before `end` sweeping counter-clockwise, the arc
    # containing it is counter-clockwise; otherwise it runs clockwise.
    return span_to_mid > span_to_end


def _short_arc_midpoint(center, radius, start, end):
    """A point on the shorter circular arc between `start` and `end`.

    Used only to pick the correct sweep direction for tip/root arcs.
    """
    cx, cy = center
    a_start = math.atan2(start[1] - cy, start[0] - cx)
    a_end = math.atan2(end[1] - cy, end[0] - cx)
    delta = a_end - a_start
    while delta <= -math.pi:
        delta += 2.0 * math.pi
    while delta > math.pi:
        delta -= 2.0 * math.pi
    mid = a_start + 0.5 * delta
    return (cx + radius * math.cos(mid), cy + radius * math.sin(mid))


def gear_outline(
    center_x,
    center_y,
    tooth_count,
    module,
    pressure_angle_deg=20.0,
    addendum_coeff=1.0,
    dedendum_coeff=1.25,
    bore_ratio=0.28,
    plane_name="xy",
    rotation_deg=0.0,
    flank_arc_segments=2,
):
    """Create an involute spur gear sketch built from circular arcs.

    The tooth tips and the root gaps between teeth are *exact* circular arcs
    about the gear centre. Each involute flank is approximated by
    `flank_arc_segments` circular arcs fitted through points sampled along the
    true involute. Because the involute sweeps only a few degrees over a single
    tooth it is very nearly circular there, so even one arc per flank is an
    excellent fit; raising `flank_arc_segments` tightens it further.
    """
    if tooth_count < 8:
        raise ValueError("tooth_count must be >= 8")
    if module <= 0:
        raise ValueError("module must be > 0")
    if bore_ratio <= 0 or bore_ratio >= 1:
        raise ValueError("bore_ratio must be in (0, 1)")
    if flank_arc_segments < 1:
        raise ValueError("flank_arc_segments must be >= 1")

    pressure_angle = math.radians(pressure_angle_deg)
    pitch_radius = 0.5 * module * tooth_count
    base_radius = pitch_radius * math.cos(pressure_angle)
    addendum_radius = pitch_radius + addendum_coeff * module
    dedendum_radius = max(module * 0.55, pitch_radius - dedendum_coeff * module)

    if addendum_radius <= base_radius:
        raise ValueError("addendum radius must be > base radius")

    t_pitch = math.sqrt(max((pitch_radius / base_radius) ** 2 - 1.0, 0.0))
    involute_pitch_angle = t_pitch - math.atan(t_pitch)
    half_tooth_angle = math.pi / (2.0 * tooth_count)
    involute_rotation = -(half_tooth_angle + involute_pitch_angle)

    r_start = max(base_radius, dedendum_radius)
    root_radius = r_start
    t_start = math.sqrt(max((r_start / base_radius) ** 2 - 1.0, 0.0))
    t_tip = math.sqrt(max((addendum_radius / base_radius) ** 2 - 1.0, 0.0))

    # Sample the involute densely enough to fit `flank_arc_segments` arcs:
    # each arc needs a start, a through-point (mid), and an end, so the flank
    # is sampled at 2 * segments + 1 points.
    n_flank_samples = 2 * flank_arc_segments + 1
    flank_a = []
    for i in range(n_flank_samples):
        alpha = i / float(n_flank_samples - 1)
        t = t_start + (t_tip - t_start) * alpha
        x, y = _involute_point(base_radius, t)
        flank_a.append(_rotate_xy(x, y, involute_rotation))
    flank_b = [(x, -y) for (x, y) in flank_a]

    a_root_angle = math.atan2(flank_a[0][1], flank_a[0][0])
    b_root_angle = math.atan2(flank_b[0][1], flank_b[0][0])
    if a_root_angle <= b_root_angle:
        flank_right = flank_a
        flank_left = flank_b
    else:
        flank_right = flank_b
        flank_left = flank_a

    tooth_pitch_angle = 2.0 * math.pi / tooth_count
    base_rotation = math.radians(rotation_deg)
    gear_center = (center_x, center_y)

    # --- Build the boundary as an ordered list of arc segments ---
    # Each segment is a dict: start/end world points, an arc center (or None
    # for a degenerate straight fallback), the clockwise flag, and whether the
    # centre is the shared gear centre (tip/root arcs reuse one point).
    def to_world(local_pt, angle):
        rx, ry = _rotate_xy(local_pt[0], local_pt[1], angle)
        return (center_x + rx, center_y + ry)

    def flank_segments(samples):
        # samples: world points along one flank, ordered start → end.
        segs = []
        for k in range(flank_arc_segments):
            a = samples[2 * k]
            mid = samples[2 * k + 1]
            b = samples[2 * k + 2]
            center = _circumcenter(a, mid, b)
            if center is None:
                segs.append({"start": a, "end": b, "center": None, "clockwise": False})
            else:
                segs.append({
                    "start": a, "end": b, "center": center,
                    "clockwise": _arc_is_clockwise(center, a, mid, b),
                })
        return segs

    def gear_center_arc(start, end, radius):
        mid = _short_arc_midpoint(gear_center, radius, start, end)
        return {
            "start": start, "end": end, "center": gear_center,
            "clockwise": _arc_is_clockwise(gear_center, start, mid, end),
            "use_gear_center": True,
        }

    segments = []
    for i in range(tooth_count):
        theta = base_rotation + i * tooth_pitch_angle
        next_theta = base_rotation + (i + 1) * tooth_pitch_angle

        right_flank = [to_world(p, theta) for p in flank_right]   # root → tip
        left_flank = [to_world(p, theta) for p in flank_left]     # root → tip

        # Right flank (root → tip), tip land, left flank (tip → root), root gap.
        segments.extend(flank_segments(right_flank))
        segments.append(gear_center_arc(right_flank[-1], left_flank[-1], addendum_radius))
        segments.extend(flank_segments(list(reversed(left_flank))))
        next_right_root = to_world(flank_right[0], next_theta)
        segments.append(gear_center_arc(left_flank[0], next_right_root, root_radius))

    # --- Build CAD geometry ---
    cad.with_sketch(plane_name)
    center = cad.point2d(center_x, center_y)

    # One shared vertex per segment start; segment k closes onto vertex k+1
    # (mod count), so the last root arc lands exactly on the first vertex — no
    # coincident/duplicate points, no degenerate closing edge.
    count = len(segments)
    point_refs = [cad.point2d(seg["start"][0], seg["start"][1]) for seg in segments]

    profile_edges = []
    for k, seg in enumerate(segments):
        start_ref = point_refs[k]
        end_ref = point_refs[(k + 1) % count]
        if seg["center"] is None:
            # Near-collinear samples: fall back to a straight segment.
            profile_edges.append(cad.line2d(start_ref, end_ref))
        elif seg.get("use_gear_center"):
            profile_edges.append(cad.arc2d(center, start_ref, end_ref, clockwise=seg["clockwise"]))
        else:
            cxy = seg["center"]
            arc_center = cad.point2d(cxy[0], cxy[1])
            profile_edges.append(cad.arc2d(arc_center, start_ref, end_ref, clockwise=seg["clockwise"]))

    bore_radius = max(module * 0.65, dedendum_radius * bore_ratio)
    bore = cad.circle2d(center, bore_radius)

    annulus_witness = (center_x + 0.5 * (bore_radius + root_radius), center_y)

    # The gear ring: the full ordered tooth profile as the outer loop
    # (segments are built consecutively, so the list is already the traversal
    # order), with the bore circle as a hole.
    region_ring = cad.region(
        loop=profile_edges,
        holes=[[bore]],
        inside=annulus_witness,
    )

    region_bore = cad.region(
        loop=[bore],
        inside=(center_x, center_y),
    )

    return {
        "center": center,
        "center_xy": (center_x, center_y),
        "profile_points": point_refs,
        "profile_edges": profile_edges,
        "bore": bore,
        "region_ring": region_ring,
        "region_bore": region_bore,
        "pitch_radius": pitch_radius,
        "addendum_radius": addendum_radius,
        "dedendum_radius": dedendum_radius,
        "root_radius": root_radius,
        "bore_radius": bore_radius,
    }


def gear_pair(
    center_x,
    center_y,
    teeth_a,
    teeth_b,
    module,
    pressure_angle_deg=20.0,
    plane_name="xy",
    rotation_a_deg=0.0,
    gap=0.0,
):
    """Create a gear pair on one sketch plane.

    gap: extra distance between the addendum circles (default 0 = meshing).
         Use gap > 0 to prevent tooth overlap on the same sketch plane.
    """
    if teeth_a < 8 or teeth_b < 8:
        raise ValueError("teeth_a and teeth_b must both be >= 8")
    if module <= 0:
        raise ValueError("module must be > 0")

    pitch_a = 0.5 * module * teeth_a
    pitch_b = 0.5 * module * teeth_b
    center_distance = pitch_a + pitch_b + gap

    gear_a = gear_outline(
        center_x=center_x,
        center_y=center_y,
        tooth_count=teeth_a,
        module=module,
        pressure_angle_deg=pressure_angle_deg,
        plane_name=plane_name,
        rotation_deg=rotation_a_deg,
    )

    rotation_b_deg = (180.0 / teeth_b) - rotation_a_deg * (teeth_a / float(teeth_b))

    gear_b = gear_outline(
        center_x=center_x + center_distance,
        center_y=center_y,
        tooth_count=teeth_b,
        module=module,
        pressure_angle_deg=pressure_angle_deg,
        plane_name=plane_name,
        rotation_deg=rotation_b_deg,
    )

    return {
        "gear_a": gear_a,
        "gear_b": gear_b,
        "center_distance": center_distance,
        "module": module,
    }
