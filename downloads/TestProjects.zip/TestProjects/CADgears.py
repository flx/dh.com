from flywheelcad import *
import math

cad = FlyWheelCAD()


def _rotate_xy(x, y, angle):
    c = math.cos(angle)
    s = math.sin(angle)
    return (x * c - y * s, x * s + y * c)


def _involute_point(base_radius, t):
    x = base_radius * (math.cos(t) + t * math.sin(t))
    y = base_radius * (math.sin(t) - t * math.cos(t))
    return (x, y)


def _append_unique(points, point, tol=1e-9):
    if points:
        px, py = points[-1]
        qx, qy = point
        if abs(px - qx) <= tol and abs(py - qy) <= tol:
            return
    points.append(point)


def _arc_points(radius, start_angle, end_angle, steps):
    while end_angle <= start_angle:
        end_angle += 2.0 * math.pi
    out = []
    for i in range(steps + 1):
        t = i / float(steps)
        angle = start_angle + (end_angle - start_angle) * t
        out.append((radius * math.cos(angle), radius * math.sin(angle)))
    return out


def gear_outline(
    center_x,
    center_y,
    tooth_count,
    module,
    pressure_angle_deg=20.0,
    addendum_coeff=1.0,
    dedendum_coeff=1.25,
    bore_ratio=0.28,
    plane_name="xy",
    rotation_deg=0.0,
    flank_steps=4,
    tip_arc_steps=2,
    root_arc_steps=2,
):
    """Create an involute spur gear sketch using line segments.

    Default step counts are tuned for reasonable fidelity with low element count.
    A 24-tooth gear produces ~(teeth * 10) line segments.
    """
    if tooth_count < 8:
        raise ValueError("tooth_count must be >= 8")
    if module <= 0:
        raise ValueError("module must be > 0")
    if bore_ratio <= 0 or bore_ratio >= 1:
        raise ValueError("bore_ratio must be in (0, 1)")

    pressure_angle = math.radians(pressure_angle_deg)
    pitch_radius = 0.5 * module * tooth_count
    base_radius = pitch_radius * math.cos(pressure_angle)
    addendum_radius = pitch_radius + addendum_coeff * module
    dedendum_radius = max(module * 0.55, pitch_radius - dedendum_coeff * module)

    if addendum_radius <= base_radius:
        raise ValueError("addendum radius must be > base radius")

    t_pitch = math.sqrt(max((pitch_radius / base_radius) ** 2 - 1.0, 0.0))
    involute_pitch_angle = t_pitch - math.atan(t_pitch)
    half_tooth_angle = math.pi / (2.0 * tooth_count)
    involute_rotation = -(half_tooth_angle + involute_pitch_angle)

    r_start = max(base_radius, dedendum_radius)
    root_radius = r_start
    t_start = math.sqrt(max((r_start / base_radius) ** 2 - 1.0, 0.0))
    t_tip = math.sqrt(max((addendum_radius / base_radius) ** 2 - 1.0, 0.0))

    t_values = []
    for i in range(flank_steps + 1):
        alpha = i / float(flank_steps)
        t_values.append(t_start + (t_tip - t_start) * alpha)

    flank_a = []
    for t in t_values:
        x, y = _involute_point(base_radius, t)
        flank_a.append(_rotate_xy(x, y, involute_rotation))
    flank_b = [(x, -y) for (x, y) in flank_a]

    a_root_angle = math.atan2(flank_a[0][1], flank_a[0][0])
    b_root_angle = math.atan2(flank_b[0][1], flank_b[0][0])
    if a_root_angle <= b_root_angle:
        flank_right = flank_a
        flank_left = flank_b
    else:
        flank_right = flank_b
        flank_left = flank_a

    right_tip_angle = math.atan2(flank_right[-1][1], flank_right[-1][0])
    left_tip_angle = math.atan2(flank_left[-1][1], flank_left[-1][0])
    left_root_angle = math.atan2(flank_left[0][1], flank_left[0][0])
    right_root_angle = math.atan2(flank_right[0][1], flank_right[0][0])

    tooth_pitch_angle = 2.0 * math.pi / tooth_count
    base_rotation = math.radians(rotation_deg)

    boundary = []
    for i in range(tooth_count):
        theta = base_rotation + i * tooth_pitch_angle

        for x, y in flank_right:
            rx, ry = _rotate_xy(x, y, theta)
            _append_unique(boundary, (rx, ry))

        tip_arc = _arc_points(addendum_radius, theta + right_tip_angle, theta + left_tip_angle, tip_arc_steps)
        for pt in tip_arc[1:]:
            _append_unique(boundary, pt)

        for x, y in reversed(flank_left):
            rx, ry = _rotate_xy(x, y, theta)
            _append_unique(boundary, (rx, ry))

        next_theta = base_rotation + (i + 1) * tooth_pitch_angle
        root_arc = _arc_points(root_radius, theta + left_root_angle, next_theta + right_root_angle, root_arc_steps)
        for pt in root_arc[1:]:
            _append_unique(boundary, pt)

    if boundary:
        first = boundary[0]
        _append_unique(boundary, first)
        if len(boundary) > 1 and boundary[-1] == first:
            boundary.pop()

    # --- Build CAD geometry ---
    cad.with_sketch(plane_name)
    center = cad.point2d(center_x, center_y)

    point_refs = []
    for x, y in boundary:
        point_refs.append(cad.point2d(center_x + x, center_y + y))

    profile_edges = []
    count = len(point_refs)
    for i in range(count):
        profile_edges.append(cad.line2d(point_refs[i], point_refs[(i + 1) % count]))

    bore_radius = max(module * 0.65, dedendum_radius * bore_ratio)
    bore = cad.circle2d(center, bore_radius)

    edge_a = profile_edges[0]
    edge_b = profile_edges[count // 3]
    edge_c = profile_edges[(2 * count) // 3]

    annulus_witness = (center_x + 0.5 * (bore_radius + root_radius), center_y)

    region_ring = cad.region(
        required=[bore, edge_a, edge_b, edge_c],
        witness=[annulus_witness],
    )

    region_bore = cad.region(
        required=[bore],
        witness=[(center_x, center_y)],
    )

    return {
        "center": center,
        "center_xy": (center_x, center_y),
        "profile_points": point_refs,
        "profile_edges": profile_edges,
        "bore": bore,
        "region_ring": region_ring,
        "region_bore": region_bore,
        "pitch_radius": pitch_radius,
        "addendum_radius": addendum_radius,
        "dedendum_radius": dedendum_radius,
        "root_radius": root_radius,
        "bore_radius": bore_radius,
    }


def gear_pair(
    center_x,
    center_y,
    teeth_a,
    teeth_b,
    module,
    pressure_angle_deg=20.0,
    plane_name="xy",
    rotation_a_deg=0.0,
    gap=0.0,
):
    """Create a gear pair on one sketch plane.

    gap: extra distance between the addendum circles (default 0 = meshing).
         Use gap > 0 to prevent tooth overlap on the same sketch plane.
    """
    if teeth_a < 8 or teeth_b < 8:
        raise ValueError("teeth_a and teeth_b must both be >= 8")
    if module <= 0:
        raise ValueError("module must be > 0")

    pitch_a = 0.5 * module * teeth_a
    pitch_b = 0.5 * module * teeth_b
    center_distance = pitch_a + pitch_b + gap

    gear_a = gear_outline(
        center_x=center_x,
        center_y=center_y,
        tooth_count=teeth_a,
        module=module,
        pressure_angle_deg=pressure_angle_deg,
        plane_name=plane_name,
        rotation_deg=rotation_a_deg,
    )

    rotation_b_deg = (180.0 / teeth_b) - rotation_a_deg * (teeth_a / float(teeth_b))

    gear_b = gear_outline(
        center_x=center_x + center_distance,
        center_y=center_y,
        tooth_count=teeth_b,
        module=module,
        pressure_angle_deg=pressure_angle_deg,
        plane_name=plane_name,
        rotation_deg=rotation_b_deg,
    )

    return {
        "gear_a": gear_a,
        "gear_b": gear_b,
        "center_distance": center_distance,
        "module": module,
    }
