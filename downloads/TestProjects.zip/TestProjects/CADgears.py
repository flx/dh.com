from flywheelcad import *
import math

cad = FlyWheelCAD()


def gear_outline(center_x, center_y, tooth_count, module,
                 tooth_height_ratio=1.0, bore_ratio=0.25,
                 plane_name="xy", rotation_deg=0.0):
    """Create a simple gear-like closed spline and a bore circle.

    This is a lightweight sketching profile (alternating root/tip radii),
    not an involute-accurate manufacturing gear.
    """
    if tooth_count < 6:
        raise ValueError("tooth_count must be >= 6")
    if module <= 0:
        raise ValueError("module must be > 0")

    cad.with_sketch(plane_name)

    pitch_radius = 0.5 * module * tooth_count
    addendum = module * tooth_height_ratio
    dedendum = 1.15 * module * tooth_height_ratio
    outer_radius = pitch_radius + addendum
    root_radius = max(module * 0.8, pitch_radius - dedendum)
    bore_radius = max(module * 0.5, root_radius * bore_ratio)
    profile_probe_radius = bore_radius + 0.55 * (root_radius - bore_radius)

    center = cad.point2d(center_x, center_y)

    points = []
    tooth_step = math.pi / float(tooth_count)
    base = math.radians(rotation_deg)
    for i in range(2 * tooth_count):
        r = outer_radius if i % 2 == 0 else root_radius
        angle = base + i * tooth_step
        x = center_x + r * math.cos(angle)
        y = center_y + r * math.sin(angle)
        points.append(cad.point2d(x, y))

    profile_edges = []
    for i in range(len(points)):
        profile_edges.append(cad.line2d(points[i], points[(i + 1) % len(points)]))
    bore = cad.circle2d(center, bore_radius)

    return {
        "center": center,
        "profile": profile_edges,
        "bore": bore,
        "pitch_radius": pitch_radius,
        "outer_radius": outer_radius,
        "root_radius": root_radius,
        "bore_radius": bore_radius,
        # Point guaranteed to be in the annulus between bore and tooth root.
        # Use this for area selection when extruding the profile.
        "profile_inside": (center_x + profile_probe_radius, center_y),
        # Point guaranteed to be inside the bore circle.
        "bore_inside": (center_x, center_y),
    }


def gear_pair(center_x, center_y, teeth_a, teeth_b, module,
              plane_name="xy", rotation_a_deg=0.0):
    """Create a meshing gear-like pair on one sketch plane."""
    if teeth_a < 6 or teeth_b < 6:
        raise ValueError("teeth_a and teeth_b must be >= 6")

    pitch_a = 0.5 * module * teeth_a
    pitch_b = 0.5 * module * teeth_b
    center_distance = pitch_a + pitch_b

    gear_a = gear_outline(
        center_x=center_x,
        center_y=center_y,
        tooth_count=teeth_a,
        module=module,
        plane_name=plane_name,
        rotation_deg=rotation_a_deg,
    )

    # Approximate opposite rotation by tooth ratio
    rotation_b = rotation_a_deg - (360.0 * teeth_a / float(teeth_b))
    gear_b = gear_outline(
        center_x=center_x + center_distance,
        center_y=center_y,
        tooth_count=teeth_b,
        module=module,
        plane_name=plane_name,
        rotation_deg=rotation_b,
    )

    return {
        "gear_a": gear_a,
        "gear_b": gear_b,
        "center_distance": center_distance,
    }
