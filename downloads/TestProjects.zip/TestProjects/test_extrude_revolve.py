from flywheelcad import *

cad = FlyWheelCAD()

# Part A — Extruded plate with circular hole

cad.with_sketch("xy")

# Rectangle 40x25 centered at (-40, 0)
pa1 = cad.point2d(-60, -12.5)
pa2 = cad.point2d(-20, -12.5)
pa3 = cad.point2d(-20, 12.5)
pa4 = cad.point2d(-60, 12.5)
la1 = cad.line2d(pa1, pa2)
la2 = cad.line2d(pa2, pa3)
la3 = cad.line2d(pa3, pa4)
la4 = cad.line2d(pa4, pa1)
cad.horizontal(la1)
cad.horizontal(la3)
cad.vertical(la2)
cad.vertical(la4)
cad.length(la1, 40)
cad.length(la2, 25)

# Hole at center of rectangle
hole_center = cad.point2d(-40, 0)
hole = cad.circle2d(hole_center, 8)
cad.radius(hole, 8)

# Extrude plate (annular region between rectangle and circle)
plate_region = cad.region(
    required=[la1, la2, la3, la4, hole],
    witness=[(-50, 0)],
)
plate = cad.extrude("xy", plate_region, 10)

# Part B — Revolved semicircle at 35 degrees

cad.with_sketch("xy")

# Vertical construction line as axis at x=40
ax_bot = cad.point2d(20, -15)
ax_top = cad.point2d(20, 15)
axis = cad.line2d(ax_bot, ax_top, construction=True)
cad.vertical(axis)
cad.length(axis, 30)

# Semicircle profile: arc + closing line
arc_top = cad.point2d(40, 12)
arc_bot = cad.point2d(40, -12)
arc_mid = cad.point2d(52, 0)
profile_arc = cad.arc2d(cad.point2d(40, 0), arc_top, arc_bot, clockwise=True)
closing = cad.line2d(arc_bot, arc_top)
cad.vertical(closing)

# Revolve around axis at 35 degrees
rev_region = cad.region(
    required=[profile_arc, closing],
    witness=[(48, 0)],
)
rev_body = cad.revolve("xy", rev_region, axis, 75)
