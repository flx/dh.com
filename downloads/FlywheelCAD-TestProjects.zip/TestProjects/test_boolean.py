from flywheelcad import *

cad = FlywheelCAD()

# Box minus cylinder: a rectangular block with a cylindrical hole through it.

cad.with_sketch("xy")

# Rectangle 30x20, centered at origin
p1 = cad.point2d(-15, -10)
p2 = cad.point2d(15, -10)
p3 = cad.point2d(15, 10)
p4 = cad.point2d(-15, 10)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 30)
cad.length(l2, 20)

box_region = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))
box = cad.extrude("xy", box_region, 15)

# Circle centered at origin, radius 6
cc = cad.point2d(0, 0)
circ = cad.circle2d(cc, 6)
cad.radius(circ, 6)

circ_region = cad.region(loop=[circ], inside=(0, 0))
cyl = cad.extrude("xy", circ_region, 20)

# Boolean difference: box - cylinder
result = cad.bool_difference(box, cyl, quality="ultra")

