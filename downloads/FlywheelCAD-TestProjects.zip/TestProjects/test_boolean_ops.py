from flywheelcad import *

cad = FlywheelCAD()

# Demonstrates all three boolean operations, reusing the same input bodies.

cad.with_sketch("xy")

# --- Body A: box at center ---
pa1 = cad.point2d(-12, -12)
pa2 = cad.point2d(12, -12)
pa3 = cad.point2d(12, 12)
pa4 = cad.point2d(-12, 12)
la1 = cad.line2d(pa1, pa2)
la2 = cad.line2d(pa2, pa3)
la3 = cad.line2d(pa3, pa4)
la4 = cad.line2d(pa4, pa1)
cad.horizontal(la1)
cad.horizontal(la3)
cad.vertical(la2)
cad.vertical(la4)
cad.length(la1, 24)
cad.length(la2, 24)

region_a = cad.region(loop=[la1, la2, la3, la4], inside=(0, 0))
box_a = cad.extrude("xy", region_a, 20)

# --- Body B: offset box overlapping A ---
pb1 = cad.point2d(6, 6)
pb2 = cad.point2d(30, 6)
pb3 = cad.point2d(30, 30)
pb4 = cad.point2d(6, 30)
lb1 = cad.line2d(pb1, pb2)
lb2 = cad.line2d(pb2, pb3)
lb3 = cad.line2d(pb3, pb4)
lb4 = cad.line2d(pb4, pb1)
cad.horizontal(lb1)
cad.horizontal(lb3)
cad.vertical(lb2)
cad.vertical(lb4)
cad.length(lb1, 24)
cad.length(lb2, 24)

region_b = cad.region(loop=[lb1, lb2, lb3, lb4], inside=(18, 18))
box_b = cad.extrude("xy", region_b, 20)

# --- Body C: cylinder ---
cc = cad.point2d(6, 6)
ccirc = cad.circle2d(cc, 5)
cad.radius(ccirc, 5)
region_c = cad.region(loop=[ccirc], inside=(6, 6))
cyl = cad.extrude("xy", region_c, 25)

# All three booleans reuse the same box_a and box_b
united = cad.bool_union(box_a, box_b)
intersected = cad.bool_intersection(box_a, box_b)
subtracted = cad.bool_difference(united, cyl, quality="ultra")