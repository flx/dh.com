from flywheelcad import *

cad = FlywheelCAD()

# Demonstrates the extrude `offset` parameter.
#   offset = 0  -> body starts on the sketch plane (the default)
#   offset > 0  -> the whole body is lifted along the plane normal
# When a body floats off the sketch plane its BOTTOM face becomes a real,
# selectable surface (topology points b0, b1, b2, ...), so you can build a new
# sketch plane on it — which you can't do when the bottom sits on the plane.

cad.with_sketch("xy")

# 30 x 20 plate centered at the origin
p1 = cad.point2d(-15, -10)
p2 = cad.point2d(15, -10)
p3 = cad.point2d(15, 10)
p4 = cad.point2d(-15, 10)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 30)
cad.length(l2, 20)

plate_region = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))

# Floating plate: 12 thick, lifted 15 above the XY plane.
plate = cad.extrude("xy", plate_region, 12, offset=15)

# Build a sketch plane on the now-selectable BOTTOM face (the b* points)...
bottom = cad.create_sketch_plane(plate.b0, plate.b1, plate.b2, name="plate_bottom")

# ...and grow a peg from it to show the bottom face is fully usable.
cad.with_sketch(bottom)
peg_center = cad.point2d(0, 0)
peg = cad.circle2d(peg_center, 5)
cad.radius(peg, 5)
peg_region = cad.region(loop=[peg], inside=(0, 0))
cad.extrude(bottom, peg_region, 6)
