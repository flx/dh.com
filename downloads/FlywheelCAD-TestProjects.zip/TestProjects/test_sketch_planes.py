from flywheelcad import *

cad = FlywheelCAD()

# 1) XY plane: constrained rectangle → extruded box with topology points

cad.with_sketch("xy")
p1 = cad.point2d(-15, -10)
p2 = cad.point2d(15, -10)
p3 = cad.point2d(15, 10)
p4 = cad.point2d(-15, 10)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)
cad.horizontal(l1)
cad.horizontal(l3)
cad.vertical(l2)
cad.vertical(l4)
cad.length(l1, 30)
cad.length(l2, 20)

box_region = cad.region(loop=[l1, l2, l3, l4], inside=(0, 0))
box = cad.extrude("xy", box_region, 12)

# 2) YZ plane: draw a line

cad.with_sketch("yz")
py1 = cad.point2d(0, 0)
py2 = cad.point2d(25, 15)
lyz = cad.line2d(py1, py2)

# 3) Create oblique custom plane from 3 box topology points

oblique = cad.create_sketch_plane(box.v0, box.v1, box.v2)

# 4) Draw a circle on the custom plane and extrude it

cad.with_sketch(oblique)
oc = cad.point2d(0, 0)
ocirc = cad.circle2d(oc, 5)
cad.radius(ocirc, 5)

circ_region = cad.region(loop=[ocirc], inside=(0, 0))
cyl = cad.extrude(oblique, circ_region, 8)
