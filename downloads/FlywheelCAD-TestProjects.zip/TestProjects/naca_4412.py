"""
naca_4412.py — NACA 4412 airfoil profile generator (support module).

Pure geometry helper: returns a closed list of (x, y) outline points for a
NACA 4412 airfoil. No FlywheelCAD dependency — the main script turns the points
into sketch geometry.

NACA 4412:  m = 4% camber, p = 40% camber position, t = 12% thickness.
Reference: http://airfoiltools.com/airfoil/details?airfoil=naca4412-il
"""

import math

_M = 0.04   # max camber (fraction of chord)
_P = 0.40   # chordwise position of max camber
_T = 0.12   # max thickness (fraction of chord)


def _camber(x):
    """Mean-camber-line height at normalized chord position x in [0, 1]."""
    if x < _P:
        return (_M / _P**2) * (2 * _P * x - x * x)
    return (_M / (1 - _P)**2) * ((1 - 2 * _P) + 2 * _P * x - x * x)


def _camber_slope(x):
    if x < _P:
        return (2 * _M / _P**2) * (_P - x)
    return (2 * _M / (1 - _P)**2) * (_P - x)


def _thickness(x):
    """Half-thickness at x. The -0.1036 x^4 term closes the trailing edge."""
    return 5 * _T * (0.2969 * math.sqrt(x) - 0.1260 * x
                     - 0.3516 * x * x + 0.2843 * x**3 - 0.1036 * x**4)


def camber_at(fraction):
    """Mean-camber height at a chord fraction (normalized). The default spar
    origin is the camber point at 30% chord (the max-thickness station)."""
    return _camber(fraction)


def naca_4412(chord=1.0, aoa_deg=0.0, origin=None, n=24, te_thickness=0.0):
    """A closed NACA 4412 outline as a list of (x, y) points.

    chord    : chord length, in model units.
    aoa_deg  : angle of attack. Positive pitches the leading edge up (the
               attitude that produces lift); negative pitches it down.
    origin   : (ox, oy) in chord-normalized coordinates, placed at local (0, 0)
               and used as the rotation centre. Default: the camber point at
               30% chord — the max-thickness location where a spar would sit —
               so every plane can be pinned through the spar line.
    n        : cosine-spaced samples per surface (higher = smoother).
    te_thickness : trailing-edge thickness as a FRACTION of chord. 0 (default)
               closes the TE to a sharp point; a positive value blunts it to a
               flat TE of this thickness. The opening is linear along the chord,
               so it sets a floor on the section thickness without touching the
               (still sharp) leading edge. Use this so the thin TE wedge never
               tapers below the mesh grid pitch — a sub-cell wedge makes the
               SDF/dual-contouring surface stair-step into a jagged edge.

    Points are ordered as a single closed loop (trailing edge → upper surface →
    leading edge → lower surface) with no duplicated endpoints, ready for a
    closed spline. A blunt TE contributes two distinct points (the flat TE face).
    """
    if origin is None:
        origin = (0.30, _camber(0.30))
    ox, oy = origin

    # Half the TE thickness, added linearly along the chord so the surfaces meet
    # at a flat face of `te_thickness` instead of converging to a sharp point.
    te_half = 0.5 * te_thickness

    # Cosine spacing concentrates samples at the leading and trailing edges.
    xs = [0.5 * (1 - math.cos(math.pi * i / n)) for i in range(n + 1)]

    upper, lower = [], []
    for x in xs:
        yc = _camber(x)
        yt = _thickness(x) + te_half * x
        theta = math.atan(_camber_slope(x))
        upper.append((x - yt * math.sin(theta), yc + yt * math.cos(theta)))
        lower.append((x + yt * math.sin(theta), yc - yt * math.cos(theta)))

    # TE → upper → LE → lower. The leading edge is always a single shared point
    # (drop lower[0]). The trailing edge is shared only when sharp; a blunt TE
    # keeps lower's last point so the closing segment forms the flat TE face.
    if te_thickness > 0.0:
        loop = list(reversed(upper)) + lower[1:]
    else:
        loop = list(reversed(upper)) + lower[1:-1]

    a = math.radians(aoa_deg)
    cos_a, sin_a = math.cos(a), math.sin(a)
    pts = []
    for (x, y) in loop:
        tx = (x - ox) * chord
        ty = (y - oy) * chord
        # Rotate by -aoa about the origin so +aoa raises the leading edge.
        rx = tx * cos_a + ty * sin_a
        ry = -tx * sin_a + ty * cos_a
        pts.append((rx, ry))
    return pts
