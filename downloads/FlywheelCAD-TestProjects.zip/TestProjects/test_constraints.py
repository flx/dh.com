from flywheelcad import *

cad = FlywheelCAD()

# A reference sketch for the constraint solver: every constraint type, each on
# its own small, recognizable figure so the effect is easy to see. The figures
# are spaced apart and independent, so nothing is over-constrained.

cad.with_sketch("xy")

# ---------------------------------------------------------------------------
# 1) Parametric square  —  horizontal, vertical, length(variable), equallines
# ---------------------------------------------------------------------------
side = cad.variable(30, fixed=True)        # a driving parameter

a1 = cad.point2d(0, 0)
a2 = cad.point2d(30, 0)
a3 = cad.point2d(30, 30)
a4 = cad.point2d(0, 30)
sq_bottom = cad.line2d(a1, a2)
sq_right = cad.line2d(a2, a3)
sq_top = cad.line2d(a3, a4)
sq_left = cad.line2d(a4, a1)
cad.horizontal(sq_bottom)
cad.horizontal(sq_top)
cad.vertical(sq_right)
cad.vertical(sq_left)
cad.length(sq_bottom, side)                # width driven by `side`
cad.equallines(sq_bottom, sq_right)        # equal sides -> square

# ---------------------------------------------------------------------------
# 2) Right triangle 3-4-5  —  perpendicular, distance(point, point)
# ---------------------------------------------------------------------------
t1 = cad.point2d(60, 0)
t2 = cad.point2d(75, 0)
t3 = cad.point2d(60, 20)
tri_a = cad.line2d(t1, t2)
tri_b = cad.line2d(t1, t3)
tri_hyp = cad.line2d(t2, t3)
cad.perpendicular(tri_a, tri_b)
cad.distance(t1, t2, 15)
cad.distance(t1, t3, 20)
cad.distance(t2, t3, 25)                   # forces the 3-4-5 ratio

# ---------------------------------------------------------------------------
# 3) Rails  —  parallel, collinear, point-on-line, point-line-distance
# ---------------------------------------------------------------------------
r1 = cad.point2d(0, 55)
r2 = cad.point2d(40, 55)
rail = cad.line2d(r1, r2)
cad.horizontal(rail)
cad.length(rail, 40)

r3 = cad.point2d(50, 55)
r4 = cad.point2d(80, 55)
rail_ext = cad.line2d(r3, r4)
cad.collinear(rail, rail_ext)              # same infinite line as `rail`

r5 = cad.point2d(0, 72)
r6 = cad.point2d(40, 70)
rail_par = cad.line2d(r5, r6)
cad.parallel(rail, rail_par)               # runs parallel to `rail`

on_rail = cad.point2d(20, 55)
cad.pointlinecoincident(on_rail, rail)     # pinned onto the rail
above_rail = cad.point2d(20, 67)
cad.pointlinedistance(above_rail, rail, 12)  # held 12 above the rail

# ---------------------------------------------------------------------------
# 4) Angle wedge  —  angle(line, line, degrees)
# ---------------------------------------------------------------------------
v = cad.point2d(100, 0)
ve = cad.point2d(130, 0)
va = cad.point2d(126, 15)
wedge_base = cad.line2d(v, ve)
wedge_arm = cad.line2d(v, va)
cad.horizontal(wedge_base)
cad.angle(wedge_base, wedge_arm, 30)       # 30 degrees between the two arms

# ---------------------------------------------------------------------------
# 5) Circle family  —  concentric, radius, equalradius, point-on-circle,
#                      circle-tangent-line, circle-tangent-circle
# ---------------------------------------------------------------------------
hub = cad.point2d(-50, 60)
inner = cad.circle2d(hub, 8)
outer = cad.circle2d(hub, 16)
cad.concentric(inner, outer)
cad.radius(inner, 8)

twin = cad.circle2d(cad.point2d(-90, 60), 8)
cad.equalradius(inner, twin)               # same radius as `inner`

on_outer = cad.point2d(-34, 60)
cad.pointoncircle(on_outer, outer)         # pinned onto `outer`

tan_l1 = cad.point2d(-72, 44)
tan_l2 = cad.point2d(-28, 44)
ground = cad.line2d(tan_l1, tan_l2)
cad.horizontal(ground)
ground_anchor = cad.circletangentline(inner, ground)   # `inner` rests tangent on the line

satellite = cad.circle2d(cad.point2d(-50, 84), 5)
cad.circletangentcircle(outer, satellite)  # `satellite` kisses `outer`

# ---------------------------------------------------------------------------
# 6) Symmetry  —  symmetryline(p1, p2, axis)
# ---------------------------------------------------------------------------
ax_b = cad.point2d(50, -30)
ax_t = cad.point2d(50, -10)
mirror_axis = cad.line2d(ax_b, ax_t, construction=True)
cad.vertical(mirror_axis)
sym_left = cad.point2d(42, -20)
sym_right = cad.point2d(58, -20)
cad.symmetryline(p1=sym_left, p2=sym_right, symmetryLine=mirror_axis)

# ---------------------------------------------------------------------------
# 7) Ellipse  —  point-on-ellipse, ellipse-tangent-line
# ---------------------------------------------------------------------------
ef1 = cad.point2d(-90, -20)
ef2 = cad.point2d(-70, -20)
ep = cad.point2d(-80, -12)
ell = cad.ellipse2d(ef1, ef2, ep)
on_ell = cad.point2d(-80, -28)
cad.pointonellipse(on_ell, ell)
et1 = cad.point2d(-96, -32)
et2 = cad.point2d(-64, -32)
ell_tan = cad.line2d(et1, et2)
ell_anchor = cad.ellipsetangentline(ell, ell_tan)

# ---------------------------------------------------------------------------
# 8) Spline tangent  —  splinetangentline (line tangent at the shared endpoint)
# ---------------------------------------------------------------------------
s1 = cad.point2d(90, -30)
s2 = cad.point2d(100, -42)
s3 = cad.point2d(110, -30)
curve = cad.spline2d([s1, s2, s3])
st1 = cad.point2d(110, -30)
st2 = cad.point2d(126, -30)
spline_tan = cad.line2d(st1, st2)
cad.splinetangentline(curve, spline_tan)

# ---------------------------------------------------------------------------
# 9) Merge points  —  weld two separate lines into a shared corner
# ---------------------------------------------------------------------------
m1 = cad.point2d(150, 0)
m2 = cad.point2d(170, 0)
arm_h = cad.line2d(m1, m2)
cad.horizontal(arm_h)
m3 = cad.point2d(170, 0)
m4 = cad.point2d(170, 20)
arm_v = cad.line2d(m3, m4)
cad.vertical(arm_v)
cad.merge_points(m3, m2)                    # the two arms now share one corner

# Solve everything together.
cad.ensure_convergence()
