from flywheelcad import *

cad = FlywheelCAD()

# Symmetric house outline with window, door, and decorative elements.
# Right half drawn explicitly, then mirrored across a vertical construction line.

cad.with_sketch("xy")

# Symmetry axis: vertical construction line at x=0
sym_bot = cad.point2d(0, 0)
sym_top = cad.point2d(0, 40)
sym = cad.line2d(sym_bot, sym_top, construction=True)
cad.vertical(sym)

# --- Right half of house ---

# Base: origin to bottom-right
p_br = cad.point2d(20, 0)
base_r = cad.line2d(sym_bot, p_br)
cad.horizontal(base_r)
cad.length(base_r, 20)

# Right wall: bottom-right up to eave
p_eave = cad.point2d(20, 25)
wall_r = cad.line2d(p_br, p_eave)
cad.vertical(wall_r)
cad.length(wall_r, 25)

# Roof slope: eave to peak on axis (reuse sym_top as peak)
cad.update({sym_top: {"y": 35}})
roof_r = cad.line2d(p_eave, sym_top)

# --- Window (right side) ---
pw1 = cad.point2d(8, 10)
pw2 = cad.point2d(16, 10)
pw3 = cad.point2d(16, 18)
pw4 = cad.point2d(8, 18)
wl1 = cad.line2d(pw1, pw2)
wl2 = cad.line2d(pw2, pw3)
wl3 = cad.line2d(pw3, pw4)
wl4 = cad.line2d(pw4, pw1)
cad.horizontal(wl1)
cad.horizontal(wl3)
cad.vertical(wl2)
cad.vertical(wl4)
cad.length(wl1, 8)
cad.length(wl2, 8)

# --- Half-door at center bottom (right side of door) ---
pd1 = cad.point2d(0, 12)
pd2 = cad.point2d(6, 12)
pd3 = cad.point2d(6, 0)
door_top = cad.line2d(pd1, pd2)
door_side = cad.line2d(pd2, pd3)
door_bot = cad.line2d(pd3, sym_bot)
cad.horizontal(door_top)
cad.vertical(door_side)
cad.horizontal(door_bot)
cad.length(door_top, 6)
cad.length(door_side, 12)

# Door handle: small circle
handle_center = cad.point2d(4.5, 6)
handle = cad.circle2d(handle_center, 0.8)

# Decorative roof window: ellipse
ef1 = cad.point2d(-3, 28)
ef2 = cad.point2d(3, 28)
ep = cad.point2d(0, 30.5)
roof_window = cad.ellipse2d(ef1, ef2, ep)

# --- Mirror right half to create left half ---
cad.mirror(
    [base_r, wall_r, roof_r, wl1, wl2, wl3, wl4],
    symmetry_line=sym,
)
