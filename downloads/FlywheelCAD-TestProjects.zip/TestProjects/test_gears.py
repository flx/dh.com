from flywheelcad import *
from CADgears import gear_outline, gear_pair, helix_twist_degrees

cad = FlywheelCAD()

# 1) Single involute gear — extruded
single = gear_outline(
    center_x=-220,
    center_y=0,
    tooth_count=24,
    module=5.0,
    pressure_angle_deg=20.0,
    plane_name="xy",
    rotation_deg=2.0,
)
single_body = cad.extrude("xy", single["region_ring"], 24, quality="high")

# 2) Meshing involute pair — extruded
pair = gear_pair(
    center_x=140,
    center_y=0,
    teeth_a=18,
    teeth_b=30,
    module=4.0,
    pressure_angle_deg=20.0,
    plane_name="xy",
    rotation_a_deg=6.0,
    gap=10.0,
)

gear_a_body = cad.extrude("xy", pair["gear_a"]["region_ring"], 18, quality="standard")
gear_b_body = cad.extrude("xy", pair["gear_b"]["region_ring"], 14, quality="standard")

# 3) Boolean keyway cut on gear A
cad.with_sketch("xy")
cx, cy = pair["gear_a"]["center_xy"]
slot_p1 = cad.point2d(cx - 14, cy - 6)
slot_p2 = cad.point2d(cx + 14, cy - 6)
slot_p3 = cad.point2d(cx + 14, cy + 6)
slot_p4 = cad.point2d(cx - 14, cy + 6)
slot_l1 = cad.line2d(slot_p1, slot_p2)
slot_l2 = cad.line2d(slot_p2, slot_p3)
slot_l3 = cad.line2d(slot_p3, slot_p4)
slot_l4 = cad.line2d(slot_p4, slot_p1)
slot_region = cad.region(loop=[slot_l1, slot_l2, slot_l3, slot_l4], inside=(cx, cy))
# Extrude the keyway symmetrically so it over-spans the gear on BOTH ends
# (gear_a is 0..18; this spans -22..+22). A one-sided 0..22 cut left the slot's
# bottom cap coincident with the gear's bottom face at Z=0, which the SDF
# difference can't cleanly open — leaving a thin membrane so the slot didn't
# punch all the way through. Over-spanning both faces leaves only the slot's
# side walls as cut surfaces.
slot_body = cad.extrude("xy", slot_region, 44, direction="symmetric", quality="high")
gear_a_keyed = cad.bool_difference(gear_a_body, slot_body, quality="high")

# 4) Helical involute gear — same 2D profile, but the extrude twists the
# cross-section along the height to set a 20° helix angle at the pitch radius.
helical = gear_outline(
    center_x=-220,
    center_y=260,
    tooth_count=24,
    module=5.0,
    pressure_angle_deg=20.0,
    plane_name="xy",
)
face_width = 30
helix_twist = helix_twist_degrees(face_width, helix_angle_deg=20.0,
                                  pitch_radius=helical["pitch_radius"])
helical_body = cad.extrude(
    "xy", helical["region_ring"], face_width,
    twist=helix_twist, twist_center=helical["center_xy"], quality="standard",
)
