from flywheelcad import *

cad = FlywheelCAD()

# Demonstrates trim operations on lines and circles.

cad.with_sketch("xy")

# --- Trim a line at intersection ---
# Two crossing lines; trim one at the crossing point.
p1 = cad.point2d(0, 0)
p2 = cad.point2d(40, 0)
l_horiz = cad.line2d(p1, p2)
cad.horizontal(l_horiz)

p3 = cad.point2d(20, -15)
p4 = cad.point2d(20, 15)
l_vert = cad.line2d(p3, p4)
cad.vertical(l_vert)

# Trim the horizontal line near its right end (keeps left segment)
l_horiz, l_horiz_1 = cad.trim(l_horiz, near=(35, 0))

# --- Trim a circle into arcs ---
c_center = cad.point2d(0, 40)
circ = cad.circle2d(c_center, 12)

# A line crossing through the circle
cp1 = cad.point2d(-20, 40)
cp2 = cad.point2d(20, 40)
c_line = cad.line2d(cp1, cp2)
cad.horizontal(c_line)

# Trim the circle near the top → produces two arcs
circ, circ_1 = cad.trim(circ, near=(0, 52))
