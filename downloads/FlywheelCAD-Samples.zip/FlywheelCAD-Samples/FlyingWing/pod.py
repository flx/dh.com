"""
pod.py — center-body with electric pusher motor and prop.

A slim drop-shaped blister (radio gear up front), truncated aft into a
shoulder that carries the motor can, with a spinner and a two-blade PUSHER
prop behind the wing's center trailing edge. The blades are twisted extrudes
(~28° washout root to tip), spanning ±Z so they clear the wing.

One revolved body forms pod + motor can; the spinner and each blade are
separate exported bodies.
"""

from flywheelcad import *
import math

cad = FlywheelCAD()


def _drop_radius(x):
    """Normalized drop-body radius at x in [0, 1]: the NACA 4-digit
    half-thickness bracket, scaled so the peak (at x ~ 0.30) is 1.0."""
    b = (0.2969 * math.sqrt(x) - 0.1260 * x - 0.3516 * x * x
         + 0.2843 * x ** 3 - 0.1036 * x ** 4)
    return b / 0.1001


with cad.component("pod"):
    # ---- pod + motor can: one revolve about the fore-aft axis ----------
    # Drop silhouette over a virtual length, truncated at the motor face.
    cad.with_sketch("xy")
    radius = 48.0
    virtual_len = 760.0          # drop shape it is cut from
    cut = 640.0                  # truncation (motor face) station
    motor_r, motor_end = 19.0, 700.0

    n = 12
    pts = []
    for i in range(n + 1):
        x = 0.5 * (1 - math.cos(math.pi * i / n)) * (cut / virtual_len)
        pts.append((x * virtual_len, max(radius * _drop_radius(x), 0.001)))
    p_nose = cad.point2d(0, 0)
    spline_pts = [p_nose] + [cad.point2d(px, py) for (px, py) in pts[1:]]
    silhouette = cad.spline2d(spline_pts, closed=False)

    cut_r = pts[-1][1]
    m1 = cad.point2d(cut, motor_r)               # motor shoulder
    m2 = cad.point2d(motor_end, motor_r)         # motor can
    m3 = cad.point2d(motor_end, 0)               # aft face on axis
    lm0 = cad.line2d(spline_pts[-1], m1)
    lm1 = cad.line2d(m1, m2)
    lm2 = cad.line2d(m2, m3)
    axis = cad.line2d(m3, p_nose)

    body = cad.revolve("xy",
                       cad.region(loop=[silhouette, lm0, lm1, lm2, axis],
                                  inside=(200.0, 20.0)),
                       axis, 360)
    cad.set_color(body, "#B71C1C", finish="glossy")   # signal red
    cad.export(body)

    # ---- spinner --------------------------------------------------------
    cad.with_sketch("xy")
    t0 = cad.point2d(702, 0)
    t1 = cad.point2d(702, 15)
    t2 = cad.point2d(736, 4)
    t3 = cad.point2d(742, 0)
    s0 = cad.line2d(t0, t1)
    s1 = cad.line2d(t1, t2)
    s2 = cad.line2d(t2, t3)
    saxis = cad.line2d(t3, t0)
    spinner = cad.revolve("xy",
                          cad.region(loop=[s0, s1, s2, saxis], inside=(710.0, 4.0)),
                          saxis, 360)
    cad.set_color(spinner, "#263238", finish="glossy")
    cad.export(spinner)

    # ---- two-blade pusher prop (twisted extrudes along +/-Z) -----------
    blade_x, hub_z, blade_len, tw = 714.0, 9.0, 205.0, 28.0

    def blade(name, z_dir):
        # Sketch plane at the blade root with its NORMAL along the blade
        # axis (+Z or -Z); the chord lies along world Y in both cases.
        o = cad.point(blade_x, 0, hub_z * z_dir)
        if z_dir > 0:
            pu = cad.point(blade_x + 1, 0, hub_z)          # u = +X
            pv = cad.point(blade_x, 1, hub_z)              # v = +Y -> normal +Z
        else:
            pu = cad.point(blade_x, 1, -hub_z)             # u = +Y
            pv = cad.point(blade_x + 1, 0, -hub_z)         # v = +X -> normal -Z
        plane = cad.create_sketch_plane(o, pu, pv, name=name)
        cad.with_sketch(plane)
        # Slender blade section, chord along world Y (24 x 6).
        if z_dir > 0:
            c1, c2 = (-3.0, -12.0), (3.0, 12.0)
        else:
            c1, c2 = (-12.0, -3.0), (12.0, 3.0)
        b1 = cad.point2d(c1[0], c1[1])
        b2 = cad.point2d(c2[0], c1[1])
        b3 = cad.point2d(c2[0], c2[1])
        b4 = cad.point2d(c1[0], c2[1])
        e1 = cad.line2d(b1, b2)
        e2 = cad.line2d(b2, b3)
        e3 = cad.line2d(b3, b4)
        e4 = cad.line2d(b4, b1)
        return cad.extrude(plane,
                           cad.region(loop=[e1, e2, e3, e4], inside=(0, 0)),
                           blade_len, twist=tw)

    for nm, zd in (("prop_up", 1), ("prop_dn", -1)):
        b = blade(nm, zd)
        cad.set_color(b, "#455A64", finish="matte")
        cad.export(b)

    cad.export_point("nose", cad.point(0, 0, 0))
    cad.export_point("prop", cad.point(blade_x, 0, 0))
