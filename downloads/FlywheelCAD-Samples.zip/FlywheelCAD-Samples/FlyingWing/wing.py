"""
wing.py — Prandtl bell-spanload half-wing (NACA 4412 sections) with elevon.

One smooth `multi_loft` half-wing whose TWIST follows Ludwig Prandtl's 1933
bell-shaped lift distribution, as flown on NASA's Prandtl-D research aircraft
(Bowers et al., "On Wings of the Minimum Induced Drag", NASA/TP-2016-219072):

  - `BELL_TWIST` is Table 3 of that paper verbatim — the twist in degrees at
    21 equal stations from centerline (index 0) to wingtip (index 20). It is
    strongly NON-linear: nearly constant (+8.3…+8.9°) over the inner half,
    then washing out fast so the OUTER WING FLIES AT NEGATIVE ANGLE OF ATTACK
    (-1.67° at the tip). With the bell spanload the local flow at the tip
    tilts the force vector forward: the tips produce induced THRUST, which
    yaws the aircraft INTO a roll (proverse yaw) — no vertical fin needed.
  - Planform per the Prandtl-D: straight taper to 25% at the tip, 24° swept
    leading edge, 2.5° dihedral.
  - ELEVON per the same paper: "the control surfaces are located in the
    outboard 14 percent of each wing, in the trailing 25 percent of the
    chord". Tip elevons are enough here BECAUSE of the bell spanload — they
    modulate the tips' induced-thrust region directly (that's the proverse-
    yaw mechanism), so they have outsized authority.

The elevon is a SEPARATE body, split from the wing along a V-shaped hinge
cut the way an RC wing is built: both parts meet at the upper surface (where
the flexible hinge tape goes) and the V opens toward the lower surface so the
elevon can deflect. The main wing keeps the forward bevel, the elevon the aft
bevel. A servo bay is pocketed into the lower surface ahead of the hinge,
with a servo block, a control horn on the elevon, and a pushrod connecting
them.

Built in its own frame: root at the origin, span along +Y, chord along +X,
lift along +Z. The twist axis is the 30%-chord spar (the profile generator's
origin), swept back with the wing. `bell_wing(...)` returns the component
name for `cad.instance`.
"""

from flywheelcad import *
from profiles import naca_4412, _camber, _half_thickness
import math

cad = FlywheelCAD()

# NASA/TP-2016-219072, Table 3: wing twist (deg) at station i/20 of the
# semispan, centerline -> tip. Note the sign change near station 19.
BELL_TWIST = [
    8.3274, 8.5524, 8.7259, 8.8441, 8.9030,
    8.8984, 8.8257, 8.6801, 8.4565, 8.1492,
    7.7522, 7.2592, 6.6634, 5.9579, 5.1362,
    4.1927, 3.1253, 1.9394, 0.6589, -0.6417,
    -1.6726,
]


def bell_twist(s):
    """Twist in degrees at span fraction s in [0, 1], interpolated linearly
    between the 21 tabulated stations."""
    t = max(0.0, min(1.0, s)) * (len(BELL_TWIST) - 1)
    i = min(int(t), len(BELL_TWIST) - 2)
    f = t - i
    return BELL_TWIST[i] * (1 - f) + BELL_TWIST[i + 1] * f


def bell_wing(semispan=1875.0, root_chord=480.0, taper=0.25,
              sweep_deg=24.0, dihedral_deg=2.5,
              elevon_span_frac=0.14, elevon_chord_frac=0.25,
              n_stations=9, samples=10, te_thickness=5.0,
              quality="preview"):
    def build():
        sweep = math.tan(math.radians(sweep_deg))
        dih = math.tan(math.radians(dihedral_deg))
        tip_chord = root_chord * taper

        def chord_at(s):
            return root_chord - (root_chord - tip_chord) * s

        def spar(s):
            """World position of the 30%-chord spar at span fraction s."""
            y = semispan * s
            return (y * sweep, y, y * dih)

        def surface_point(s, chord_frac, upper):
            """World (x, y, z) of the wing skin at span fraction s and the
            given chord fraction — mirrors the profile generator's transform
            (origin at the 30% spar, rotation by the local twist)."""
            c = chord_at(s)
            a = math.radians(bell_twist(s))
            ca, sa = math.cos(a), math.sin(a)
            yt = _half_thickness(chord_frac, 0.12)
            v_abs = _camber(chord_frac) + (yt if upper else -yt)
            tx = (chord_frac - 0.30) * c
            ty = (v_abs - _camber(0.30)) * c
            sx, sy, sz = spar(s)
            return (sx + tx * ca + ty * sa, sy, sz - tx * sa + ty * ca)

        # ---- the lofted wing --------------------------------------------
        planes, regions = [], []
        for k in range(n_stations):
            # Cosine spacing: dense near root and tip, where the bell twist
            # changes fastest.
            s = 0.5 * (1 - math.cos(math.pi * k / (n_stations - 1)))
            x, y, z = spar(s)
            origin = cad.point(x, y, z)
            along_chord = cad.point(x + 1, y, z)   # local u = +X (chord)
            along_lift = cad.point(x, y, z + 1)    # local v = +Z (lift)
            plane = cad.create_sketch_plane(origin, along_chord, along_lift,
                                            name="bw_%d" % k)

            cad.with_sketch(plane)
            outline = naca_4412(chord=chord_at(s), aoa_deg=bell_twist(s),
                                n=samples, te_thickness=te_thickness / chord_at(s))
            pts = [cad.point2d(px, py) for (px, py) in outline]
            section = cad.spline2d(pts, closed=True)

            planes.append(plane)
            regions.append(cad.region(loop=[section], inside=(0, 0)))

        skin = cad.multi_loft(planes, regions, quality=quality)
        # A second, identical loft: the elevon is carved from it by
        # INTERSECTION with the elevon-region prism, while the main wing has
        # that same region SUBTRACTED — two clean separate bodies whose cut
        # faces are the two bevels of the V.
        skin2 = cad.multi_loft(planes, regions, quality=quality)

        # ---- elevon: separated at a V-shaped hinge cut -------------------
        # Hinge runs at (1 - elevon_chord_frac) of the chord over the
        # outboard elevon_span_frac of the semispan.
        hinge_frac = 1.0 - elevon_chord_frac
        s0 = 1.0 - elevon_span_frac
        s1 = 0.985                       # stop just short of the tip
        h_in = surface_point(s0, hinge_frac, upper=True)
        h_out = surface_point(s1, hinge_frac, upper=True)

        hd = (h_out[0] - h_in[0], h_out[1] - h_in[1], h_out[2] - h_in[2])
        hlen = math.sqrt(hd[0] ** 2 + hd[1] ** 2 + hd[2] ** 2)
        h = (hd[0] / hlen, hd[1] / hlen, hd[2] / hlen)
        # Prism-profile plane: u horizontal (positive ~ forward), v vertical;
        # the plane NORMAL is the hinge direction, so prisms extrude along it.
        u = (-h[1], h[0], 0.0)
        ul = math.hypot(u[0], u[1])
        u = (u[0] / ul, u[1] / ul, 0.0)
        v = (h[1] * u[2] - h[2] * u[1], h[2] * u[0] - h[0] * u[2], h[0] * u[1] - h[1] * u[0])

        apex_up = 3.0                    # small overlap above the skin: the
                                         # cut goes through, top slit stays thin
        depth = 0.08 * chord_at(s0) + 8  # below the lower skin with margin
        # RC-style single working bevel: the wing's cut face is near-vertical,
        # the elevon's front face carries the ~24 degree bevel that gives the
        # up-deflection clearance. Top-surface slit ~ 1.5 units (tape-thin).
        wing_slope = 0.10
        elevon_bevel = 0.45
        w_fwd = (depth + apex_up) * wing_slope
        w_aft = (depth + apex_up) * elevon_bevel
        aft_ext = chord_at(s0) * (elevon_chord_frac + 0.10)   # past the TE
        end_gap = 2.5                    # free play at both elevon ends

        def hinge_profile_plane(name, along_gap):
            """Sketch plane perpendicular to the hinge, origin on the hinge
            line `along_gap` units outboard of its inboard end, at apex
            height. In-plane +u points forward, +v up."""
            o = (h_in[0] + h[0] * along_gap,
                 h_in[1] + h[1] * along_gap,
                 h_in[2] + h[2] * along_gap + apex_up)
            pa = cad.point(o[0], o[1], o[2])
            pu = cad.point(o[0] + u[0], o[1] + u[1], o[2] + u[2])
            pv = cad.point(o[0] + v[0], o[1] + v[1], o[2] + v[2])
            return cad.create_sketch_plane(pa, pu, pv, name=name)

        def elevon_region_prism(name, along_gap, length):
            """Prism covering the elevon volume: apex at the top, the AFT
            bevel of the V as its forward face, extended past the TE."""
            plane = hinge_profile_plane(name, along_gap)
            cad.with_sketch(plane)
            e1 = cad.point2d(0, 0)                              # apex
            e2 = cad.point2d(-w_aft, -(depth + apex_up))        # aft bevel foot
            e3 = cad.point2d(-aft_ext, -(depth + apex_up))      # past the TE
            e4 = cad.point2d(-aft_ext, 0)
            l1 = cad.line2d(e1, e2)
            l2 = cad.line2d(e2, e3)
            l3 = cad.line2d(e3, e4)
            l4 = cad.line2d(e4, e1)
            return cad.extrude(plane,
                               cad.region(loop=[l1, l2, l3, l4],
                                          inside=(-aft_ext * 0.5, -depth * 0.5)),
                               length, quality=quality, export=False)

        def wing_cut_prism(name, along_gap, length):
            """Prism removed from the main wing: everything aft of the
            FORWARD bevel of the V (a superset of the elevon region)."""
            plane = hinge_profile_plane(name, along_gap)
            cad.with_sketch(plane)
            c1 = cad.point2d(0, 0)                              # apex
            c2 = cad.point2d(w_fwd, -(depth + apex_up))         # near-vertical face
            c3 = cad.point2d(w_fwd, -(depth + apex_up) * 2)
            c4 = cad.point2d(-aft_ext, -(depth + apex_up) * 2)
            c5 = cad.point2d(-aft_ext, 0)
            l1 = cad.line2d(c1, c2)
            l2 = cad.line2d(c2, c3)
            l3 = cad.line2d(c3, c4)
            l4 = cad.line2d(c4, c5)
            l5 = cad.line2d(c5, c1)
            return cad.extrude(plane,
                               cad.region(loop=[l1, l2, l3, l4, l5],
                                          inside=(-aft_ext * 0.5, -depth)),
                               length, quality=quality, export=False)

        cut = wing_cut_prism("bw_cut", 0.0, hlen)
        bay_region = elevon_region_prism("bw_ele", end_gap, hlen - 2 * end_gap)

        # ---- servo bay: pocket in the lower surface ahead of the hinge --
        sm = (s0 + s1) / 2.0
        bay_lo = surface_point(sm, hinge_frac - 0.22, upper=False)
        bay_w, bay_l, bay_d = 30.0, 34.0, 14.0
        b0 = (bay_lo[0] - bay_l / 2, bay_lo[1] - bay_w / 2, bay_lo[2] - 4.0)
        pb = cad.point(b0[0], b0[1], b0[2])
        pbu = cad.point(b0[0] + 1, b0[1], b0[2])    # u = +X
        pbv = cad.point(b0[0], b0[1] + 1, b0[2])    # v = +Y, normal = +Z (up)
        bplane = cad.create_sketch_plane(pb, pbu, pbv, name="bw_bay")
        cad.with_sketch(bplane)
        r1 = cad.point2d(0, 0)
        r2 = cad.point2d(bay_l, 0)
        r3 = cad.point2d(bay_l, bay_w)
        r4 = cad.point2d(0, bay_w)
        bl1 = cad.line2d(r1, r2)
        bl2 = cad.line2d(r2, r3)
        bl3 = cad.line2d(r3, r4)
        bl4 = cad.line2d(r4, r1)
        bay = cad.extrude(bplane,
                          cad.region(loop=[bl1, bl2, bl3, bl4], inside=(bay_l / 2, bay_w / 2)),
                          bay_d + 4.0, quality=quality, export=False)

        body = cad.bool_difference(skin, cut, bay, quality=quality)
        cad.set_color(body, "#ECEFF1", finish="matte")   # pale gray-white
        cad.export(body)

        # The elevon: the second loft clipped to the elevon region — its own
        # body, its own color (visibly a separate control surface).
        elevon = cad.bool_intersection(skin2, bay_region, quality=quality)
        cad.set_color(elevon, "#F57C00", finish="matte")   # signal orange
        cad.export(elevon)

        # ---- servo block, control horn, pushrod (visible hardware) ------
        cad.with_sketch(bplane)
        v1 = cad.point2d(4, 4)
        v2 = cad.point2d(bay_l - 4, 4)
        v3 = cad.point2d(bay_l - 4, bay_w - 4)
        v4 = cad.point2d(4, bay_w - 4)
        vl1 = cad.line2d(v1, v2)
        vl2 = cad.line2d(v2, v3)
        vl3 = cad.line2d(v3, v4)
        vl4 = cad.line2d(v4, v1)
        servo = cad.extrude(bplane,
                            cad.region(loop=[vl1, vl2, vl3, vl4], inside=(bay_l / 2, bay_w / 2)),
                            bay_d, quality=quality)
        cad.set_color(servo, "#263238", finish="matte")
        cad.export(servo)

        # Control horn: a small triangular plate under the ELEVON, clearly
        # aft of the hinge gap, in a vertical chordwise plane at the servo's
        # span station. Its tip hangs DOWN — the pushrod attaches there.
        # NOTE on the sketch frame: the defining points give this plane a +Y
        # normal, and the app's plane frame keeps sketch-"up" pointing to
        # world +Z (v.z >= 0), which for a +Y normal flips u to world -X.
        # So sketch -x is world +X (aft) and sketch -y is world -Z (down).
        horn_base = surface_point(sm, hinge_frac + 0.09, upper=False)
        ph = cad.point(horn_base[0], horn_base[1] - 1.5, horn_base[2] + 2.0)
        phu = cad.point(horn_base[0] + 1, horn_base[1] - 1.5, horn_base[2] + 2.0)
        phv = cad.point(horn_base[0], horn_base[1] - 1.5, horn_base[2] + 1.0)
        hplane = cad.create_sketch_plane(ph, phu, phv, name="bw_horn")
        cad.with_sketch(hplane)
        t1 = cad.point2d(0, 0)
        t2 = cad.point2d(-14, 0)    # base runs aft along the elevon underside
        t3 = cad.point2d(-2, -16)   # tip hangs down below the lower surface
        tl1 = cad.line2d(t1, t2)
        tl2 = cad.line2d(t2, t3)
        tl3 = cad.line2d(t3, t1)
        horn = cad.extrude(hplane,
                           cad.region(loop=[tl1, tl2, tl3], inside=(-5, -4)),
                           3.0, quality=quality)
        cad.set_color(horn, "#263238", finish="matte")
        cad.export(horn)

        # Pushrod: a slender rod from the servo arm aft-and-DOWN to the horn
        # tip (which hangs ~14 below the elevon's lower surface).
        rod_a = (bay_lo[0] + bay_l * 0.3, horn_base[1], bay_lo[2] - 6.0)
        rod_b = (horn_base[0] + 2.0, horn_base[1], horn_base[2] - 14.0)
        rd = (rod_b[0] - rod_a[0], rod_b[1] - rod_a[1], rod_b[2] - rod_a[2])
        rlen = math.sqrt(rd[0] ** 2 + rd[1] ** 2 + rd[2] ** 2)
        rn = (rd[0] / rlen, rd[1] / rlen, rd[2] / rlen)
        # Plane through rod_a with normal along the rod: u = +Y-ish, v = n x u.
        ru = (0.0, 1.0, 0.0)
        rv = (rn[1] * ru[2] - rn[2] * ru[1], rn[2] * ru[0] - rn[0] * ru[2], rn[0] * ru[1] - rn[1] * ru[0])
        pr = cad.point(rod_a[0], rod_a[1], rod_a[2])
        pru = cad.point(rod_a[0] + ru[0], rod_a[1] + ru[1], rod_a[2] + ru[2])
        prv = cad.point(rod_a[0] + rv[0], rod_a[1] + rv[1], rod_a[2] + rv[2])
        rplane = cad.create_sketch_plane(pr, pru, prv, name="bw_rod")
        cad.with_sketch(rplane)
        w1 = cad.point2d(-1.2, -1.2)
        w2 = cad.point2d(1.2, -1.2)
        w3 = cad.point2d(1.2, 1.2)
        w4 = cad.point2d(-1.2, 1.2)
        wl1 = cad.line2d(w1, w2)
        wl2 = cad.line2d(w2, w3)
        wl3 = cad.line2d(w3, w4)
        wl4 = cad.line2d(w4, w1)
        rod = cad.extrude(rplane,
                          cad.region(loop=[wl1, wl2, wl3, wl4], inside=(0, 0)),
                          rlen, quality=quality)
        cad.set_color(rod, "#90A4AE", finish="metallic")
        cad.export(rod)

        cad.export_point("root", cad.point(0, 0, 0))
        cad.export_point("tip", cad.point(semispan * sweep, semispan, semispan * dih))

    return cad.parametric("bellwing", build,
                          semispan=semispan, root_chord=root_chord, taper=taper,
                          sweep_deg=sweep_deg, dihedral_deg=dihedral_deg,
                          elevon_span_frac=elevon_span_frac,
                          elevon_chord_frac=elevon_chord_frac,
                          n_stations=n_stations, samples=samples,
                          te_thickness=te_thickness, quality=quality)
