"""
tail.py — glider T-tail component (two symmetric-airfoil surfaces).

  - a VERTICAL FIN: symmetric NACA 00xx sections stacked and lofted along +Z
    (chord along +X, thickness along +Y),
  - a HORIZONTAL STABILIZER sitting on TOP of the fin (the "T"): symmetric
    sections lofted across the full span ±Y (chord along +X, thickness along +Z).

Both are exported as distinct parts of the one "tail" component. Built at their
world positions on the tail boom, so the assembly instances it untransformed.
"""

from flywheelcad import *
from profiles import naca_symmetric
from config import MODEL_SCALE as S

cad = FlywheelCAD()

QUALITY = "preview"
SAMPLES = 10
TE = 3.0 * S
THICK = 0.10                 # 10% symmetric section (a fraction — not scaled)

# Vertical fin (root on the boom, tapering upward). All lengths × MODEL_SCALE.
FIN_X = 1850.0 * S           # fin mid-chord, fore/aft
FIN_BASE_Z = 20.0 * S        # sits on the boom top
FIN_HEIGHT = 340.0 * S
FIN_ROOT_CHORD = 195.0 * S
FIN_TIP_CHORD = 120.0 * S
FIN_STATIONS = 5

# Horizontal stabilizer at the fin top (the T).
STAB_X = 1885.0 * S
STAB_HALFSPAN = 430.0 * S
STAB_ROOT_CHORD = 150.0 * S
STAB_TIP_CHORD = 92.0 * S
STAB_STATIONS = 5


def _section(plane_name, origin, u_pt, v_pt, chord):
    """Place a symmetric airfoil section on a plane; return (plane, region)."""
    plane = cad.create_sketch_plane(origin, u_pt, v_pt, name=plane_name)
    cad.with_sketch(plane)
    outline = naca_symmetric(chord=chord, thickness=THICK, aoa_deg=0.0,
                             n=SAMPLES, te_thickness=TE / chord)
    pts = [cad.point2d(px, py) for (px, py) in outline]
    section = cad.spline2d(pts, closed=True)
    return plane, cad.region(loop=[section], inside=(0, 0))


with cad.component("tail"):
    # --- Vertical fin: sections stacked in Z (span axis = +Z) ---
    fin_planes, fin_regions = [], []
    for k in range(FIN_STATIONS):
        s = k / (FIN_STATIONS - 1)
        z = FIN_BASE_Z + FIN_HEIGHT * s
        chord = FIN_ROOT_CHORD - (FIN_ROOT_CHORD - FIN_TIP_CHORD) * s
        plane, region = _section(
            "fin_%d" % k,
            cad.point(FIN_X, 0, z),         # origin
            cad.point(FIN_X + 1, 0, z),     # local u = +X (chord)
            cad.point(FIN_X, 1, z),         # local v = +Y (thickness)
            chord)
        fin_planes.append(plane)
        fin_regions.append(region)
    fin = cad.multi_loft(fin_planes, fin_regions, quality=QUALITY)
    cad.set_color(fin, "#DED0B4", finish="matte")   # light tan/beige
    cad.component_export(fin, name="fin")

    # --- Horizontal stabilizer on top of the fin: sections across ±Y ---
    stab_z = FIN_BASE_Z + FIN_HEIGHT
    stab_planes, stab_regions = [], []
    for k in range(STAB_STATIONS):
        s = k / (STAB_STATIONS - 1)                       # 0..1 across full span
        y = -STAB_HALFSPAN + 2 * STAB_HALFSPAN * s
        frac = abs(y) / STAB_HALFSPAN                     # 0 centre -> 1 tip
        chord = STAB_ROOT_CHORD - (STAB_ROOT_CHORD - STAB_TIP_CHORD) * frac
        plane, region = _section(
            "stab_%d" % k,
            cad.point(STAB_X, y, stab_z),        # origin
            cad.point(STAB_X + 1, y, stab_z),    # local u = +X (chord)
            cad.point(STAB_X, y, stab_z + 1),    # local v = +Z (thickness)
            chord)
        stab_planes.append(plane)
        stab_regions.append(region)
    stab = cad.multi_loft(stab_planes, stab_regions, quality=QUALITY)
    cad.set_color(stab, "#DED0B4", finish="matte")
    cad.component_export(stab, name="stab")

    cad.component_export_point("base", cad.point(FIN_X, 0, FIN_BASE_Z))
