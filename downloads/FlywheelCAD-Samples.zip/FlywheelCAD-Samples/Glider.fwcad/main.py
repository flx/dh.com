# flywheelcad-format: 1
"""
main.py — a sailplane assembly (open this file as the document).

Composes three separately-defined components onto a common frame:
  - fuselage  : body + cockpit + tail boom, one lofted piece (fuselage.py)
  - wing      : a NACA 4412 half-wing, non-linear taper + washout (wing.py),
                instanced on each side (the left one mirrored across zx)
  - tail      : a symmetric-airfoil T-tail — fin + top stabilizer (tail.py)

Overall length ~2050 units; wing span ~4400 (half-span 2200) — glider-typical.
Each component carries a slightly different off-white/beige shade.

Frame: +X fore/aft (nose at 0), +Y span (right), +Z up. The fuselage and tail
build at their world positions; the wings build at the origin and are placed at
the wing seat.
"""

from flywheelcad import *
from config import MODEL_SCALE as S   # the ONE size knob — see config.py

cad = FlywheelCAD()

import fuselage           # defines the "fuselage" component (sized by MODEL_SCALE)
import tail               # defines the "tail" component (fin + stab)
from wing import wing     # parametric wing factory

# One wing shape (built to size), placed on both sides. Chords/span are scaled;
# angles (twist, dihedral) are not.
WING = wing(span=2200.0 * S, root_chord=260.0 * S, tip_chord=110.0 * S,
            root_aoa=3.0, tip_aoa=-1.5, dihedral_deg=2.5, te_thickness=3.0 * S)

# Wing seat: mid-high on the pod, just behind the cockpit.
WING_X, WING_Z = 640.0 * S, 95.0 * S

# --- Placement (components are already built to size; just position them) ---
fus = cad.instance("fuselage")                                    # nose at origin
wing_r = cad.instance(WING, translate=(WING_X, 0, WING_Z))        # right wing (+Y)
wing_l = cad.instance(WING, mirror_plane="zx", translate=(WING_X, 0, WING_Z))  # left wing (-Y)
emp = cad.instance("tail")                                        # T-tail on the boom
