"""
config.py — shared sizing for the glider.

MODEL_SCALE uniformly sizes the GEOMETRY of every component:

    1.0 → the full glider: ~2050 units long, ~4400-unit span (glider-typical).

The fuselage / wings / tail are `multi_loft` surfaces. In a Release build these
mesh in a few seconds each (~10-15s for the whole glider at "preview"). A DEBUG
build is dramatically slower for the loft numerics — if a build takes minutes,
you are on Debug; run Release, or raise MODEL_SCALE for a smaller test. Raise
each component's `quality=` (preview → ultra) for a finer final surface.
"""

MODEL_SCALE = 1.0
