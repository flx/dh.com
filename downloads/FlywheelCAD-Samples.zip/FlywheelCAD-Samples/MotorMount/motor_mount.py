# Motor mount plate — standard-library showcase.
#
# A mounting flange machined from one plate (every cutout is a declared
# region hole — no booleans needed for the plate itself), populated with
# catalog parts from the standard component library:
#
#   * a NEMA 17 stepper hung under the plate, shaft up through the boss
#     bore, fixed by four M3 cap screws into its faceplate taps
#   * a standard-size servo dropped into a body cutout, its flange seated
#     on the plate, with a control horn mated onto the output spline
#   * a 608 bearing pressed into a through-seat
#   * four corner mounting holes for the flange itself
#
# Each placed component gets its own display color so the assembly reads
# at a glance. Library modules live in lib/standard/ (copy-on-use).

from flywheelcad import *

cad = FlywheelCAD()

from lib.standard.steppers import stepper
from lib.standard.servos import servo, horn
from lib.standard.fasteners import cap_screw
from lib.standard.bearings import bearing

# ---------------------------------------------------------------- plate
# 160 x 64 x 6 flange. All cutouts are nested region holes:
# corner mounting holes (M4 clearance), the motor boss bore + its four
# M3 clearance holes, the servo body cutout + its four screw holes, and
# the bearing seat.
PLATE_L, PLATE_W, PLATE_T = 160.0, 64.0, 6.0
MOTOR_AT = (-50.0, 0.0)
SERVO_AT = (10.0, 0.0)
BEARING_AT = (62.0, 0.0)

cad.with_sketch("xy")
hx, hy = PLATE_L / 2.0, PLATE_W / 2.0
p1 = cad.point2d(-hx, -hy)
p2 = cad.point2d(hx, -hy)
p3 = cad.point2d(hx, hy)
p4 = cad.point2d(-hx, hy)
l1 = cad.line2d(p1, p2)
l2 = cad.line2d(p2, p3)
l3 = cad.line2d(p3, p4)
l4 = cad.line2d(p4, p1)

holes = []

# Corner mounting holes (M4 clearance, 4.5 mm).
for (cx, cy) in [(74, 26), (-74, 26), (-74, -26), (74, -26)]:
    holes.append([cad.circle2d(cad.point2d(cx, cy), 2.25)])

# Motor: boss bore (22 mm boss + clearance) and the M3 bolt circle on
# the NEMA 17 31 mm square.
mx, my = MOTOR_AT
holes.append([cad.circle2d(cad.point2d(mx, my), 11.3)])
for (bx, by) in [(15.5, 15.5), (-15.5, 15.5), (-15.5, -15.5), (15.5, -15.5)]:
    holes.append([cad.circle2d(cad.point2d(mx + bx, my + by), 1.7)])

# Servo: body cutout (40.5 x 20.2 case + fitting clearance) and the four
# flange screw holes at the standard 49.5 x 10 pattern.
sx, sy = SERVO_AT
c1 = cad.point2d(sx - 20.6, sy - 10.4)
c2 = cad.point2d(sx + 20.6, sy - 10.4)
c3 = cad.point2d(sx + 20.6, sy + 10.4)
c4 = cad.point2d(sx - 20.6, sy + 10.4)
s1 = cad.line2d(c1, c2)
s2 = cad.line2d(c2, c3)
s3 = cad.line2d(c3, c4)
s4 = cad.line2d(c4, c1)
holes.append([s1, s2, s3, s4])
for (bx, by) in [(24.75, 5.0), (-24.75, 5.0), (-24.75, -5.0), (24.75, -5.0)]:
    holes.append([cad.circle2d(cad.point2d(sx + bx, sy + by), 1.45)])

# Bearing seat: 608 pressed through (22 mm OD, light press allowance).
bx, by = BEARING_AT
holes.append([cad.circle2d(cad.point2d(bx, by), 11.02)])

plate = cad.extrude("xy",
                    cad.region(loop=[l1, l2, l3, l4], holes=holes,
                               inside=(-hx + 6.0, -hy + 6.0)),
                    PLATE_T)
cad.set_color(plate, "#78909C", finish="metallic")

# ------------------------------------------------------------ components
# NEMA 17 under the plate: mount face against the plate bottom (z = 0),
# shaft up through the boss bore.
m = stepper(cad, size=17, length=40)
motor = cad.instance(m, translate=(MOTOR_AT[0], MOTOR_AT[1], 0))
cad.set_color(motor, "#5C6BC0", finish="matte")

# Four M3 cap screws from the top into the motor's faceplate taps.
m3 = cap_screw(cad, thread="M3", length=8)
for k, (ox, oy) in enumerate([(15.5, 15.5), (-15.5, 15.5), (-15.5, -15.5), (15.5, -15.5)]):
    s = cad.instance(m3, translate=(MOTOR_AT[0] + ox, MOTOR_AT[1] + oy, PLATE_T))
    cad.set_color(s, "#FFC107", finish="metallic")

# Servo dropped into its cutout, flange seated on the plate top.
sv = servo(cad, size="standard")
servo_inst = cad.instance(sv, translate=(SERVO_AT[0], SERVO_AT[1], PLATE_T))
cad.set_color(servo_inst, "#F57C00", finish="matte")

# Servo screws (M2.5 into the mount pattern), seated on the flange top
# (flange_t = 3.0 for the "standard" servo).
SERVO_FLANGE_T = 3.0
m25 = cap_screw(cad, thread="M2.5", length=8)
for (ox, oy) in [(24.75, 5.0), (-24.75, 5.0), (-24.75, -5.0), (24.75, -5.0)]:
    s = cad.instance(m25, translate=(SERVO_AT[0] + ox, SERVO_AT[1] + oy, PLATE_T + SERVO_FLANGE_T))
    cad.set_color(s, "#FFC107", finish="metallic")

# Control horn mated onto the servo's output spline.
h = horn(cad, style="single", spline="standard")
arm = cad.instance(h)
cad.set_color(arm, "#ECEFF1", finish="glossy")
cad.mate_coincident(arm, "hub", servo_inst.spline_tip)

# 608 bearing pressed into its seat, slightly proud of the 6 mm plate.
b = bearing(cad, designation="608")
brg = cad.instance(b, translate=(BEARING_AT[0], BEARING_AT[1], 0))
cad.set_color(brg, "#CFD8DC", finish="metallic")
