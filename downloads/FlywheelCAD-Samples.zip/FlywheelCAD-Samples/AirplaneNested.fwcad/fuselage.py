"""
fuselage.py — fuselage leaf component (body of revolution).

A half-silhouette in the xy plane revolved 360° about the centerline. Exports
the body plus the mount points the wings and tail attach to.
"""

from flywheelcad import *
cad = FlywheelCAD()

with cad.component("fuselage"):
    cad.with_sketch("xy")
    # Smooth half-silhouette: a single spline through the profile points, closed
    # off by the centerline. Revolved 360° it gives a smoothly curved fuselage.
    p0 = cad.point2d(0, 0)       # nose tip (on centerline)
    p1 = cad.point2d(10, 8)
    p2 = cad.point2d(30, 11)
    p3 = cad.point2d(50, 9)
    p4 = cad.point2d(66, 3)
    p5 = cad.point2d(72, 0)      # tail tip (on centerline)
    silhouette = cad.spline2d([p0, p1, p2, p3, p4, p5])
    axis = cad.line2d(p5, p0)    # centerline (y = 0); also the revolve axis
    body = cad.revolve("xy",
                       cad.region(loop=[silhouette, axis], inside=(32, 4)),
                       axis, 360)
    cad.set_color(body, "red", finish="matte")   # red fuselage
    cad.component_export(body)
    cad.component_export_point("nose", cad.point(0, 0, 0))
    cad.component_export_point("wing_mount", cad.point(30, 0, 0))
    cad.component_export_point("tail_mount", cad.point(68, 0, 0))
