# flywheelcad-format: 1
# =============================================================================
# AxialFluxMotor — a 3D-printable double-rotor, coreless-stator axial flux motor
#
# Overall radius ~200 mm (stator plate). Architecture: one printed coreless
# (ironless) stator disc carrying 24 flat coils, sandwiched between two rotor
# discs, each carrying 32 commercially available N42 block magnets
# (40 x 20 x 10 mm) seated in through-windows against a 3 mm laser-cut steel
# back-iron disc. The rotors are fixed to a 15 mm steel shaft that runs in two
# 6902 deep-groove bearings (15x28x7) housed in the stator hub.
#
# Purchased parts (all common internet-catalog items):
#   64x  N42 neodymium block magnet 40 x 20 x 10 mm (magnetized through 10 mm)
#   2x   6902 deep-groove ball bearing, 15 x 28 x 7 mm
#   1x   15 mm precision steel shaft, 100 mm long
#   2x   3 mm mild-steel disc, OD 370 mm / bore 68 mm (laser-cut to the
#        steel_disc body in this file, e.g. SendCutSend / Fractory)
#   8x   M4 x 30 cap screws + nuts (rotor stacks), 6x M5 (stator mounting)
#   ~0.5 kg of 0.5-0.8 mm enamelled magnet wire
#
# Printed parts (exported to 3MF): stator plate, stator hub, 2x rotor carrier,
# 2x rotor hub. Coils, magnets, steel discs, bearings and shaft are modeled
# for fit/visualisation and excluded from mesh export.
#
# Electromagnetics (quick sanity numbers, not a promise):
#   32 poles / 24 coils (classic 4:3 coreless ratio), 3 phases, 8 coils each.
#   Magnetic gap = 14 mm stator + 2 x 1.5 mm running clearance = 17 mm between
#   opposing magnet faces; ~0.7 T in the gap with N42 10 mm magnets.
# =============================================================================
from flywheelcad import *
cad = FlywheelCAD()
cad.set_quality("ultra")

import math
from lib.standard.bearings import bearing

# ---- design constants (the numbers to change live here) ---------------------
N_POLES = 32          # magnets per rotor (must be even)
N_COILS = 24          # coils in the stator = 3/4 of N_POLES
MAG_RIN, MAG_ROUT = 135.0, 175.0     # magnet ring radial span (40 mm magnet)
MAG_HALF_W = 10.0     # half of the 20 mm magnet width (tangential)
MAG_T = 10.0          # magnet thickness
POCKET_CLEAR = 0.2    # rotor window clearance around a magnet, per side
COIL_RIN, COIL_ROUT = 125.0, 185.0   # coil block radial span
COIL_HALF_W_IN, COIL_HALF_W_OUT = 14.5, 21.5   # coil half-widths at RIN/ROUT
COIL_T = 10.0         # coil bundle thickness
COIL_CORNER_R = 8.0   # corner radius of the coil outline
WIND_W = 8.0          # winding bundle width — uniform wall, outline to window
WINDOW_CLEAR = 0.3    # stator window clearance around a coil, per side
STATOR_T = 14.0       # stator plate thickness (coil + 2 mm skin per side)
AIR_GAP = 1.5         # running clearance stator face -> magnet face
R_STATOR = 200.0      # stator plate outer radius (the ~200 mm in the brief)
R_ROTOR = 185.0       # rotor disc outer radius
CARRIER_T = 10.0      # printed magnet-carrier thickness (= magnet thickness)
STEEL_T = 3.0         # laser-cut back-iron disc thickness
R_ROTOR_BORE = 34.0   # carrier/steel bore (clears the stator hub flange R32)
R_BOLTS = 40.0        # rotor stack M4 bolt circle
R_MOUNT = 193.0       # stator M5 mounting hole circle

Z_ROTOR = STATOR_T / 2.0 + AIR_GAP           # 8.5 — rotor carrier inner face

PHASE_COLORS = ["#B87333", "#2E7D32", "#5E35B1"]   # phase A copper / B / C
COL_N, COL_S = "#C62828", "#1565C0"                # pole facing the stator

def _rot(x, y, deg):
    a = math.radians(deg)
    return (x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a))

def _quad(corners):
    """4 corner tuples (CCW) -> closed list of 4 sketch lines."""
    qpts = [cad.point2d(round(x, 3), round(y, 3)) for (x, y) in corners]
    qlines = [cad.line2d(qpts[j], qpts[(j + 1) % 4]) for j in range(4)]
    return qlines

def _rounded_quad(corners, radius):
    """_quad plus a fillet at every corner -> 8-element region loop."""
    rq_lines = _quad(corners)
    rq_fils = [cad.fillet(rq_lines[j], rq_lines[(j + 1) % 4], radius=radius)
               for j in range(4)]
    return [rq_lines[0], rq_fils[0], rq_lines[1], rq_fils[1],
            rq_lines[2], rq_fils[2], rq_lines[3], rq_fils[3]]

def _coil_hole_corners(inset=0.0):
    """Corners of the coil's winding window: the outline drawn in by a uniform
    WIND_W (+ inset) wall so the wound bundle is equally thick on every side.
    (The side edges slope ~6.6 deg, so treating the offset as radial/tangential
    is accurate to about 1 %.)"""
    t = WIND_W + inset
    wx0, wx1 = COIL_RIN + t, COIL_ROUT - t
    def hw(x):
        return (COIL_HALF_W_IN + (COIL_HALF_W_OUT - COIL_HALF_W_IN)
                * (x - COIL_RIN) / (COIL_ROUT - COIL_RIN))
    return [(wx0, -(hw(wx0) - t)), (wx1, -(hw(wx1) - t)),
            (wx1, hw(wx1) - t), (wx0, hw(wx0) - t)]

# =============================================================================
# Stator plate — printed. One 14 mm disc, R200, with 24 through-windows the
# coils sit in, a bore for the bearing hub, and 6 M5 mounting holes.
# The window pattern is generated (derived data); the circles that a person
# would re-size are dimensioned.
# =============================================================================
cad.with_sketch("xy")
sp_center = cad.point2d(0, 0)
stator_outer = cad.circle2d(sp_center, R_STATOR)
cad.coincident(p0=sp_center, p1=origin_xy)
cad.radius(circle=stator_outer, radius=200)

sb_center = cad.point2d(0, 0)
stator_bore = cad.circle2d(sb_center, 24.2)
cad.coincident(p0=sb_center, p1=origin_xy)
cad.radius(circle=stator_bore, radius=24.2)

stator_holes = [[stator_bore]]
for i in range(6):                        # M5 mounting holes
    mx, my = _rot(R_MOUNT, 0.0, i * 60.0)
    stator_holes.append([cad.circle2d(cad.point2d(round(mx, 3), round(my, 3)), 2.6)])
for i in range(N_COILS):                  # coil windows: coil outline + clearance,
    ang = i * 360.0 / N_COILS             # rounded to match the coil corners
    stator_holes.append(_rounded_quad(
        [_rot(COIL_RIN - WINDOW_CLEAR, -(COIL_HALF_W_IN + WINDOW_CLEAR), ang),
         _rot(COIL_ROUT + WINDOW_CLEAR, -(COIL_HALF_W_OUT + WINDOW_CLEAR), ang),
         _rot(COIL_ROUT + WINDOW_CLEAR, COIL_HALF_W_OUT + WINDOW_CLEAR, ang),
         _rot(COIL_RIN - WINDOW_CLEAR, COIL_HALF_W_IN + WINDOW_CLEAR, ang)],
        COIL_CORNER_R + WINDOW_CLEAR))

sp_inside = _rot(100.0, 0.0, 7.5)         # between window 0 and window 1
stator_region = cad.region(loop=[stator_outer], holes=stator_holes,
                           inside=(round(sp_inside[0], 3), round(sp_inside[1], 3)))
stator_plate = cad.extrude("xy", stator_region, STATOR_T, offset=-STATOR_T / 2.0)
cad.set_color(stator_plate, "#455A64", finish="matte")

# =============================================================================
# Stator hub — printed. Revolved bush that presses into the plate bore and
# carries the two 6902 bearings (seats R14 x 7 deep at each end), with a
# registration flange under the plate. Glue or 3 small screws into the plate.
# =============================================================================
cad.with_sketch("zx")
hub_prof = [(8.5, -9.0), (14.0, -9.0), (14.0, -16.0), (24.0, -16.0),
            (24.0, -9.0), (32.0, -9.0), (32.0, -7.0), (24.0, -7.0),
            (24.0, 16.0), (14.0, 16.0), (14.0, 9.0), (8.5, 9.0)]
hub_pts = [cad.point2d(r, z) for (r, z) in hub_prof]
hub_lines = [cad.line2d(hub_pts[j], hub_pts[j + 1]) for j in range(len(hub_pts) - 1)]
hub_lines.append(cad.line2d(hub_pts[-1], hub_pts[0]))
hub_axis = cad.line2d(cad.point2d(0.0, -16.0), cad.point2d(0.0, 16.0),
                      construction=True)
stator_hub = cad.revolve("zx", cad.region(loop=hub_lines, inside=(16.0, 0.0)),
                         axis_line=hub_axis, angle=360)
cad.set_color(stator_hub, "#607D8B", finish="matte")

# =============================================================================
# Shaft — purchased 15 mm ground shaft, 100 mm. Visual only (export=False).
# =============================================================================
cad.with_sketch("xy")
sh_center = cad.point2d(0, 0)
shaft_circle = cad.circle2d(sh_center, 7.5)
cad.coincident(p0=sh_center, p1=origin_xy)
cad.radius(circle=shaft_circle, radius=7.5)
shaft = cad.extrude("xy", cad.region(loop=[shaft_circle], inside=(0, 0)),
                    100, offset=-50, export=False)
cad.set_color(shaft, "#B0BEC5", finish="metallic")

# =============================================================================
# Coil — one phase-colored component per phase, instanced 24x. The body is the
# envelope of the winding path: a filleted trapezoidal loop (the "racetrack")
# whose window matches the magnet footprint. Not individual strands, per design.
# =============================================================================
def coil_comp(phase):
    def build():
        cad.with_sketch("xy")
        oloop = _rounded_quad([(COIL_RIN, -COIL_HALF_W_IN), (COIL_ROUT, -COIL_HALF_W_OUT),
                               (COIL_ROUT, COIL_HALF_W_OUT), (COIL_RIN, COIL_HALF_W_IN)],
                              COIL_CORNER_R)
        # winding window: a uniform WIND_W wall all round, like a real bundle
        wloop = _rounded_quad(_coil_hole_corners(), COIL_CORNER_R - WIND_W / 2.0)
        mid_r = (MAG_RIN + MAG_ROUT) / 2.0
        bundle = cad.extrude("xy",
                             cad.region(loop=oloop, holes=[wloop], inside=(mid_r, 14.0)),
                             COIL_T, offset=-COIL_T / 2.0, export=False)
        cad.set_color(bundle, PHASE_COLORS[phase], finish="matte")
        cad.component_export(bundle, name="w")
    return cad.parametric("coil", build, phase=phase,
                          label=f"Phase {'ABC'[phase]} coil")

COIL_BY_PHASE = [coil_comp(0), coil_comp(1), coil_comp(2)]
for i in range(N_COILS):
    cad.instance(COIL_BY_PHASE[i % 3], axis=(0, 0, 1), angle=i * 360.0 / N_COILS,
                 name=f"coil{i}", export=False)

# =============================================================================
# Coil former — printed. A core that fills the winding window: wind each coil
# directly around one of these, then epoxy former + coil into the stator
# window together. Modeled 0.15 mm under the window all round.
# =============================================================================
with cad.component("coil_former", label="Coil winding former (printed)"):
    cad.with_sketch("xy")
    cf_loop = _rounded_quad(_coil_hole_corners(inset=0.15),
                            COIL_CORNER_R - WIND_W / 2.0 - 0.15)
    cf_body = cad.extrude("xy",
                          cad.region(loop=cf_loop,
                                     inside=((COIL_RIN + COIL_ROUT) / 2.0, 0.0)),
                          COIL_T, offset=-COIL_T / 2.0)
    cad.set_color(cf_body, "#ECEFF1", finish="matte")
    cad.component_export(cf_body, name="core")

for i in range(N_COILS):
    cad.instance("coil_former", axis=(0, 0, 1), angle=i * 360.0 / N_COILS,
                 name=f"former{i}")

# =============================================================================
# Magnet — N42 block 40 x 20 x 10 mm, drawn at its working radius so instances
# only rotate about the axis. Color = pole facing the stator (red N / blue S).
# =============================================================================
def magnet_comp(pole):
    def build():
        cad.with_sketch("xy")
        outline = _quad([(MAG_RIN, -MAG_HALF_W), (MAG_ROUT, -MAG_HALF_W),
                         (MAG_ROUT, MAG_HALF_W), (MAG_RIN, MAG_HALF_W)])
        mid_r = (MAG_RIN + MAG_ROUT) / 2.0
        blk = cad.extrude("xy", cad.region(loop=outline, inside=(mid_r, 0.0)),
                          MAG_T, export=False)
        cad.set_color(blk, COL_N if pole == "N" else COL_S, finish="metallic")
        cad.component_export(blk, name="m")
    return cad.parametric("mag40x20x10", build, pole=pole,
                          label=f"N42 block 40x20x10, {pole} to stator")

MAG_N = magnet_comp("N")
MAG_S = magnet_comp("S")
for i in range(N_POLES):
    ang = i * 360.0 / N_POLES
    # top rotor: N,S,N,... facing down; bottom rotor: opposite pole facing up,
    # so flux crosses the stator and returns through the steel discs.
    cad.instance(MAG_N if i % 2 == 0 else MAG_S, axis=(0, 0, 1), angle=ang,
                 translate=(0, 0, Z_ROTOR), name=f"mag_t{i}", export=False)
    cad.instance(MAG_S if i % 2 == 0 else MAG_N, axis=(0, 0, 1), angle=ang,
                 translate=(0, 0, -(Z_ROTOR + MAG_T)), name=f"mag_b{i}", export=False)

# =============================================================================
# Rotor carrier — printed. 10 mm disc with 32 through-windows; magnets drop in
# and seat directly on the steel back-iron disc behind (which also carries the
# magnetic return path). Bolted to the steel disc and rotor hub at R40.
# =============================================================================
with cad.component("rotor_carrier", label="Rotor magnet carrier (printed)"):
    cad.with_sketch("xy")
    rc_outer = cad.circle2d(cad.point2d(0, 0), R_ROTOR)
    rc_bore = cad.circle2d(cad.point2d(0, 0), R_ROTOR_BORE)
    rc_holes = [[rc_bore]]
    for i in range(4):                     # M4 stack bolts
        bx, by = _rot(R_BOLTS, 0.0, i * 90.0)
        rc_holes.append([cad.circle2d(cad.point2d(round(bx, 3), round(by, 3)), 2.2)])
    for i in range(N_POLES):               # magnet windows
        ang = i * 360.0 / N_POLES
        rc_holes.append(_quad(
            [_rot(MAG_RIN - POCKET_CLEAR, -(MAG_HALF_W + POCKET_CLEAR), ang),
             _rot(MAG_ROUT + POCKET_CLEAR, -(MAG_HALF_W + POCKET_CLEAR), ang),
             _rot(MAG_ROUT + POCKET_CLEAR, MAG_HALF_W + POCKET_CLEAR, ang),
             _rot(MAG_RIN - POCKET_CLEAR, MAG_HALF_W + POCKET_CLEAR, ang)]))
    rc_in = _rot(100.0, 0.0, 360.0 / N_POLES / 2.0)
    rc_body = cad.extrude("xy",
                          cad.region(loop=[rc_outer], holes=rc_holes,
                                     inside=(round(rc_in[0], 3), round(rc_in[1], 3))),
                          CARRIER_T)
    cad.set_color(rc_body, "#F57C00", finish="matte")
    cad.component_export(rc_body, name="disc")

cad.instance("rotor_carrier", translate=(0, 0, Z_ROTOR), name="carrier_top")
cad.instance("rotor_carrier", translate=(0, 0, -(Z_ROTOR + CARRIER_T)), name="carrier_bot")

# =============================================================================
# Steel back-iron disc — purchased laser-cut, 3 mm mild steel. Visual only.
# =============================================================================
with cad.component("steel_disc", label="Back-iron disc (laser-cut steel)"):
    cad.with_sketch("xy")
    sd_outer = cad.circle2d(cad.point2d(0, 0), R_ROTOR)
    sd_bore = cad.circle2d(cad.point2d(0, 0), R_ROTOR_BORE)
    sd_holes = [[sd_bore]]
    for i in range(4):
        bx, by = _rot(R_BOLTS, 0.0, i * 90.0)
        sd_holes.append([cad.circle2d(cad.point2d(round(bx, 3), round(by, 3)), 2.2)])
    sd_body = cad.extrude("xy",
                          cad.region(loop=[sd_outer], holes=sd_holes, inside=(100.0, 20.0)),
                          STEEL_T, export=False)
    cad.set_color(sd_body, "#90A4AE", finish="metallic")
    cad.component_export(sd_body, name="disc")

cad.instance("steel_disc", translate=(0, 0, Z_ROTOR + CARRIER_T), name="steel_top",
             export=False)
cad.instance("steel_disc", translate=(0, 0, -(Z_ROTOR + CARRIER_T + STEEL_T)),
             name="steel_bot", export=False)

# =============================================================================
# Rotor hub — printed. Flange (R44 x 5, bolted through steel disc and carrier
# at R40) plus a shaft boss (R16 x 18, 15 mm bore; add a M4 grub screw or pin
# cross-drilled after printing to lock it to the shaft).
# =============================================================================
with cad.component("rotor_hub", label="Rotor hub (printed)"):
    cad.with_sketch("xy")
    rh_outer = cad.circle2d(cad.point2d(0, 0), 44.0)
    rh_shaft = cad.circle2d(cad.point2d(0, 0), 7.5)
    rh_holes = [[rh_shaft]]
    for i in range(4):
        bx, by = _rot(R_BOLTS, 0.0, i * 90.0)
        rh_holes.append([cad.circle2d(cad.point2d(round(bx, 3), round(by, 3)), 2.2)])
    rh_flange = cad.extrude("xy",
                            cad.region(loop=[rh_outer], holes=rh_holes, inside=(25.0, 0.0)),
                            5.0)
    # boss as a zx-revolve so its circles don't subdivide the flange's xy sketch
    cad.with_sketch("zx")
    rb_prof = [(7.5, 5.0), (16.0, 5.0), (16.0, 23.0), (7.5, 23.0)]
    rb_pts = [cad.point2d(r, z) for (r, z) in rb_prof]
    rb_lines = [cad.line2d(rb_pts[j], rb_pts[j + 1]) for j in range(len(rb_pts) - 1)]
    rb_lines.append(cad.line2d(rb_pts[-1], rb_pts[0]))
    rb_axis = cad.line2d(cad.point2d(0.0, 5.0), cad.point2d(0.0, 23.0),
                         construction=True)
    rh_boss = cad.revolve("zx", cad.region(loop=rb_lines, inside=(11.75, 14.0)),
                          axis_line=rb_axis, angle=360)
    rh_body = cad.bool_union(rh_flange, rh_boss)
    cad.set_color(rh_body, "#00695C", finish="matte")
    cad.component_export(rh_body, name="hub")

Z_HUB = Z_ROTOR + CARRIER_T + STEEL_T          # 21.5 — flange seats on steel disc
cad.instance("rotor_hub", translate=(0, 0, Z_HUB), name="hub_top")
cad.instance("rotor_hub", mirror_plane="xy", translate=(0, 0, -Z_HUB), name="hub_bot")

# =============================================================================
# Bearings — purchased 6902 (15 x 28 x 7), one in each stator hub seat.
# =============================================================================
BRG = bearing(cad, designation="6902")
cad.instance(BRG, translate=(0, 0, -16), name="brg_low", export=False)
cad.instance(BRG, translate=(0, 0, 9), name="brg_high", export=False)


cad.with_sketch("xy")
p327 = cad.point2d(-3.66, 207.71)
p328 = cad.point2d(-285, 207.1)
l329 = cad.line2d(p327, p328)
p330 = cad.point2d(-282.91, -206.5)
l331 = cad.line2d(p328, p330)
p332 = cad.point2d(9.27, -208.44)
l333 = cad.line2d(p330, p332)
cad.point_on_circle(point=p327, circle=stator_outer)
cad.point_on_circle(point=p332, circle=stator_outer)
cad.horizontal(line=l329)
cad.horizontal(line=l333)
cad.vertical(line=l331)
cad.point_line_distance(point=origin_xy, line=l331, distance=250)