# flywheelcad standard library
"""Pins & retaining rings: dowel pins, slotted spring pins, E-clips, snap
(circlip) retaining rings, clevis pins, and cotter (split) pins.

Dimensions follow common metric fastener catalog proportions:
    dowel_pin       ISO 2338 (parallel dowel pin, h8 tolerance) -- plain
                    cylinder with a small lead-in chamfer at each end
    spring_pin      ISO 8752 (slotted spring / roll pin) -- a rolled tube
                    with a longitudinal slit so it compresses into a bore
    e_clip          DIN 6799 (E-ring / external circlip for small shafts)
    retaining_ring  DIN 471 (external, on a shaft) / DIN 472 (internal, in
                    a bore) snap ring -- flat C-annulus with a spring gap
    clevis_pin      ISO 2341 (clevis pin, form B) -- headed pin with a
                    cross cotter-hole through the shank near the tip
    cotter_pin      ISO 1234 / DIN 94 (split/cotter pin) -- simplified as a
                    single shank with a looped eye (a torus) at the head
                    end, in place of two splayed half-round legs

All parts are proportioned from their one free dimension (diameter / shaft
/ bore) using the catalog ratios cited per factory below -- this is not a
lookup-table library (no discrete size series), so only "quality" (and
retaining_ring's "kind") are enumerated; every other parameter is
continuous free-text.

Anchor contract:
    dowel_pin       end_a (0,0,0), end_b (0,0,length)   -- axis +Z
    spring_pin      end_a (0,0,0), end_b (0,0,length)   -- axis +Z
    e_clip          center (0,0,0)                       -- lies in XY, z=0..t
    retaining_ring  center (0,0,0)                       -- lies in XY, z=0..t
    clevis_pin      head (0,0,0), tip (0,0,-length)      -- head at top,
                    shank down -Z
    cotter_pin      eye (0,0,length), tip (0,0,0)        -- axis +Z, eye at top
"""

__library_version__ = "1.0"

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float -- a variable or list(...) call yields NO dropdown.
# diameter/length/shaft/bore are continuous -> free-text; only "kind" (the
# internal/external variant of retaining_ring) and "quality" are enumerated.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "retaining_ring": {"kind": ["internal", "external"]},
}

_STEEL = "#B0BEC5"


def _plane_at(cad, z):
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _rect(cad, x0, y0, x1, y1):
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _revolve_profile(cad, pts, inside, quality, on_axis=True):
    """Revolve a (radius, height) profile on ZX about the axis at r = 0.

    on_axis=True: the profile touches r = 0, so the closing edge IS the axis.
    on_axis=False: annular profile -- a separate r = 0 construction axis.
    """
    cad.with_sketch("zx")
    p = [cad.point2d(r, z) for (r, z) in pts]
    lines = [cad.line2d(p[i], p[i + 1]) for i in range(len(p) - 1)]
    lines.append(cad.line2d(p[-1], p[0]))
    if on_axis:
        axis = lines[-1]
    else:
        zmin = min(z for (_, z) in pts)
        zmax = max(z for (_, z) in pts)
        axis = cad.line2d(cad.point2d(0.0, zmin), cad.point2d(0.0, zmax),
                          construction=True)
    return cad.revolve("zx", cad.region(loop=lines, inside=inside),
                       axis_line=axis, angle=360.0, quality=quality, export=False)


# Dimensions per ISO 2338 (parallel dowel pin, h8 tolerance)
def dowel_pin(cad, diameter=5.0, length=16.0, quality=None):
    """An ISO 2338 hardened dowel pin (h8 tolerance): a plain cylinder with
    a small lead-in chamfer at each end. Axis +Z. Anchors: end_a (0,0,0),
    end_b (0,0,length)."""
    diameter = float(diameter)
    length = float(length)

    def build():
        r = diameter / 2.0
        chamfer = min(diameter * 0.15, length * 0.15, 1.0)
        solid = _revolve_profile(cad, [
            (0.0, 0.0), (r - chamfer, 0.0), (r, chamfer),
            (r, length - chamfer), (r - chamfer, length), (0.0, length),
        ], inside=(r / 2.0, length / 2.0), quality=quality)
        cad.set_color(solid, _STEEL, finish="metallic")
        cad.component_export(solid)
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(0.0, 0.0, length))

    return cad.parametric("dowel_pin", build, diameter=diameter, length=length,
                          quality=quality or "std",
                          label=f"Ø{diameter:g} x {length:g} dowel pin")


# Dimensions per ISO 8752 (slotted spring / roll pin)
def spring_pin(cad, diameter=4.0, length=20.0, quality=None):
    """An ISO 8752 slotted spring (roll) pin: a rolled tube (wall ~0.12 x
    diameter) with a chamfer at each end and a longitudinal slit so the pin
    compresses into a drilled hole. Axis +Z. Anchors: end_a (0,0,0),
    end_b (0,0,length), slit_a/slit_b (the slit mouth's midline at each end,
    on +Y at the outer radius -- off-axis, so a second point-mate here pins
    rotation about the pin's length, referencing the slit's orientation)."""
    diameter = float(diameter)
    length = float(length)

    def build():
        r_out = diameter / 2.0
        wall = diameter * 0.12
        r_in = r_out - wall
        chamfer = wall * 0.3
        tube = _revolve_profile(cad, [
            (r_in, 0.0), (r_out - chamfer, 0.0), (r_out, chamfer),
            (r_out, length - chamfer), (r_out - chamfer, length), (r_in, length),
        ], inside=((r_in + r_out) / 2.0, length / 2.0), quality=quality,
           on_axis=False)

        # Longitudinal slit: a thin box from the bore out past the OD,
        # running the full length -- cut on its own fresh page, never a
        # second profile on the shared 'zx' revolve page.
        slot_w = max(wall * 0.9, 0.25)
        slot_plane = _plane_at(cad, 0.0)
        cad.with_sketch(slot_plane)
        slot_outline = _rect(cad, -slot_w / 2.0, 0.0, slot_w / 2.0, r_out + 1.0)
        slot = cad.extrude(slot_plane,
                           cad.region(loop=slot_outline, inside=(0.0, r_out * 0.5)),
                           length + 1.0, offset=-0.5, quality=quality, export=False)

        pin = cad.bool_difference(tube, slot, quality=quality)
        cad.set_color(pin, _STEEL, finish="metallic")
        cad.component_export(pin)
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(0.0, 0.0, length))
        # Off-axis rotation-pinning references on the slit (the pin's one
        # azimuthal feature; the slit outline runs +Y from the bore out past
        # the OD) -- same pattern as the rail's corner_a/corner_b
        # (library-mate-points-other-part-classes).
        cad.component_export_point("slit_a", cad.point(0.0, r_out, 0.0))
        cad.component_export_point("slit_b", cad.point(0.0, r_out, length))

    return cad.parametric("spring_pin", build, diameter=diameter, length=length,
                          quality=quality or "std",
                          label=f"Ø{diameter:g} x {length:g} spring pin")


# Dimensions per DIN 6799 (E-ring / external circlip)
def e_clip(cad, shaft=6.0, quality=None):
    """A DIN 6799 E-clip (external retaining ring): a flat annulus sized for
    a shaft groove, open on one side (a C, not a closed ring) so it can be
    sprung onto the shaft. Lies flat in XY, z=0..thickness. Anchor: center
    (0,0,0). shaft is a free dimension (mm)."""
    shaft = float(shaft)

    def build():
        inner_r = shaft * 0.4
        outer_r = shaft * 1.1
        t = shaft * 0.12
        cad.with_sketch("xy")
        outer_c = cad.circle2d(cad.point2d(0.0, 0.0), outer_r)
        inner_c = cad.circle2d(cad.point2d(0.0, 0.0), inner_r)
        ring = cad.extrude("xy",
                           cad.region(loop=[outer_c], holes=[[inner_c]],
                                      inside=((inner_r + outer_r) / 2.0, 0.0)),
                           t, quality=quality, export=False)

        # Mouth gap on +X: its own custom plane (even though coincident with
        # the ring's own base at z=0) so its outline never shares 'xy' with
        # the ring's loop above.
        gap = max(shaft * 0.18, 0.6)
        mouth_plane = _plane_at(cad, 0.0)
        cad.with_sketch(mouth_plane)
        mouth_outline = _rect(cad, inner_r - 0.5, -gap / 2.0, outer_r + 1.0, gap / 2.0)
        mouth = cad.extrude(mouth_plane,
                            cad.region(loop=mouth_outline,
                                       inside=((inner_r + outer_r) / 2.0, 0.0)),
                            t + 1.0, offset=-0.5, quality=quality, export=False)

        clip = cad.bool_difference(ring, mouth, quality=quality)
        cad.set_color(clip, _STEEL, finish="metallic")
        cad.component_export(clip)
        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("e_clip", build, shaft=shaft, quality=quality or "std",
                          label=f"E-clip (shaft {shaft:g})")


# Dimensions per DIN 471 (external) / DIN 472 (internal) retaining ring
def retaining_ring(cad, bore=20.0, kind="internal", quality=None):
    """A DIN 471 (external, sprung onto a shaft) / DIN 472 (internal,
    sprung into a bore) snap retaining ring: a flat C-annulus with a spring
    gap on +X. "internal" sizes the ring OD to the bore (springs outward);
    "external" sizes the ring ID to the shaft (springs inward). Lies flat
    in XY, z=0..thickness. Anchor: center (0,0,0). bore is a free
    dimension (mm, the bore or shaft diameter depending on kind)."""
    bore = float(bore)
    kind = str(kind).lower()
    internal = kind != "external"

    def build():
        width = max(bore * 0.08, 0.6)
        thickness = max(0.6, min(3.0, bore * 0.07))
        if internal:
            outer_r = bore / 2.0
            inner_r = outer_r - width
        else:
            inner_r = bore / 2.0
            outer_r = inner_r + width

        cad.with_sketch("xy")
        outer_c = cad.circle2d(cad.point2d(0.0, 0.0), outer_r)
        inner_c = cad.circle2d(cad.point2d(0.0, 0.0), inner_r)
        ring = cad.extrude("xy",
                           cad.region(loop=[outer_c], holes=[[inner_c]],
                                      inside=((inner_r + outer_r) / 2.0, 0.0)),
                           thickness, quality=quality, export=False)

        gap = max(width * 1.3, 0.6)
        mouth_plane = _plane_at(cad, 0.0)
        cad.with_sketch(mouth_plane)
        mouth_outline = _rect(cad, inner_r - 0.5, -gap / 2.0, outer_r + 1.0, gap / 2.0)
        mouth = cad.extrude(mouth_plane,
                            cad.region(loop=mouth_outline,
                                       inside=((inner_r + outer_r) / 2.0, 0.0)),
                            thickness + 1.0, offset=-0.5, quality=quality, export=False)

        ring = cad.bool_difference(ring, mouth, quality=quality)
        cad.set_color(ring, _STEEL, finish="metallic")
        cad.component_export(ring)
        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("retaining_ring", build,
                          kind=("internal" if internal else "external"),
                          bore=bore, quality=quality or "std",
                          label=f"{'Internal' if internal else 'External'} retaining ring (bore {bore:g})")


# Dimensions per ISO 2341 (clevis pin, form B)
def clevis_pin(cad, diameter=5.0, length=20.0, quality=None):
    """An ISO 2341 clevis pin: a cylindrical shank with a flat head at one
    end and a cross cotter-hole through the shank near the tip. Head at
    z=0 (top), shank down -Z. Anchors: head (0,0,0), tip (0,0,-length)."""
    diameter = float(diameter)
    length = float(length)

    def build():
        shank_r = diameter / 2.0
        head_r = diameter * 0.8
        head_t = diameter * 0.4
        solid = _revolve_profile(cad, [
            (0.0, -length), (shank_r, -length), (shank_r, 0.0),
            (head_r, 0.0), (head_r, head_t), (0.0, head_t),
        ], inside=(shank_r / 2.0, -length / 2.0), quality=quality)

        # Cross cotter-hole near the tip: a through-bore along the 'yz'
        # plane's normal (+X), perpendicular to the pin axis.
        hole_r = diameter * 0.25 / 2.0
        z_hole = min(-length + max(diameter * 1.0, hole_r * 3.0), -diameter * 0.6)
        cad.with_sketch("yz")
        hole_c = cad.circle2d(cad.point2d(0.0, z_hole), hole_r)
        hole = cad.extrude("yz",
                           cad.region(loop=[hole_c], inside=(0.0, z_hole)),
                           2.0 * (shank_r + 1.0), offset=-(shank_r + 1.0),
                           quality=quality, export=False)

        pin = cad.bool_difference(solid, hole, quality=quality)
        cad.set_color(pin, _STEEL, finish="metallic")
        cad.component_export(pin)
        cad.component_export_point("head", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, -length))

    return cad.parametric("clevis_pin", build, diameter=diameter, length=length,
                          quality=quality or "std",
                          label=f"Ø{diameter:g} x {length:g} clevis pin")


# Dimensions per ISO 1234 / DIN 94 (split/cotter pin)
def cotter_pin(cad, diameter=3.2, length=40.0, quality=None):
    """An ISO 1234 / DIN 94 split (cotter) pin, simplified as a single
    shank with a looped eye (a small torus) at the head end, in place of
    two splayed half-round legs. Axis +Z, eye at top. Anchors: eye
    (0,0,length), tip (0,0,0)."""
    diameter = float(diameter)
    length = float(length)

    def build():
        r = diameter / 2.0
        shank = _revolve_profile(cad, [
            (0.0, 0.0), (r, 0.0), (r, length), (0.0, length),
        ], inside=(r / 2.0, length / 2.0), quality=quality)

        # Eye: a torus (revolve of a small offset circle) resting just
        # above the shank's top end. It is a second revolve profile on the
        # shared 'zx' page, so a deliberate small +Z gap above the shank
        # keeps the two loops from ever overlapping in (radius, height).
        tube_r = diameter * 0.4
        major_r = diameter * 0.5
        gap = max(diameter * 0.05, 0.15)
        center_z = length + tube_r + gap
        cad.with_sketch("zx")
        circ = cad.circle2d(cad.point2d(major_r, center_z), tube_r)
        eye_axis = cad.line2d(cad.point2d(0.0, center_z - tube_r - 0.1),
                              cad.point2d(0.0, center_z + tube_r + 0.1),
                              construction=True)
        eye = cad.revolve("zx", cad.region(loop=[circ], inside=(major_r, center_z)),
                          axis_line=eye_axis, angle=360.0, quality=quality, export=False)

        pin = cad.bool_union(shank, eye, quality=quality)
        cad.set_color(pin, _STEEL, finish="metallic")
        cad.component_export(pin)
        cad.component_export_point("eye", cad.point(0.0, 0.0, length))
        cad.component_export_point("tip", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("cotter_pin", build, diameter=diameter, length=length,
                          quality=quality or "std",
                          label=f"Ø{diameter:g} x {length:g} cotter pin")
