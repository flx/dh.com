# flywheelcad standard library
"""Hobby servos and control horns.

Parametric RC-servo bodies in the four ubiquitous case classes, with the
mounting interface and output spline as named anchors, plus matching
control horns (arms). Dimensions are nominal catalog-class values for the
most common parts of each class (TowerPro SG90 / MG90S, the Futaba
S3003 / Hitec HS-422 standard case, and the HS-805 giant case); real
parts vary by fractions of a millimeter between vendors.

Sizes:
    "sub_micro"  9 g class  (SG90)
    "micro"      13 g metal-gear class (MG90S)
    "standard"   40 mm class (S3003 / HS-422 / MG996R)
    "large"      66 mm giant class (HS-805BB)

Servo anchor contract:
    mount_0..N   mounting-screw positions on the flange (z = 0 is the
                 flange underside — the surface that sits on the mount)
    spline_base  output spline where it leaves the gear boss
    spline_tip   top of the output spline (a horn's `hub` mates here)

Servo orientation: flange underside on the world XY plane at z = 0, case
hanging -Z below it, output spline up +Z, offset toward +X (the "front").

Horn anchor contract: `hub` (bottom center of the hub, mates onto a
servo's spline_tip) and `tip` / `tip_0..N` at the outer linkage hole of
each arm, on the horn's top face. Pushrods attach at the tips.
"""

__library_version__ = "1.0"

import math

# Nominal case-class dimensions (mm). Heights measured from the case
# bottom; the model shifts everything so the flange UNDERSIDE is z = 0.
SERVO = {
    "sub_micro": dict(body_l=23.0, body_w=12.2, flange_l=32.2, flange_t=2.5,
                      under_flange=19.5, case_top=26.5, boss_top=28.5,
                      spline_top=32.0, spline_r=2.3, gear2_r=3.0,
                      holes=[(13.75, 0.0), (-13.75, 0.0)], hole_r=1.0),
    "micro":     dict(body_l=22.8, body_w=12.2, flange_l=32.6, flange_t=2.5,
                      under_flange=19.4, case_top=26.7, boss_top=28.8,
                      spline_top=31.6, spline_r=2.35, gear2_r=3.0,
                      holes=[(13.9, 0.0), (-13.9, 0.0)], hole_r=1.0),
    "standard":  dict(body_l=40.5, body_w=20.2, flange_l=53.6, flange_t=3.0,
                      under_flange=26.7, case_top=32.5, boss_top=38.0,
                      spline_top=42.0, spline_r=2.95, gear2_r=4.5,
                      holes=[(24.75, 5.0), (-24.75, 5.0), (-24.75, -5.0), (24.75, -5.0)],
                      hole_r=1.55),
    "large":     dict(body_l=66.0, body_w=30.0, flange_l=82.8, flange_t=4.0,
                      under_flange=40.0, case_top=49.0, boss_top=56.0,
                      spline_top=60.0, spline_r=4.0, gear2_r=6.0,
                      holes=[(37.45, 8.9), (-37.45, 8.9), (-37.45, -8.9), (37.45, -8.9)],
                      hole_r=2.8),
}

# Horn (control arm) classes, matched to the servo output spline sizes.
HORN = {
    "micro":    dict(hub_r=3.5, hub_h=3.8, plate_t=1.6, arm_len=19.0,
                     root_w=5.5, tip_w=3.6, hole_r=0.55, hole_step=2.2, hole_count=4),
    "standard": dict(hub_r=5.0, hub_h=5.2, plate_t=2.0, arm_len=25.4,
                     root_w=7.5, tip_w=4.6, hole_r=0.75, hole_step=3.0, hole_count=4),
    "large":    dict(hub_r=6.5, hub_h=6.5, plate_t=2.6, arm_len=38.0,
                     root_w=10.0, tip_w=6.0, hole_r=1.0, hole_step=4.0, hole_count=5),
}

# Dropdown choices for the browser's "Insert from Library" parameter form.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "servo": {"size": ["sub_micro", "micro", "standard", "large"]},
    "horn": {
        "style": ["single", "double", "cross", "disc"],
        "spline": ["micro", "standard", "large"],
    },
}


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y)."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list)."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def servo(cad, size="standard", quality=None):
    """A hobby servo: case, mounting flange with screw holes, gear-head
    bosses, and output spline.

    size:    "sub_micro", "micro", "standard", or "large"
    quality: mesh quality preset forwarded to the body commands

    Returns a component name for cad.instance(...). See the module
    docstring for the anchor contract and orientation.
    """
    key = str(size)
    d = SERVO[key]

    def build():
        under = d["under_flange"]
        hl, hw = d["body_l"] / 2.0, d["body_w"] / 2.0
        axis_x = hl - hw          # spline axis: one case-width from the front
        z_case_top = d["case_top"] - under
        z_boss_top = d["boss_top"] - under
        z_spline_top = d["spline_top"] - under

        parts = []

        # Case: rounded box from the bottom up past the flange.
        case_plane = _plane_at(cad, -under)
        cad.with_sketch(case_plane)
        case_outline = _rect(cad, -hl, -hw, hl, hw)
        parts.append(cad.extrude(case_plane,
                                 cad.region(loop=case_outline, inside=(0.0, 0.0)),
                                 d["case_top"], quality=quality,
                                 edge_radius=0.8, export=False))

        # Mounting flange on XY (underside = z 0), screw holes nested.
        fl = d["flange_l"] / 2.0
        cad.with_sketch("xy")
        flange_outline = _rect(cad, -fl, -hw, fl, hw)
        screw_holes = [cad.circle2d(cad.point2d(mx, my), d["hole_r"]) for (mx, my) in d["holes"]]
        parts.append(cad.extrude("xy",
                                 cad.region(loop=flange_outline,
                                            holes=[[c] for c in screw_holes],
                                            inside=(0.0, hw - 1.0)),
                                 d["flange_t"], quality=quality, export=False))

        # Gear-head: output boss on the axis, second (idler) boss behind it.
        gear_plane = _plane_at(cad, z_case_top - 0.5)
        cad.with_sketch(gear_plane)
        boss_r = hw - 0.2
        boss_c = cad.circle2d(cad.point2d(axis_x, 0.0), boss_r)
        g2_r = d["gear2_r"]
        g2_x = axis_x - boss_r - g2_r - 0.6
        g2_c = cad.circle2d(cad.point2d(g2_x, 0.0), g2_r)
        boss_h = z_boss_top - (z_case_top - 0.5)
        parts.append(cad.extrude(gear_plane,
                                 cad.region(loop=[boss_c], inside=(axis_x, 0.0)),
                                 boss_h, quality=quality, export=False))
        parts.append(cad.extrude(gear_plane,
                                 cad.region(loop=[g2_c], inside=(g2_x, 0.0)),
                                 boss_h - 1.0, quality=quality, export=False))

        # Output spline.
        spline_plane = _plane_at(cad, z_boss_top)
        cad.with_sketch(spline_plane)
        spline_c = cad.circle2d(cad.point2d(axis_x, 0.0), d["spline_r"])
        parts.append(cad.extrude(spline_plane,
                                 cad.region(loop=[spline_c], inside=(axis_x, 0.0)),
                                 z_spline_top - z_boss_top, quality=quality, export=False))

        # Wire exit stub low on the rear face.
        wire_plane = _plane_at(cad, -under + 5.0)
        cad.with_sketch(wire_plane)
        wire_outline = _rect(cad, -hl - 2.5, -2.5, -hl + 1.0, 2.5)
        parts.append(cad.extrude(wire_plane,
                                 cad.region(loop=wire_outline, inside=(-hl - 0.5, 0.0)),
                                 3.5, offset=-3.5, quality=quality, export=False))

        body = cad.bool_union(*parts, quality=quality)
        cad.set_color(body, "#263238", finish="matte")
        cad.component_export(body)

        for i, (mx, my) in enumerate(d["holes"]):
            cad.component_export_point(f"mount_{i}", cad.point(mx, my, 0.0))
        cad.component_export_point("spline_base", cad.point(axis_x, 0.0, z_boss_top))
        cad.component_export_point("spline_tip", cad.point(axis_x, 0.0, z_spline_top))

    return cad.parametric(f"servo_{key}", build, quality=quality or "std",
                          label=f"{key.replace('_', ' ').title()} servo")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def horn(cad, style="single", spline="standard", length=None, quality=None):
    """A servo control horn (arm) with linkage holes.

    style:  "single", "double" (2 arms at 180°), "cross" (4 arms at 90°),
            or "disc" (round wheel with a rim hole circle)
    spline: "micro", "standard", or "large" — matches the servo class
            (sub_micro and micro servos both take "micro" horns)
    length: arm length in mm, hub center to tip (default per class);
            for "disc" this is the wheel RADIUS
    quality: mesh quality preset forwarded to the body commands

    Returns a component name for cad.instance(...). The `hub` anchor is
    the bottom center — mate it onto a servo's `spline_tip`. Arm tips
    expose `tip` (single) or `tip_0..N`, at the outermost linkage hole.
    """
    key = str(spline)
    d = HORN[key]
    arm_len = float(length if length is not None else d["arm_len"])
    kind = str(style)

    def build():
        hub_r, hub_h, plate_t = d["hub_r"], d["hub_h"], d["plate_t"]
        z_plate = hub_h - plate_t

        parts = []

        # Hub cylinder on XY.
        cad.with_sketch("xy")
        hub_c = cad.circle2d(cad.point2d(0.0, 0.0), hub_r)
        parts.append(cad.extrude("xy", cad.region(loop=[hub_c], inside=(0.0, 0.0)),
                                 hub_h, quality=quality, export=False))

        angles = {"single": [0.0], "double": [0.0, 180.0],
                  "cross": [0.0, 90.0, 180.0, 270.0]}.get(kind)
        tips = []

        if angles is None:
            # Disc wheel: one plate with a rim hole circle.
            disc_plane = _plane_at(cad, z_plate)
            cad.with_sketch(disc_plane)
            rim = arm_len
            disc_c = cad.circle2d(cad.point2d(0.0, 0.0), rim)
            hole_ring = rim - 3.0 * d["hole_r"] - 1.0
            rim_holes = []
            for k in range(6):
                a = math.radians(60.0 * k + 30.0)
                rim_holes.append(cad.circle2d(
                    cad.point2d(hole_ring * math.cos(a), hole_ring * math.sin(a)),
                    d["hole_r"]))
            parts.append(cad.extrude(disc_plane,
                                     cad.region(loop=[disc_c],
                                                holes=[[c] for c in rim_holes],
                                                inside=(0.0, -rim + 1.0)),
                                     plate_t, quality=quality, export=False))
            for k in range(6):
                a = math.radians(60.0 * k + 30.0)
                tips.append((f"rim_{k}", hole_ring * math.cos(a), hole_ring * math.sin(a)))
        else:
            # Tapered arm plate per angle, each on its own plane so the 2D
            # outlines never intersect in one sketch. Linkage holes nest
            # inside each outline.
            for k, deg in enumerate(angles):
                a = math.radians(deg)
                ca, sa = math.cos(a), math.sin(a)

                def rot(x, y):
                    return (x * ca - y * sa, x * sa + y * ca)

                root_w, tip_w = d["root_w"], d["tip_w"]
                corners = [(0.0, -root_w / 2.0), (arm_len, -tip_w / 2.0),
                           (arm_len, tip_w / 2.0), (0.0, root_w / 2.0)]
                arm_plane = _plane_at(cad, z_plate)
                cad.with_sketch(arm_plane)
                pts = [cad.point2d(*rot(x, y)) for (x, y) in corners]
                outline = [cad.line2d(pts[i], pts[(i + 1) % 4]) for i in range(4)]
                outer_x = arm_len - 2.0 * d["hole_r"] - 0.8
                link_holes = []
                for h in range(d["hole_count"]):
                    hx = outer_x - h * d["hole_step"]
                    link_holes.append(cad.circle2d(cad.point2d(*rot(hx, 0.0)), d["hole_r"]))
                parts.append(cad.extrude(arm_plane,
                                         cad.region(loop=outline,
                                                    holes=[[c] for c in link_holes],
                                                    inside=rot(arm_len * 0.35, 0.0)),
                                         plate_t, quality=quality, export=False))
                name = "tip" if kind == "single" else f"tip_{k}"
                tx, ty = rot(outer_x, 0.0)
                tips.append((name, tx, ty))

        body = cad.bool_union(*parts, quality=quality)
        cad.set_color(body, "#ECEFF1", finish="glossy")
        cad.component_export(body)

        cad.component_export_point("hub", cad.point(0.0, 0.0, 0.0))
        for (name, tx, ty) in tips:
            cad.component_export_point(name, cad.point(tx, ty, hub_h))

    return cad.parametric(f"horn_{key}_{kind}", build,
                          length=arm_len, quality=quality or "std",
                          label=f"{kind.title()} horn ({key})")
