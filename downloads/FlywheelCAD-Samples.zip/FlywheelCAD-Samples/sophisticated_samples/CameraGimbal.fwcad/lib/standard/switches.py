# flywheelcad standard library
"""Common panel-mount switches and rotary controls.

Five catalog-class parts. Threads, belt/knurl-style cosmetic detail are not
modeled to that level -- this is envelope + mounting-feature geometry:

    rocker_switch    KCD1-class rocker switch: 21x15mm body (the standard
                     KCD1 panel-cutout envelope), 27x22x2 bezel flange,
                     18x11x3 rocker actuator (dims representative of common
                     KCD1-101 boat/rocker switches).
    toggle_switch    MTS-101-class mini toggle: 13x8x10 body envelope, M6
                     threaded bushing (dia 6 x 8, the common MTS-101
                     bushing thread), 8mm-af hex nut sized for an M6
                     bushing, 2.5mm dia x 12mm lever (typical mini-toggle
                     lever).
    slide_switch     Small SPDT slide switch (e.g. SS-12F class): 9x4x3.5
                     body, 2.5x1.5x1.5 slider nub, 3 x 0.5mm-sq
                     through-hole pins (single-row SPDT pinout).
    potentiometer    WH148 / Alpha 9mm potentiometer: 12x12x8 body, M7
                     threaded bushing (dia 7 x 7, the standard WH148
                     bushing thread), 6mm dia x 15mm D-shaft (standard
                     WH148 shaft) -- hex-nut across-flats/thickness are
                     representative, not part of the WH148 spec.
    rotary_encoder   EC11-class rotary encoder with pushbutton: 12x12x7
                     body, M7 threaded bushing (dia 7 x 7, the common EC11
                     bushing thread), 6mm dia x 20mm D-shaft (common EC11
                     shaft length), 5 through-hole pins (2 switch + 3
                     encoder, the common EC11 pinout).

Orientation: every body sits BEHIND the panel (below z = 0, -Z). Threaded
bushings, nuts, shafts and levers rise IN FRONT of the panel (above z = 0,
+Z). rocker_switch and slide_switch have no bushing and build straight up
from z = 0 instead (rocker_switch's body still hangs below z = 0 -- see
its own docstring).

Anchor contract:
    rocker_switch    origin (0,0,0)
    toggle_switch    origin (0,0,0), lever_tip
    slide_switch     origin (0,0,0)
    potentiometer    base (0,0,0), shaft_tip
    rotary_encoder   base (0,0,0), shaft_tip
"""

__library_version__ = "1.0"

import math

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float -- a variable or list(...) call yields NO dropdown.
# So every choice list is spelled out literally here.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "potentiometer": {"shaft": ["round", "d_flat", "knurled"]},
}

_BLACK = "#212121"
_STEEL = "#90A4AE"
_ACCENT = "#E53935"


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y).

    Used to give a feature its OWN sketch page: if a LARGER shape were
    drawn AFTER a smaller one already sitting on the same page (both
    centered at the same point), the smaller shape becomes a hole of the
    larger one and the larger shape's "inside" point (its own center)
    would then fall IN that hole -- invalid. A fresh page avoids this by
    construction. (Smaller shapes drawn strictly AFTER a larger one on
    the SAME page, both nested and non-crossing, are fine -- see the
    body+nub+pins / body+legs style calls below.)"""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list) on the CURRENT sketch."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _hexagon(cad, af, cx=0.0, cy=0.0):
    """Hex outline (list of lines) from across-flats width, on the CURRENT
    sketch, flats top/bottom."""
    r = (af / 2.0) / math.cos(math.radians(30.0))
    pts = [cad.point2d(cx + r * math.cos(math.radians(60 * k + 30)),
                       cy + r * math.sin(math.radians(60 * k + 30))) for k in range(6)]
    return [cad.line2d(pts[i], pts[(i + 1) % 6]) for i in range(6)]


def _box(cad, plane, x0, y0, x1, y1, height, offset=None, quality=None, export=None):
    """A rectangular-prism extrude on `plane`; sketches its OWN outline."""
    cad.with_sketch(plane)
    outline = _rect(cad, x0, y0, x1, y1)
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    return cad.extrude(plane, cad.region(loop=outline, inside=(cx, cy)),
                       height, offset=offset, quality=quality, export=export)


def _cyl(cad, plane, radius, height, cx=0.0, cy=0.0, offset=None, quality=None, export=None):
    """A cylinder extrude on `plane`; sketches its OWN circle."""
    cad.with_sketch(plane)
    c = cad.circle2d(cad.point2d(cx, cy), radius)
    return cad.extrude(plane, cad.region(loop=[c], inside=(cx, cy)),
                       height, offset=offset, quality=quality, export=export)


def _hex_prism(cad, plane, af, height, cx=0.0, cy=0.0, offset=None, quality=None, export=None):
    """A hex-prism extrude on `plane`; sketches its OWN hex outline."""
    cad.with_sketch(plane)
    outline = _hexagon(cad, af, cx, cy)
    return cad.extrude(plane, cad.region(loop=outline, inside=(cx, cy)),
                       height, offset=offset, quality=quality, export=export)


# Dimensions per KCD1 industry-standard rocker-switch panel-cutout envelope (21x15mm)
def rocker_switch(cad, quality=None):
    """A KCD1-class panel rocker switch (21x15mm cutout).

    The body sits behind the panel (below z=0); the bezel flange overlaps
    the panel face in front of it (z=0..2); the rocker actuator sits on
    the bezel (z=2..5, a second color/export). Anchor: origin (0,0,0)."""
    BODY_X, BODY_Y, BODY_Z = 21.0, 15.0, 23.0
    BEZEL_X, BEZEL_Y, BEZEL_Z = 27.0, 22.0, 2.0
    ROCKER_X, ROCKER_Y, ROCKER_Z = 18.0, 11.0, 3.0

    def build():
        body = _box(cad, "xy", -BODY_X / 2.0, -BODY_Y / 2.0, BODY_X / 2.0, BODY_Y / 2.0,
                    BODY_Z, offset=-BODY_Z, quality=quality, export=False)
        bezel = _box(cad, _plane_at(cad, 0.0), -BEZEL_X / 2.0, -BEZEL_Y / 2.0,
                    BEZEL_X / 2.0, BEZEL_Y / 2.0, BEZEL_Z, quality=quality, export=False)
        housing = cad.bool_union(body, bezel, quality=quality)
        cad.set_color(housing, _BLACK, finish="matte")
        cad.component_export(housing)

        rocker = _box(cad, _plane_at(cad, BEZEL_Z), -ROCKER_X / 2.0, -ROCKER_Y / 2.0,
                     ROCKER_X / 2.0, ROCKER_Y / 2.0, ROCKER_Z, quality=quality)
        cad.set_color(rocker, _ACCENT, finish="matte")
        cad.component_export(rocker)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("rocker_switch", build, quality=quality or "std",
                          label="KCD1 panel rocker switch")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def toggle_switch(cad, quality=None):
    """A mini toggle switch (MTS-101 class).

    The body sits behind the panel (below z=0); an M6 threaded bushing
    (dia 6 x 8) rises from z=0 with an 8mm-af hex nut around its base,
    and a 2.5mm dia x 12mm lever rises from the bushing top. Anchors:
    origin (0,0,0), lever_tip."""
    BODY_X, BODY_Y, BODY_Z = 13.0, 8.0, 10.0
    BUSHING_D, BUSHING_H = 6.0, 8.0
    NUT_AF, NUT_H = 8.0, 2.0
    LEVER_D, LEVER_H = 2.5, 12.0
    lever_tip_z = BUSHING_H + LEVER_H

    def build():
        body = _box(cad, "xy", -BODY_X / 2.0, -BODY_Y / 2.0, BODY_X / 2.0, BODY_Y / 2.0,
                    BODY_Z, offset=-BODY_Z, quality=quality)
        cad.set_color(body, _BLACK, finish="matte")
        cad.component_export(body)

        bushing = _cyl(cad, _plane_at(cad, 0.0), BUSHING_D / 2.0, BUSHING_H,
                       quality=quality, export=False)
        nut = _hex_prism(cad, _plane_at(cad, 0.0), NUT_AF, NUT_H,
                         quality=quality, export=False)
        lever = _cyl(cad, _plane_at(cad, BUSHING_H), LEVER_D / 2.0, LEVER_H,
                     quality=quality, export=False)
        hardware = cad.bool_union(bushing, nut, lever, quality=quality)
        cad.set_color(hardware, _STEEL, finish="metallic")
        cad.component_export(hardware)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("lever_tip", cad.point(0.0, 0.0, lever_tip_z))

    return cad.parametric("toggle_switch", build, quality=quality or "std",
                          label="Mini toggle switch (MTS-101)")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def slide_switch(cad, quality=None):
    """An SPDT slide switch.

    The body sits on the panel/PCB (z=0..3.5); the slider nub sits on top
    (z=3.5..5.0, same plastic); 3 pins drop below (-Z, a second color/
    export). Anchor: origin (0,0,0)."""
    BODY_X, BODY_Y, BODY_Z = 9.0, 4.0, 3.5
    NUB_X, NUB_Y, NUB_Z = 2.5, 1.5, 1.5
    PIN_S = 0.5
    PIN_LEN = 3.0
    PIN_X = (-3.0, 0.0, 3.0)

    def build():
        # Body (biggest footprint) then nub (nested inside it) then pins
        # (nested inside body, and the center one inside the nub too) --
        # all drawn strictly in decreasing-size order and extruded right
        # away, so each region() always resolves to its own innermost,
        # hole-free face (same pattern as electronics.py tact_button).
        body = _box(cad, "xy", -BODY_X / 2.0, -BODY_Y / 2.0, BODY_X / 2.0, BODY_Y / 2.0,
                    BODY_Z, quality=quality, export=False)
        nub = _box(cad, "xy", -NUB_X / 2.0, -NUB_Y / 2.0, NUB_X / 2.0, NUB_Y / 2.0,
                   NUB_Z, offset=BODY_Z, quality=quality, export=False)
        housing = cad.bool_union(body, nub, quality=quality)
        cad.set_color(housing, _BLACK, finish="matte")
        cad.component_export(housing)

        pins = [_box(cad, "xy", px - PIN_S / 2.0, -PIN_S / 2.0, px + PIN_S / 2.0, PIN_S / 2.0,
                     PIN_LEN, offset=-PIN_LEN, quality=quality, export=False)
                for px in PIN_X]
        pin_body = cad.bool_union(*pins, quality=quality)
        cad.set_color(pin_body, _STEEL, finish="metallic")
        cad.component_export(pin_body)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("slide_switch", build, quality=quality or "std",
                          label="SPDT slide switch")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def potentiometer(cad, shaft="round", quality=None):
    """A WH148 / Alpha-class 9mm panel potentiometer.

    The body sits behind the panel (below z=0); an M7 threaded bushing
    (dia 7 x 7) rises from z=0 with a hex nut around its base (nut
    across-flats/thickness are representative, not part of the WH148
    spec), and a 6mm dia x 15mm D-shaft rises from the bushing top.
    shaft="round" is a plain cylinder; "d_flat" mills a flat on one side
    (subtracts a box); "knurled" is also a plain cylinder (the knurl is
    cosmetic and not modeled). Anchors: base (0,0,0), shaft_tip."""
    BODY_X, BODY_Y, BODY_Z = 12.0, 12.0, 8.0
    BUSHING_D, BUSHING_H = 7.0, 7.0
    NUT_AF, NUT_H = 10.0, 2.5
    SHAFT_D, SHAFT_H = 6.0, 15.0
    FLAT_DEPTH = 1.2
    variant = str(shaft).lower()
    shaft_tip_z = BUSHING_H + SHAFT_H

    def build():
        body = _box(cad, "xy", -BODY_X / 2.0, -BODY_Y / 2.0, BODY_X / 2.0, BODY_Y / 2.0,
                    BODY_Z, offset=-BODY_Z, quality=quality)
        cad.set_color(body, _BLACK, finish="matte")
        cad.component_export(body)

        bushing = _cyl(cad, _plane_at(cad, 0.0), BUSHING_D / 2.0, BUSHING_H,
                       quality=quality, export=False)
        nut = _hex_prism(cad, _plane_at(cad, 0.0), NUT_AF, NUT_H,
                         quality=quality, export=False)

        shaft_r = SHAFT_D / 2.0
        shaft_z0 = BUSHING_H
        shaft_cyl = _cyl(cad, _plane_at(cad, shaft_z0), shaft_r, SHAFT_H,
                         quality=quality, export=False)
        if variant == "d_flat":
            flat_x = shaft_r - FLAT_DEPTH
            cut_box = _box(cad, _plane_at(cad, shaft_z0 - 1.0), flat_x, -(shaft_r + 2.0),
                           shaft_r + 2.0, shaft_r + 2.0, SHAFT_H + 2.0,
                           quality=quality, export=False)
            shaft_final = cad.bool_difference(shaft_cyl, cut_box, quality=quality)
        else:
            shaft_final = shaft_cyl

        hardware = cad.bool_union(bushing, nut, shaft_final, quality=quality)
        cad.set_color(hardware, _STEEL, finish="metallic")
        cad.component_export(hardware)

        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("shaft_tip", cad.point(0.0, 0.0, shaft_tip_z))

    return cad.parametric(f"pot_{variant}", build, shaft=variant,
                          quality=quality or "std",
                          label=f"9mm potentiometer ({variant} shaft)")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def rotary_encoder(cad, quality=None):
    """An EC11-class rotary encoder with pushbutton.

    The body sits behind the panel (below z=0); an M7 threaded bushing
    (dia 7 x 7) rises from z=0; a 6mm dia x 20mm D-shaft (flat milled on
    one side) rises from the bushing top; 5 pins drop below the body (-Z,
    a second color/export with the bushing + shaft). Anchors: base
    (0,0,0), shaft_tip."""
    BODY_X, BODY_Y, BODY_Z = 12.0, 12.0, 7.0
    BUSHING_D, BUSHING_H = 7.0, 7.0
    SHAFT_D, SHAFT_H = 6.0, 20.0
    FLAT_DEPTH = 1.2
    PIN_D, PIN_LEN = 0.6, 4.0
    PIN_X = (-4.0, -2.0, 0.0, 2.0, 4.0)
    shaft_tip_z = BUSHING_H + SHAFT_H

    def build():
        body = _box(cad, "xy", -BODY_X / 2.0, -BODY_Y / 2.0, BODY_X / 2.0, BODY_Y / 2.0,
                    BODY_Z, offset=-BODY_Z, quality=quality)
        cad.set_color(body, _BLACK, finish="matte")
        cad.component_export(body)

        # Pins are drawn nested inside the (already-extruded) body footprint
        # on the SAME "xy" page, same safe decreasing-size pattern as above;
        # they end up in the metal export group below (a bool_union of
        # spatially disjoint parts is fine -- "disconnected components" is
        # benign, per the library authoring spec).
        pins = [_cyl(cad, "xy", PIN_D / 2.0, PIN_LEN, cx=px,
                     offset=-(BODY_Z + PIN_LEN), quality=quality, export=False)
                for px in PIN_X]

        bushing = _cyl(cad, _plane_at(cad, 0.0), BUSHING_D / 2.0, BUSHING_H,
                       quality=quality, export=False)
        shaft_r = SHAFT_D / 2.0
        shaft_z0 = BUSHING_H
        shaft_cyl = _cyl(cad, _plane_at(cad, shaft_z0), shaft_r, SHAFT_H,
                         quality=quality, export=False)
        flat_x = shaft_r - FLAT_DEPTH
        cut_box = _box(cad, _plane_at(cad, shaft_z0 - 1.0), flat_x, -(shaft_r + 2.0),
                       shaft_r + 2.0, shaft_r + 2.0, SHAFT_H + 2.0,
                       quality=quality, export=False)
        shaft_final = cad.bool_difference(shaft_cyl, cut_box, quality=quality)

        hardware = cad.bool_union(bushing, shaft_final, *pins, quality=quality)
        cad.set_color(hardware, _STEEL, finish="metallic")
        cad.component_export(hardware)

        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("shaft_tip", cad.point(0.0, 0.0, shaft_tip_z))

    return cad.parametric("rotary_encoder", build, quality=quality or "std",
                          label="EC11 rotary encoder w/ pushbutton")
