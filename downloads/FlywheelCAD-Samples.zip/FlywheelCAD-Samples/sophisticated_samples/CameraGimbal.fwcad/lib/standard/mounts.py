# flywheelcad standard library
"""Mounting / attachment hardware: a VESA monitor-adapter plate, a tripod
camera-mount boss, a V-groove skate wheel, a continuous (piano) hinge, and a
cable saddle clip.

Dimensions follow:
    vesa_mount    VESA FDMI (Flat Display Mounting Interface) hole patterns:
                  75x75mm (MIS-D), 100x100mm (MIS-D), 200x200mm (MIS-E/F) —
                  4x M4 clearance holes (dia 4.5) on the square pattern, plus
                  a central cable pass-through (dia 25, not part of the VESA
                  spec — representative). Plate margin (+30mm per side) and
                  6mm thickness are representative, not spec'd by VESA.
    tripod_mount  1/4"-20 UNC photographic tripod thread (ISO 1222 / ANSI
                  camera-mount standard); bore is the 1/4" (6.35mm) nominal
                  clearance diameter (thread cosmetic — a plain round hole).
                  Plate/boss envelope (30x30x4 plate, dia 12 x 8 boss) is a
                  representative small mounting-boss size, not part of the
                  thread spec.
    caster_wheel  Generic V-groove ("V-slot") linear-motion skate wheel, as
                  used on aluminium-extrusion V-rail (OpenBuilders-style):
                  an annular wheel with a V-notch riding groove around the
                  rim. diameter/bore are free parameters; width (10mm) and
                  notch geometry (~2mm deep) are representative.
    piano_hinge   Generic continuous ("piano") hinge: two flat leaves joined
                  by a rolled knuckle barrel. Leaf width 15mm, thickness
                  1.5mm, knuckle dia 4mm are a representative small-hardware
                  class (comparable to narrow 5/8" continuous hinge stock);
                  length is a free parameter. Screw hole size/spacing are
                  representative (not from a specific catalog part).
    cable_clip    Generic cable saddle / P-clip: a block with a semicircular
                  cable groove and a mounting foot with a screw clearance
                  hole (dia 3.5, per the task spec). Block envelope scales
                  with cable_d; foot/groove proportions are representative.

Orientation:
    vesa_mount    plate on world XY, z = 0 to 6 (thickness)
    tripod_mount  plate + boss on world XY, boss up +Z
    caster_wheel  axis +Z, face_a at z = 0, face_b at z = width
    piano_hinge   leaves flat in world XY (z = 0 to leaf thickness), hinge
                  axis (knuckle barrel) along +X at the seam (y = 0)
    cable_clip    block base on world XY at z = 0, cable groove runs +X

Anchor contract:
    vesa_mount    center (0,0,0), hole_0..3 (VESA bolt-hole centers, CCW
                  from (+pattern/2,+pattern/2))
    tripod_mount  center (0,0,0), top (0,0,12) (boss top face)
    caster_wheel  center (0,0,0), face_a (0,0,0), face_b (0,0,width)
    piano_hinge   end_a (0,0,0), end_b (length,0,0)
    cable_clip    origin (0,0,0)
"""

__library_version__ = "1.0"

import math

# VESA FDMI hole-pattern square side (mm).
VESA_PATTERN = {"75": 75.0, "100": 100.0, "200": 200.0}

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float — a variable or list(...) call yields NO dropdown.
# So every choice list is spelled out literally here. diameter/bore/length/
# cable_d stay free-text (continuous).
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "vesa_mount": {"pattern": ["75", "100", "200"]},
}

_ALU = "#CFD8DC"
_STEEL = "#90A4AE"
_DARK_PLASTIC = "#212121"
_BLACK_PLASTIC = "#37474F"


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list)."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y).

    Used to give a shape group its OWN sketch page even when it sits at the
    same height as other geometry: elements sharing one sketch page get
    intersected/split by area detection, which breaks a region() call that
    names an untouched loop. A fresh plane keeps overlapping-by-design shapes
    (later fused by bool_union) independent."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _revolve_profile(cad, pts, inside, quality, on_axis=True):
    """Revolve a (radius, height) profile on ZX about the axis at r = 0.

    on_axis=True: the profile touches r = 0, so the closing edge IS the axis.
    on_axis=False: annular profile — a separate r = 0 construction axis.
    """
    cad.with_sketch("zx")
    p = [cad.point2d(r, z) for (r, z) in pts]
    lines = [cad.line2d(p[i], p[i + 1]) for i in range(len(p) - 1)]
    lines.append(cad.line2d(p[-1], p[0]))
    if on_axis:
        axis = lines[-1]
    else:
        zmin = min(z for (_, z) in pts)
        zmax = max(z for (_, z) in pts)
        axis = cad.line2d(cad.point2d(0.0, zmin), cad.point2d(0.0, zmax),
                          construction=True)
    return cad.revolve("zx", cad.region(loop=lines, inside=inside),
                       axis_line=axis, angle=360.0, quality=quality, export=False)


# Dimensions per VESA FDMI (Flat Display Mounting Interface, MIS-D/E/F) hole-pattern standard (plate margin/thickness/cable hole are representative, not part of the VESA spec)
def vesa_mount(cad, pattern="100", quality=None):
    """A VESA (FDMI) monitor-mount adapter plate: a square plate with a
    central cable pass-through hole and 4 corner M4 clearance holes on the
    VESA bolt pattern. pattern: "75" (75x75mm), "100" (100x100mm), "200"
    (200x200mm). Plate side = pattern + 30mm margin, 6mm thick, on world XY
    (z = 0..6). Anchors: center (0,0,0), hole_0..3 (VESA bolt-hole centers,
    CCW starting at (+pattern/2, +pattern/2))."""
    key = str(pattern)
    p = VESA_PATTERN[key]
    half_p = p / 2.0
    side = p + 30.0
    half_side = side / 2.0
    thickness = 6.0
    hole_r = 4.5 / 2.0
    cable_r = 25.0 / 2.0

    def build():
        cad.with_sketch("xy")
        outline = _rect(cad, -half_side, -half_side, half_side, half_side)
        bolt_xy = [(half_p, half_p), (-half_p, half_p),
                  (-half_p, -half_p), (half_p, -half_p)]
        bolt_holes = [cad.circle2d(cad.point2d(hx, hy), hole_r) for (hx, hy) in bolt_xy]
        cable_hole = cad.circle2d(cad.point2d(0.0, 0.0), cable_r)
        plate_region = cad.region(loop=outline,
                                  holes=[[h] for h in bolt_holes] + [[cable_hole]],
                                  inside=((half_p + half_side) / 2.0, 0.0))
        plate = cad.extrude("xy", plate_region, thickness, quality=quality)
        cad.set_color(plate, _ALU, finish="matte")
        cad.component_export(plate)
        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(bolt_xy):
            cad.component_export_point(f"hole_{i}", cad.point(hx, hy, 0.0))

    return cad.parametric(f"vesa_{key}", build, quality=quality or "std",
                          label=f"VESA {key}x{key} mount plate")


# Dimensions per ISO 1222 / ANSI photographic tripod-mount standard (1/4"-20 UNC thread; boss/plate envelope is representative, not part of the thread spec)
def tripod_mount(cad, quality=None):
    """A 1/4"-20 camera/tripod mounting boss: a 30x30x4mm backing plate
    with a central raised cylindrical boss (dia 12, height 8) unioned on
    top, bored with a 1/4" (6.35mm) clearance hole straight through boss +
    plate. Anchors: center (0,0,0), top (0,0,12) (boss top face; plate 4 +
    boss 8)."""
    plate_s = 30.0
    plate_t = 4.0
    boss_d = 12.0
    boss_h = 8.0
    hole_r = 6.35 / 2.0
    total_h = plate_t + boss_h

    def build():
        half = plate_s / 2.0
        cad.with_sketch("xy")
        outline = _rect(cad, -half, -half, half, half)
        plate = cad.extrude("xy", cad.region(loop=outline, inside=(0.0, 0.0)),
                            plate_t, quality=quality, export=False)

        # Boss on its OWN plane, started slightly below the plate's top so
        # the two solids overlap in volume (not just touch at a flush
        # face) -- bool_union needs real overlap to fuse cleanly.
        embed = 0.5
        boss_plane = _plane_at(cad, plate_t - embed)
        cad.with_sketch(boss_plane)
        boss_c = cad.circle2d(cad.point2d(0.0, 0.0), boss_d / 2.0)
        boss = cad.extrude(boss_plane, cad.region(loop=[boss_c], inside=(0.0, 0.0)),
                           boss_h + embed, quality=quality, export=False)

        solid = cad.bool_union(plate, boss, quality=quality, export=False)

        # Bore on a third fresh plane, spanning well past both ends.
        bore_plane = _plane_at(cad, -1.0)
        cad.with_sketch(bore_plane)
        bore_c = cad.circle2d(cad.point2d(0.0, 0.0), hole_r)
        bore = cad.extrude(bore_plane, cad.region(loop=[bore_c], inside=(0.0, 0.0)),
                           total_h + 2.0, quality=quality, export=False)

        mount = cad.bool_difference(solid, bore, quality=quality)
        cad.set_color(mount, _ALU, finish="metallic")
        cad.component_export(mount)
        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, total_h))

    return cad.parametric("tripod_mount", build, quality=quality or "std",
                          label="1/4-20 tripod mount")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def caster_wheel(cad, diameter=24.0, bore=8.0, quality=None):
    """A V-groove skate/V-slot caster wheel: an annular revolve with a
    shallow V-notch groove around the outer rim at mid-width (rides on a
    V-slot/angle rail), bored `bore` straight through. Axis +Z, face_a at
    z=0, width fixed at 10mm. diameter/bore are free dimensions (mm).
    Anchors: center (0,0,0), face_a (0,0,0), face_b (0,0,width)."""
    diameter = float(diameter)
    bore = float(bore)
    outer_r = diameter / 2.0
    bore_r = bore / 2.0
    width = 10.0
    notch_depth = min(2.0, outer_r - bore_r - 0.5)
    notch_half_w = width * 0.15

    def build():
        mid = width / 2.0
        wheel = _revolve_profile(cad, [
            (bore_r, 0.0),
            (outer_r, 0.0),
            (outer_r, mid - notch_half_w),
            (outer_r - notch_depth, mid),
            (outer_r, mid + notch_half_w),
            (outer_r, width),
            (bore_r, width),
        ], inside=((bore_r + outer_r) / 2.0, width * 0.25), quality=quality,
           on_axis=False)
        cad.set_color(wheel, _DARK_PLASTIC, finish="matte")
        cad.component_export(wheel)
        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("face_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("face_b", cad.point(0.0, 0.0, width))

    return cad.parametric("caster_wheel", build, diameter=diameter, bore=bore,
                          quality=quality or "std",
                          label=f"V-groove wheel Ø{diameter:g} bore {bore:g}")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def piano_hinge(cad, length=100.0, quality=None):
    """A continuous ("piano") hinge: two flat leaves (each 15mm wide x
    1.5mm thick, running the full length) lying in the XY plane, joined by
    a rolled knuckle barrel (dia 4mm) along +X at the seam (y=0), plus 2
    screw clearance holes (dia 3.5, representative) per leaf. length is a
    free dimension (mm). Anchors: end_a (0,0,0), end_b (length,0,0),
    corner_a/corner_b (leaf A's outer bottom corner at each end -- off the
    hinge axis, so a second point-mate here pins rotation about it)."""
    length = float(length)
    barrel_r = 2.0
    leaf_w = 15.0
    leaf_t = 1.5
    overlap = 1.0             # leaf inner edge overlaps the barrel for union
    hole_r = 3.5 / 2.0
    leaf_inner = barrel_r - overlap
    leaf_outer = leaf_inner + leaf_w
    hole_xs = (length * 0.2, length * 0.8)

    def build():
        cad.with_sketch("xy")
        outline_a = _rect(cad, 0.0, leaf_inner, length, leaf_outer)
        mid_a = (leaf_inner + leaf_outer) / 2.0
        holes_a = [cad.circle2d(cad.point2d(hx, mid_a), hole_r) for hx in hole_xs]
        leaf_a = cad.extrude("xy",
                             cad.region(loop=outline_a, holes=[[h] for h in holes_a],
                                       inside=(length * 0.5, leaf_inner + leaf_w * 0.25)),
                             leaf_t, quality=quality, export=False)

        cad.with_sketch("xy")
        outline_b = _rect(cad, 0.0, -leaf_outer, length, -leaf_inner)
        mid_b = -(leaf_inner + leaf_outer) / 2.0
        holes_b = [cad.circle2d(cad.point2d(hx, mid_b), hole_r) for hx in hole_xs]
        leaf_b = cad.extrude("xy",
                             cad.region(loop=outline_b, holes=[[h] for h in holes_b],
                                       inside=(length * 0.5, -(leaf_inner + leaf_w * 0.25))),
                             leaf_t, quality=quality, export=False)

        # Knuckle barrel: axis +X (the "yz" plane's normal), centered on the
        # seam (y=0) at the leaves' mid-thickness so it overlaps both leaves.
        cad.with_sketch("yz")
        barrel_c = cad.circle2d(cad.point2d(0.0, leaf_t / 2.0), barrel_r)
        barrel = cad.extrude("yz", cad.region(loop=[barrel_c], inside=(0.0, leaf_t / 2.0)),
                             length, quality=quality, export=False)

        hinge = cad.bool_union(leaf_a, leaf_b, barrel, quality=quality)
        cad.set_color(hinge, _STEEL, finish="metallic")
        cad.component_export(hinge)
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(length, 0.0, 0.0))
        # Off-axis rotation-pinning references: leaf A's outer bottom corner
        # at each end (a genuine solid corner of the leaf) -- same pattern as
        # the rail's corner_a/corner_b (library-mate-points-other-part-classes).
        cad.component_export_point("corner_a", cad.point(0.0, leaf_outer, 0.0))
        cad.component_export_point("corner_b", cad.point(length, leaf_outer, 0.0))

    return cad.parametric("piano_hinge", build, length=length,
                          quality=quality or "std",
                          label=f"Piano hinge {length:g}mm")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def cable_clip(cad, cable_d=6.0, quality=None):
    """A cable saddle / P-clip: a block (width cable_d+8, depth cable_d+4,
    height cable_d/2+3) with a semicircular cable groove cut along +X (a
    round cylinder of radius cable_d/2 centered exactly at the top face, so
    only its lower half removes material) and a mounting foot extending to
    one side (+Y) with a screw clearance hole (dia 3.5) through it. Base at
    z=0. cable_d is a free dimension (mm). Anchor: origin (0,0,0)."""
    cable_d = float(cable_d)
    block_w = cable_d + 8.0
    block_d = cable_d + 4.0
    block_h = cable_d / 2.0 + 3.0
    groove_r = cable_d / 2.0

    foot_t = min(3.0, block_h * 0.6)
    foot_ext = 6.0
    foot_overlap = 1.5
    foot_hw = block_d / 2.0
    foot_cx = block_w / 2.0
    hole_r = 3.5 / 2.0

    def build():
        half_w = block_w / 2.0
        half_d = block_d / 2.0
        cad.with_sketch("xy")
        block_outline = _rect(cad, 0.0, -half_d, block_w, half_d)
        block = cad.extrude("xy", cad.region(loop=block_outline, inside=(half_w, 0.0)),
                            block_h, quality=quality, export=False)

        # Mounting foot: its own plane (fresh page), overlapping the block's
        # +Y edge by `foot_overlap` so bool_union fuses them solidly.
        foot_plane = _plane_at(cad, 0.0)
        cad.with_sketch(foot_plane)
        foot_y0 = half_d - foot_overlap
        foot_y1 = foot_y0 + foot_ext
        foot_outline = _rect(cad, foot_cx - foot_hw, foot_y0, foot_cx + foot_hw, foot_y1)
        foot_hole = cad.circle2d(cad.point2d(foot_cx, (foot_y0 + foot_y1) / 2.0), hole_r)
        # Inside point offset toward the far (+X) edge of the foot, well
        # clear of the hole's radius regardless of its y-position.
        foot_inside = (foot_cx + foot_hw - 0.5, (foot_y0 + foot_y1) / 2.0)
        foot = cad.extrude(foot_plane,
                           cad.region(loop=foot_outline, holes=[[foot_hole]],
                                     inside=foot_inside),
                           foot_t, quality=quality, export=False)

        base = cad.bool_union(block, foot, quality=quality, export=False)

        # Groove: a full cylinder along +X ("yz" plane normal), centered
        # exactly at the top face height -- only its lower half intersects
        # the block, leaving a clean semicircular channel open at the top.
        margin = 2.0
        cad.with_sketch("yz")
        groove_c = cad.circle2d(cad.point2d(0.0, block_h), groove_r)
        groove = cad.extrude("yz", cad.region(loop=[groove_c], inside=(0.0, block_h)),
                             block_w + 2.0 * margin, offset=-margin,
                             quality=quality, export=False)

        clip = cad.bool_difference(base, groove, quality=quality)
        cad.set_color(clip, _BLACK_PLASTIC, finish="matte")
        cad.component_export(clip)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("cable_clip", build, cable_d=cable_d,
                          quality=quality or "std",
                          label=f"Cable clip Ø{cable_d:g}")
