# flywheelcad standard library
"""Common hobby/maker microcontroller board footprints.

Each factory builds a representative board: a PCB slab of the correct
outline + the ACCURATE mounting-hole pattern (diameter and positions) +
a few representative blocks (headers, USB, a module can) so the part reads
as the board and a mounting plate/case can be designed around it. The hole
pattern is the point of these parts — dimensions are cited per factory
below and should not be treated as decorative.

Convention: every board's origin is its BOARD CENTER (not the mounting-hole
centroid) — simplest and consistent across all four board factories. Board
slabs sit z = 0..thickness (1.6 mm, 1.4 mm for Raspberry Pi); headers, USB
connectors, and module cans protrude +Z from the top face. Through-holes
run the full slab thickness. Every board exports `origin` (0,0,0) and
`mount_0..N` at each real mounting hole (z = 0).

Per the single-exported-body convention used across this library (one
`cad.component_export()` per factory, reached by `cad.bool_union(*parts)`), each
footprint is colored uniformly as PCB green rather than per-feature
(headers/connectors would otherwise be near-black/metallic) — a merged
body carries one color.

Dimension sources (see each factory's docstring for the exact figures):
    arduino_uno     Arduino UNO R3 official mechanical reference drawing
    arduino_nano    Arduino Nano datasheet outline + common 4-corner
                    mounting-hole footprint used by Nano carrier boards
    raspberry_pi    Raspberry Pi Foundation mechanical drawings (the
                    58 x 49 mm / 3.5 mm-inset hole pattern is unchanged
                    from Model B+ through 3B/4B; Zero uses 58 x 23 mm)
    esp32_devkit    Generic "ESP32 DevKit V1" 30-pin breakout board size
                    (widely cloned by HiLetgo/DOIT and others)
    pcb_standoff    Generic nylon board-support/snap-standoff catalog
                    dimensions (representative, not one exact part number)
"""

__library_version__ = "1.0"

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float — a variable or list(...) call yields NO dropdown.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "raspberry_pi": {"model": ["3B", "4B", "Zero"]},
}

_PCB = "#1B5E20"
_STANDOFF = "#ECEFF1"


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y)."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list)."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _slab(cad, hw, hd, thickness, holes, hole_r, quality=None):
    """Board slab centered on the origin: rectangle [-hw,hw] x [-hd,hd],
    full thickness 0..thickness, with round through mounting holes at
    `holes` (list of (x, y), board-center-relative). export=False.

    Drawn on a FRESH plane at z = 0 rather than on the shared "xy" one: two
    boards in the same document (a Pi and its HAT, say) have overlapping plan
    outlines, and on one shared sketch the second one's loops subdivide the
    first one's region — "Extrude 'pcb_1' region no longer resolves". A plane
    per slab keeps each board's sketch its own, the way `_block` already
    does for every component block above z = 0."""
    plane = _plane_at(cad, 0.0)
    cad.with_sketch(plane)
    outline = _rect(cad, -hw, -hd, hw, hd)
    if holes:
        hole_circles = [cad.circle2d(cad.point2d(hx, hy), hole_r) for (hx, hy) in holes]
        body_region = cad.region(loop=outline, holes=[[c] for c in hole_circles],
                                 inside=(0.0, 0.0))
    else:
        body_region = cad.region(loop=outline, inside=(0.0, 0.0))
    return cad.extrude(plane, body_region, thickness, quality=quality, export=False)


def _block(cad, cx, cy, z0, w, d, h, quality=None):
    """A box centered at (cx, cy) in XY, spanning z0..z0+h. export=False."""
    plane = _plane_at(cad, z0)
    cad.with_sketch(plane)
    outline = _rect(cad, cx - w / 2.0, cy - d / 2.0, cx + w / 2.0, cy + d / 2.0)
    return cad.extrude(plane, cad.region(loop=outline, inside=(cx, cy)), h,
                       quality=quality, export=False)


# Dimensions per Arduino UNO R3 official mechanical reference drawing
def arduino_uno(cad, quality=None):
    """An Arduino Uno R3-footprint board: PCB outline, the 4 real mounting
    holes, and representative USB-B / barrel-jack / header blocks.

    Board 68.6 x 53.4 x 1.6 mm. Mounting holes dia 3.2 mm at (relative to
    the board's bottom-left corner, per the Arduino UNO R3 official
    mechanical reference drawing): (15.24, 2.54), (15.24, 50.8),
    (66.04, 7.62), (66.04, 35.56). Origin is the board CENTER (holes
    shifted by -34.3, -26.7). Board sits z=0..1.6; USB/jack/headers
    protrude +Z from the top face along the -X (left) short edge.
    Anchors: mount_0..3 (at each hole, z=0), origin (0,0,0).
    """
    W, D, T = 68.6, 53.4, 1.6
    hw, hd = W / 2.0, D / 2.0
    raw_holes = [(15.24, 2.54), (15.24, 50.8), (66.04, 7.62), (66.04, 35.56)]
    holes = [(x - hw, y - hd) for (x, y) in raw_holes]
    hole_r = 3.2 / 2.0

    def build():
        parts = [_slab(cad, hw, hd, T, holes, hole_r, quality=quality)]
        # USB-B block straddling the left short edge.
        parts.append(_block(cad, -hw, 14.0, T, 12.0, 16.0, 11.0, quality=quality))
        # Barrel power-jack block, below the USB block.
        parts.append(_block(cad, -hw, -8.0, T, 9.0, 11.0, 9.0, quality=quality))
        # Two representative header rows along the long edges.
        parts.append(_block(cad, 5.0, hd - 2.0, T, 40.0, 2.5, 8.5, quality=quality))
        parts.append(_block(cad, 5.0, -hd + 2.0, T, 40.0, 2.5, 8.5, quality=quality))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(holes):
            cad.component_export_point(f"mount_{i}", cad.point(hx, hy, 0.0))

    return cad.parametric("arduino_uno", build, quality=quality or "std",
                          label="Arduino Uno")


# Dimensions per Arduino Nano datasheet outline (common 4-corner mounting-hole footprint)
def arduino_nano(cad, quality=None):
    """An Arduino Nano-footprint board: PCB outline, 4 corner mounting
    holes, two 15-pin header rows, and a mini-USB block.

    Board 43.18 x 17.78 x 1.6 mm (Arduino Nano datasheet outline).
    Mounting holes dia 1.8 mm at the 4 corners, inset 1.5 mm (the common
    4-hole Nano carrier footprint). Two 15-pin header rows at 2.54 mm
    pitch (span 14 x 2.54 = 35.56 mm) along the long edges. Origin is the
    board CENTER. Anchors: mount_0..3 (z=0), origin (0,0,0).
    """
    W, D, T = 43.18, 17.78, 1.6
    hw, hd = W / 2.0, D / 2.0
    inset = 1.5
    holes = [(hw - inset, hd - inset), (-(hw - inset), hd - inset),
             (-(hw - inset), -(hd - inset)), (hw - inset, -(hd - inset))]
    hole_r = 1.8 / 2.0
    header_len = 14 * 2.54

    def build():
        parts = [_slab(cad, hw, hd, T, holes, hole_r, quality=quality)]
        # Two 15-pin header rows along the long edges.
        parts.append(_block(cad, 0.0, hd - 1.5, T, header_len, 2.5, 8.5, quality=quality))
        parts.append(_block(cad, 0.0, -(hd - 1.5), T, header_len, 2.5, 8.5, quality=quality))
        # Mini-USB block at one (short) end.
        parts.append(_block(cad, -hw, 0.0, T, 8.0, 6.0, 4.0, quality=quality))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(holes):
            cad.component_export_point(f"mount_{i}", cad.point(hx, hy, 0.0))

    return cad.parametric("arduino_nano", build, quality=quality or "std",
                          label="Arduino Nano")


# Raspberry Pi board classes: overall size + mounting-hole rectangle, per
# the Raspberry Pi Foundation mechanical drawings. The hole rectangle is
# always inset 3.5 mm from two board edges (unchanged since Model B+ for
# the 3B/4B footprint; Zero uses a smaller board and hole rectangle).
_RPI_INSET = 3.5
_RPI_HOLE_R = 2.75 / 2.0
RASPBERRY_PI = {
    "4B":   dict(w=85.0, d=56.0, hole_w=58.0, hole_d=49.0,
                header_cx=-9.0, header_w=46.0, extras=True),
    "3B":   dict(w=85.0, d=56.0, hole_w=58.0, hole_d=49.0,
                header_cx=-9.0, header_w=46.0, extras=False),
    "Zero": dict(w=65.0, d=30.0, hole_w=58.0, hole_d=23.0,
                header_cx=0.0, header_w=30.0, extras=False),
}


# Dimensions per Raspberry Pi Foundation mechanical drawings
def raspberry_pi(cad, model="4B", quality=None):
    """A Raspberry Pi-footprint board: PCB outline, the 4 real mounting
    holes, a representative 40-pin GPIO header, and (4B only) 2 USB blocks
    + an Ethernet block.

    model: "3B" (85 x 56 mm), "4B" (85 x 56 mm), or "Zero" (65 x 30 mm).
    Mounting holes dia 2.75 mm, forming a rectangle inset 3.5 mm from the
    board edges: 58 x 49 mm for 3B/4B, 58 x 23 mm for Zero (Raspberry Pi
    Foundation mechanical drawings). Board thickness 1.4 mm. Origin is the
    board CENTER. Anchors: mount_0..3 (z=0), origin (0,0,0).
    """
    key = str(model)
    d = RASPBERRY_PI[key]
    W, D, T = d["w"], d["d"], 1.4
    hw, hd = W / 2.0, D / 2.0
    x_left = _RPI_INSET - hw
    x_right = _RPI_INSET + d["hole_w"] - hw
    y_bottom = _RPI_INSET - hd
    y_top = _RPI_INSET + d["hole_d"] - hd
    holes = [(x_left, y_bottom), (x_right, y_bottom), (x_left, y_top), (x_right, y_top)]

    def build():
        parts = [_slab(cad, hw, hd, T, holes, _RPI_HOLE_R, quality=quality)]
        # 40-pin GPIO header along the top edge.
        parts.append(_block(cad, d["header_cx"], hd - 3.0, T, d["header_w"], 5.0, 8.5,
                            quality=quality))
        if d["extras"]:
            # Ethernet + two stacked USB-A blocks along the right edge.
            parts.append(_block(cad, hw, -18.0, T, 12.0, 16.0, 13.5, quality=quality))
            parts.append(_block(cad, hw, 0.0, T, 13.0, 17.0, 15.0, quality=quality))
            parts.append(_block(cad, hw, 17.0, T, 13.0, 17.0, 15.0, quality=quality))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(holes):
            cad.component_export_point(f"mount_{i}", cad.point(hx, hy, 0.0))

    return cad.parametric(f"raspberry_pi_{key.lower()}", build, quality=quality or "std",
                          label=f"Raspberry Pi {key}")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def esp32_devkit(cad, quality=None):
    """An ESP32 DevKit-footprint board: PCB outline, two 15-pin header
    rows, a micro-USB block, the ESP32 module can, and 2 optional small
    corner mounting holes.

    Board 52 x 28 x 1.6 mm (common "DevKit V1" 30-pin breakout size). Two
    15-pin header rows at 2.54 mm pitch (span 35.56 mm), rows 0.9 in
    (22.86 mm) apart, along the long edges. Micro-USB block at one end;
    the ESP32 module modeled as a metal can 18 x 25.5 x 3.0 mm near the
    other end. No mounting holes on the real part, but 2 small dia 3.2 mm
    holes are added at 2 corners (left edge) as a practical mounting
    option. Origin is the board CENTER.
    Anchors: origin (0,0,0), mount_0/1 (the 2 corner holes, z=0),
    pin_a0 / pin_b0 (first pin of each header row, z=1.6).
    """
    W, D, T = 52.0, 28.0, 1.6
    hw, hd = W / 2.0, D / 2.0
    row_half_gap = 22.86 / 2.0
    header_len = 14 * 2.54
    holes = [(-(hw - 3.0), hd - 3.0), (-(hw - 3.0), -(hd - 3.0))]
    hole_r = 3.2 / 2.0

    def build():
        parts = [_slab(cad, hw, hd, T, holes, hole_r, quality=quality)]
        # Two 15-pin header rows along the long edges.
        parts.append(_block(cad, 0.0, row_half_gap, T, header_len, 2.5, 8.5, quality=quality))
        parts.append(_block(cad, 0.0, -row_half_gap, T, header_len, 2.5, 8.5, quality=quality))
        # Micro-USB block at the left end.
        parts.append(_block(cad, -hw, 0.0, T, 8.0, 6.0, 4.0, quality=quality))
        # ESP32 module can near the right end.
        parts.append(_block(cad, hw - 11.0, 0.0, T, 18.0, 25.5, 3.0, quality=quality))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, _PCB, finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(holes):
            cad.component_export_point(f"mount_{i}", cad.point(hx, hy, 0.0))
        cad.component_export_point("pin_a0", cad.point(-header_len / 2.0, row_half_gap, T))
        cad.component_export_point("pin_b0", cad.point(-header_len / 2.0, -row_half_gap, T))

    return cad.parametric("esp32_devkit", build, quality=quality or "std",
                          label="ESP32 DevKit")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def pcb_standoff(cad, height=6.0, quality=None):
    """A nylon PCB support/board-mount spacer: a round spacer body (dia
    6.0 mm) of `height` mm with a 3.2 mm through bore, plus a short snap
    peg (dia 2.9 mm, length 4 mm) on top for a board hole. Representative
    dimensions (generic nylon board-spacer catalog class, e.g. Essentra/
    Keystone board supports) — not tied to one exact part number.

    The peg's base flares out to meet the main bore's inner wall exactly
    (a common real injection-molded detail) so the peg is solidly joined
    to the body rather than floating over the open bore.
    Orientation: base at z=0, peg points +Z.
    Anchors: base (0,0,0), top (0,0,height).
    """
    height = float(height)
    r, bore_r, peg_r, peg_len, flare = 3.0, 1.6, 1.45, 4.0, 0.3

    def build():
        cad.with_sketch("zx")
        # Annular body: through bore (bore_r) to the outer wall (r), 0..height.
        bp = [cad.point2d(bore_r, 0.0), cad.point2d(r, 0.0),
              cad.point2d(r, height), cad.point2d(bore_r, height)]
        bl = [cad.line2d(bp[i], bp[(i + 1) % 4]) for i in range(4)]
        b_axis = cad.line2d(cad.point2d(0.0, 0.0), cad.point2d(0.0, height), construction=True)
        body = cad.revolve("zx", cad.region(loop=bl, inside=((bore_r + r) / 2.0, height / 2.0)),
                           axis_line=b_axis, angle=360.0, quality=quality, export=False)

        # Snap peg: base flares to bore_r (meeting the body's bore wall
        # exactly at z=height) then necks down to the true peg radius.
        cad.with_sketch("zx")
        pp = [cad.point2d(0.0, height), cad.point2d(bore_r, height),
              cad.point2d(peg_r, height + flare), cad.point2d(peg_r, height + peg_len),
              cad.point2d(0.0, height + peg_len)]
        pl = [cad.line2d(pp[i], pp[(i + 1) % 5]) for i in range(4)]
        p_axis = cad.line2d(pp[4], pp[0])
        peg = cad.revolve("zx",
                          cad.region(loop=pl + [p_axis],
                                     inside=(peg_r / 2.0, height + peg_len - 1.0)),
                          axis_line=p_axis, angle=360.0, quality=quality, export=False)

        spacer = cad.bool_union(body, peg, quality=quality)
        cad.set_color(spacer, _STANDOFF, finish="matte")
        cad.component_export(spacer)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, height))

    return cad.parametric("pcb_standoff", build, height=height, quality=quality or "std",
                          label=f"PCB standoff {height:g}mm")
