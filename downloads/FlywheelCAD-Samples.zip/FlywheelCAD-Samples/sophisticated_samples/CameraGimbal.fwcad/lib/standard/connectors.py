# flywheelcad standard library
"""Common wire/board connector envelopes for PCB and panel work.

Five catalog-class parts, dimensions chosen to match the connector families
named in each docstring (exact numbers per part below):

    usb              Receptacle shell, simplified as an outer metal shell
                      block minus a mouth cavity cut from the front face,
                      plus a plastic tongue blade:
                        "A"     shell 12.0(X) x 4.5(Z) x 13.5(Y-deep),
                                rectangular mouth (representative 10.4 x 2.9,
                                ~0.8mm shell wall)
                        "C"     shell 9.0 x 3.5 x 7.0, rounded-oval
                                (stadium) mouth 8.94 x 3.26
                        "micro" shell 8.0 x 3.0 x 5.0, trapezoidal mouth
                                ~7.5 x 2.5 (tapered 60% at the top)
    jst              JST-XH style 2.5mm-pitch wire-to-board header: white
                      nylon housing (2.5*pins + 1.5) long x 6.0 wide x 5.75
                      tall, open top, `pins` gold posts (0.6mm square)
                      rising 6.0 above the housing top / 3.5 below the base.
    dupont           Dupont/"berg" 2.54mm female housing: black nylon shell
                      (2.54*pins) x (2.54*rows) x 14.0 tall, with a grid of
                      blind square pin sockets (representative 0.7mm square,
                      10.0mm deep).
    terminal_block   5.08mm-pitch screw terminal block: green body
                      (5.08*ways) long x 8.0 wide x 10.0 tall, `ways` wire
                      -entry bores (dia 3.0) opening on the +Y face, `ways`
                      screw heads (small cylinders) on top.
    barrel_jack_panel  Panel-mount DC barrel jack: hex nut-engagement face
                      (representative across-flats 10.0) topped by a
                      threaded cylindrical barrel (OD 8.0, length 12.0),
                      full through bore (dia 5.5), 3 solder tabs at the
                      back. Orientation simplified to a +Z on-axis stack
                      (see docstring) rather than the true panel +Y axis.

Orientation:
    usb                PCB face (shell bottom) at z = 0, opening faces +Y
    jst                base at z = 0, pins up (+Z) through the housing
    dupont             base at z = 0, sockets open up (+Z)
    terminal_block     base at z = 0, back face at y = 0, bores face +Y
    barrel_jack_panel  hex base at z = 0, barrel up (+Z) -- see docstring

Anchor contract:
    usb                origin (0,0,0)
    jst                pin_0 (first pin center, on top of the housing)
    dupont             origin (0,0,0), pin_0 (first socket center, on top)
    terminal_block     origin (0,0,0), way_0 (first screw, on top)
    barrel_jack_panel  origin (0,0,0)
"""

__library_version__ = "1.0"

import math

_USB = {
    "A":     dict(shell=(12.0, 4.5, 13.5), mouth=(10.4, 2.9), shape="rect"),
    "C":     dict(shell=(9.0, 3.5, 7.0),   mouth=(8.94, 3.26), shape="stadium"),
    "micro": dict(shell=(8.0, 3.0, 5.0),   mouth=(7.5, 2.5),  shape="trapezoid"),
}
_USB_WALL_BACK = 1.2      # back-wall thickness left behind the mouth cavity
_USB_OVERSHOOT = 0.5      # cutter pokes past the front face for a clean boolean
_USB_TONGUE_T = 0.6       # plastic tongue thickness (Z)
_USB_TONGUE_MARGIN = 0.5  # tongue set back from the cavity's back wall / opening

_JST_PITCH = 2.5
_JST_HOUSING_Y = 6.0
_JST_HOUSING_Z = 5.75
_JST_WALL = 0.8
_JST_FLOOR = 1.0
_JST_PIN_S = 0.6
_JST_PIN_ABOVE = 6.0
_JST_PIN_BELOW = 3.5
_JST_OVERSHOOT = 0.5

_DUPONT_PITCH = 2.54
_DUPONT_HEIGHT = 14.0
_DUPONT_SOCKET_S = 0.7
_DUPONT_SOCKET_DEPTH = 10.0
_DUPONT_OVERSHOOT = 0.5

_TERM_PITCH = 5.08
_TERM_Y = 8.0
_TERM_Z = 10.0
_TERM_BORE_R = 1.5
_TERM_WALL_BACK = 2.0
_TERM_OVERSHOOT = 0.5
_TERM_SCREW_R = 1.8
_TERM_SCREW_H = 1.5

_JACK_HEX_AF = 10.0
_JACK_HEX_H = 4.0
_JACK_BARREL_R = 4.0     # OD 8.0
_JACK_BARREL_LEN = 12.0
_JACK_BORE_R = 2.75      # dia 5.5
_JACK_OVERSHOOT = 0.5
_JACK_TAB_W = 1.5
_JACK_TAB_LEN = 3.0
_JACK_TAB_RADIUS = 4.0

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float -- a variable or list(...) call yields NO dropdown.
# So every choice list is spelled out literally here. Continuous numeric
# params (pin/way counts) stay free-text.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "usb": {"kind": ["A", "C", "micro"]},
    "dupont": {"rows": [1, 2]},
}


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list)."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _trapezoid(cad, cu, cv, bottom_w, top_w, height):
    """Isoceles trapezoid outline centered at (cu, cv): full width bottom_w
    at v = cv - height/2, full width top_w at v = cv + height/2."""
    bl = cad.point2d(cu - bottom_w / 2.0, cv - height / 2.0)
    br = cad.point2d(cu + bottom_w / 2.0, cv - height / 2.0)
    tr = cad.point2d(cu + top_w / 2.0, cv + height / 2.0)
    tl = cad.point2d(cu - top_w / 2.0, cv + height / 2.0)
    return [cad.line2d(bl, br), cad.line2d(br, tr),
            cad.line2d(tr, tl), cad.line2d(tl, bl)]


def _stadium(cad, cu, cv, length, height):
    """Pill/stadium outline (2 lines + 2 semicircular arcs) centered at
    (cu, cv): total extent `length` along u, cap diameter (and full v
    extent) `height`. Flat sides run parallel to u; rounded caps close
    each end, bulging outward (away from the shape's own interior)."""
    r = height / 2.0
    half_flat = max(0.0, length / 2.0 - r)
    right, left = cu + half_flat, cu - half_flat
    top, bottom = cv + r, cv - r
    p_tr = cad.point2d(right, top)
    p_tl = cad.point2d(left, top)
    p_bl = cad.point2d(left, bottom)
    p_br = cad.point2d(right, bottom)
    top_line = cad.line2d(p_tl, p_tr)
    right_arc = cad.arc2d(cad.point2d(right, cv), p_tr, p_br, clockwise=True)
    bottom_line = cad.line2d(p_br, p_bl)
    left_arc = cad.arc2d(cad.point2d(left, cv), p_bl, p_tl, clockwise=True)
    return [top_line, right_arc, bottom_line, left_arc]


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y).

    Used to give a shape group its OWN sketch page even when it sits at the
    same height as other geometry -- see fan()/header() in electronics.py
    for the original rationale (elements sharing one sketch page that CROSS
    each other get split by area detection, breaking a region() call that
    names an untouched loop)."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _hexagon(cad, af, cx=0.0, cy=0.0):
    """Hex outline (list of lines) from across-flats width, flats top/bottom."""
    r = (af / 2.0) / math.cos(math.radians(30.0))
    pts = [cad.point2d(cx + r * math.cos(math.radians(60 * k + 30)),
                       cy + r * math.sin(math.radians(60 * k + 30))) for k in range(6)]
    return [cad.line2d(pts[i], pts[(i + 1) % 6]) for i in range(6)]


def _rot(deg, r):
    a = math.radians(deg)
    return (r * math.cos(a), r * math.sin(a))


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def usb(cad, kind="A", quality=None):
    """A USB receptacle shell: an outer metal shell block minus a mouth
    cavity cut from the front face, plus a plastic tongue blade.
    kind: "A", "C", or "micro" (see module docstring for exact dims).

    Orientation: PCB face at z=0 (shell bottom), opening faces +Y (front
    face at y=shell_y). Anchor: origin (0,0,0). Shell "#B0BEC5" metallic,
    tongue "#212121" matte (two exports)."""
    key = str(kind)
    d = _USB[key]
    shell_x, shell_z, shell_y = d["shell"]
    mouth_x, mouth_z = d["mouth"]
    shape = d["shape"]

    def build():
        half_x = shell_x / 2.0
        z_center = shell_z / 2.0

        cad.with_sketch("xy")
        shell_outline = _rect(cad, -half_x, 0.0, half_x, shell_y)
        shell_box = cad.extrude("xy", cad.region(loop=shell_outline, inside=(0.0, shell_y / 2.0)),
                                shell_z, quality=quality, export=False)

        cad.with_sketch("zx")
        if shape == "stadium":
            cavity_loop = _stadium(cad, 0.0, z_center, mouth_x, mouth_z)
        elif shape == "trapezoid":
            cavity_loop = _trapezoid(cad, 0.0, z_center, mouth_x, mouth_x * 0.6, mouth_z)
        else:
            cavity_loop = _rect(cad, -mouth_x / 2.0, z_center - mouth_z / 2.0,
                                mouth_x / 2.0, z_center + mouth_z / 2.0)
        cavity_depth = shell_y + _USB_OVERSHOOT - _USB_WALL_BACK
        cavity = cad.extrude("zx", cad.region(loop=cavity_loop, inside=(0.0, z_center)),
                             cavity_depth, offset=_USB_WALL_BACK, quality=quality, export=False)

        shell = cad.bool_difference(shell_box, cavity, quality=quality)
        cad.set_color(shell, "#B0BEC5", finish="metallic")
        cad.component_export(shell)

        tongue_x = mouth_x * 0.75
        tongue_y0 = _USB_WALL_BACK + _USB_TONGUE_MARGIN
        tongue_y1 = shell_y - _USB_TONGUE_MARGIN
        tongue_zbot = z_center - _USB_TONGUE_T / 2.0
        tongue_plane = _plane_at(cad, tongue_zbot)
        cad.with_sketch(tongue_plane)
        tongue_outline = _rect(cad, -tongue_x / 2.0, tongue_y0, tongue_x / 2.0, tongue_y1)
        tongue = cad.extrude(tongue_plane,
                             cad.region(loop=tongue_outline, inside=(0.0, (tongue_y0 + tongue_y1) / 2.0)),
                             _USB_TONGUE_T, quality=quality)
        cad.set_color(tongue, "#212121", finish="matte")
        cad.component_export(tongue)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric(f"usb_{key}", build, quality=quality or "std",
                          label=f"USB {key} receptacle")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def jst(cad, pins=2, quality=None):
    """A JST-XH style 2.5mm-pitch wire-to-board header. White nylon housing
    (2.5*pins + 1.5) long x 6.0 wide x 5.75 tall, open top (cavity floor
    1.0mm above the base), with `pins` gold posts (0.6mm square) rising 6.0
    above the housing top and dropping 3.5 below the base.

    Orientation: base at z=0. Anchor: pin_0 (first pin center, on top of
    the housing). Housing "#ECEFF1", pins "#FFC107" (two exports)."""
    n = int(pins)
    housing_x = _JST_PITCH * n + 1.5
    hx, hy = housing_x / 2.0, _JST_HOUSING_Y / 2.0

    def build():
        cad.with_sketch("xy")
        outer = _rect(cad, -hx, -hy, hx, hy)
        outer_box = cad.extrude("xy", cad.region(loop=outer, inside=(0.0, 0.0)),
                                _JST_HOUSING_Z, quality=quality, export=False)

        cad.with_sketch("xy")
        cavity_x, cavity_y = hx - _JST_WALL, hy - _JST_WALL
        cavity_outline = _rect(cad, -cavity_x, -cavity_y, cavity_x, cavity_y)
        cavity = cad.extrude("xy", cad.region(loop=cavity_outline, inside=(0.0, 0.0)),
                             _JST_HOUSING_Z - _JST_FLOOR + _JST_OVERSHOOT, offset=_JST_FLOOR,
                             quality=quality, export=False)

        housing = cad.bool_difference(outer_box, cavity, quality=quality)
        cad.set_color(housing, "#ECEFF1", finish="matte")
        cad.component_export(housing)

        pin_len = _JST_HOUSING_Z + _JST_PIN_ABOVE + _JST_PIN_BELOW
        pins_list = []
        pin0 = None
        for c in range(n):
            x = (c - (n - 1) / 2.0) * _JST_PITCH
            cad.with_sketch("xy")
            outline = _rect(cad, x - _JST_PIN_S / 2.0, -_JST_PIN_S / 2.0,
                            x + _JST_PIN_S / 2.0, _JST_PIN_S / 2.0)
            post = cad.extrude("xy", cad.region(loop=outline, inside=(x, 0.0)),
                               pin_len, offset=-_JST_PIN_BELOW, quality=quality, export=False)
            pins_list.append(post)
            if pin0 is None:
                pin0 = x

        if len(pins_list) > 1:
            pins_body = cad.bool_union(*pins_list, quality=quality)
        else:
            pins_body = pins_list[0]
            pins_body.set_export(True)
        cad.set_color(pins_body, "#FFC107", finish="metallic")
        cad.component_export(pins_body)

        cad.component_export_point("pin_0", cad.point(pin0, 0.0, _JST_HOUSING_Z + _JST_PIN_ABOVE))

    return cad.parametric(f"jst_{n}", build, quality=quality or "std",
                          label=f"JST-XH {n}-pin header")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def dupont(cad, pins=1, rows=1, quality=None):
    """A Dupont/"berg" 2.54mm female housing: black nylon shell
    (2.54*pins) x (2.54*rows) x 14.0 tall, with a grid of blind square pin
    sockets (representative 0.7mm square, 10.0mm deep) cut from the top.

    Orientation: base at z=0, sockets open up (+Z). Anchors: origin
    (0,0,0), pin_0 (first socket center, on top). Color "#212121" matte."""
    n_pins, n_rows = int(pins), int(rows)
    half_x = _DUPONT_PITCH * n_pins / 2.0
    half_y = _DUPONT_PITCH * n_rows / 2.0

    def build():
        cad.with_sketch("xy")
        outline = _rect(cad, -half_x, -half_y, half_x, half_y)
        shell_box = cad.extrude("xy", cad.region(loop=outline, inside=(0.0, 0.0)),
                                _DUPONT_HEIGHT, quality=quality, export=False)

        sockets = []
        pin0 = None
        s = _DUPONT_SOCKET_S / 2.0
        for r in range(n_rows):
            y = (r - (n_rows - 1) / 2.0) * _DUPONT_PITCH
            for c in range(n_pins):
                x = (c - (n_pins - 1) / 2.0) * _DUPONT_PITCH
                cad.with_sketch("xy")
                sock_outline = _rect(cad, x - s, y - s, x + s, y + s)
                socket = cad.extrude("xy", cad.region(loop=sock_outline, inside=(x, y)),
                                     _DUPONT_SOCKET_DEPTH + _DUPONT_OVERSHOOT,
                                     offset=(_DUPONT_HEIGHT - _DUPONT_SOCKET_DEPTH),
                                     quality=quality, export=False)
                sockets.append(socket)
                if pin0 is None:
                    pin0 = (x, y)

        sockets_body = cad.bool_union(*sockets, quality=quality, export=False) if len(sockets) > 1 else sockets[0]
        shell = cad.bool_difference(shell_box, sockets_body, quality=quality)
        cad.set_color(shell, "#212121", finish="matte")
        cad.component_export(shell)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("pin_0", cad.point(pin0[0], pin0[1], _DUPONT_HEIGHT))

    return cad.parametric(f"dupont_{n_pins}x{n_rows}", build,
                          pins=n_pins, rows=n_rows, quality=quality or "std",
                          label=f"Dupont {n_pins}x{n_rows} housing")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def terminal_block(cad, ways=2, quality=None):
    """A screw terminal block, 5.08mm pitch: green body (5.08*ways) long x
    8.0 wide x 10.0 tall, with `ways` wire-entry bores (dia 3.0) opening on
    the +Y face and `ways` screw heads (small cylinders) on top.

    Orientation: base at z=0, back face at y=0, bores face +Y. Anchors:
    origin (0,0,0), way_0 (first screw, on top). Body "#2E7D32" matte,
    screws "#B0BEC5" (two exports)."""
    n = int(ways)
    half_x = _TERM_PITCH * n / 2.0

    def build():
        z_center = _TERM_Z / 2.0

        cad.with_sketch("xy")
        outline = _rect(cad, -half_x, 0.0, half_x, _TERM_Y)
        body_box = cad.extrude("xy", cad.region(loop=outline, inside=(0.0, _TERM_Y / 2.0)),
                               _TERM_Z, quality=quality, export=False)

        bore_depth = _TERM_Y + _TERM_OVERSHOOT - _TERM_WALL_BACK
        bores = []
        way0 = None
        for w in range(n):
            x = (w - (n - 1) / 2.0) * _TERM_PITCH
            cad.with_sketch("zx")
            bore_c = cad.circle2d(cad.point2d(x, z_center), _TERM_BORE_R)
            bores.append(cad.extrude("zx", cad.region(loop=[bore_c], inside=(x, z_center)),
                                     bore_depth, offset=_TERM_WALL_BACK, quality=quality,
                                     export=False))
            if way0 is None:
                way0 = x

        bores_cutter = cad.bool_union(*bores, quality=quality, export=False) if len(bores) > 1 else bores[0]
        body = cad.bool_difference(body_box, bores_cutter, quality=quality)
        cad.set_color(body, "#2E7D32", finish="matte")
        cad.component_export(body)

        screws = []
        for w in range(n):
            x = (w - (n - 1) / 2.0) * _TERM_PITCH
            cad.with_sketch("xy")
            screw_c = cad.circle2d(cad.point2d(x, _TERM_Y / 2.0), _TERM_SCREW_R)
            screws.append(cad.extrude("xy", cad.region(loop=[screw_c], inside=(x, _TERM_Y / 2.0)),
                                      _TERM_SCREW_H, offset=_TERM_Z, quality=quality, export=False))
        screws_body = cad.bool_union(*screws, quality=quality) if len(screws) > 1 else screws[0]
        if len(screws) == 1:
            screws_body.set_export(True)
        cad.set_color(screws_body, "#B0BEC5", finish="metallic")
        cad.component_export(screws_body)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("way_0", cad.point(way0, _TERM_Y / 2.0, _TERM_Z))

    return cad.parametric(f"terminal_{n}", build, quality=quality or "std",
                          label=f"{n}-way terminal block")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def barrel_jack_panel(cad, quality=None):
    """A panel-mount DC barrel jack, simplified as an on-axis (+Z) stack: a
    hex nut-engagement face (representative across-flats 10.0, height 4.0)
    at the base, topped by a threaded cylindrical barrel (OD 8.0, length
    12.0), a full through bore (dia 5.5), and 3 solder tabs at the back
    (bottom, -Z). The true part mounts through a panel with its axis along
    +Y; this model keeps the simpler on-axis +Z revolve/extrude stack
    instead (equivalent envelope, easier to author/verify) -- hex base at
    z=0. Anchor: origin (0,0,0). Color "#37474F" matte."""

    def build():
        cad.with_sketch("xy")
        hex_outline = _hexagon(cad, _JACK_HEX_AF)
        hex_base = cad.extrude("xy", cad.region(loop=hex_outline, inside=(0.0, 0.0)),
                               _JACK_HEX_H, quality=quality, export=False)

        barrel_plane = _plane_at(cad, _JACK_HEX_H)
        cad.with_sketch(barrel_plane)
        barrel_c = cad.circle2d(cad.point2d(0.0, 0.0), _JACK_BARREL_R)
        barrel_cyl = cad.extrude(barrel_plane, cad.region(loop=[barrel_c], inside=(0.0, 0.0)),
                                 _JACK_BARREL_LEN, quality=quality, export=False)

        blank = cad.bool_union(hex_base, barrel_cyl, quality=quality, export=False)

        bore_plane = _plane_at(cad, -_JACK_OVERSHOOT)
        cad.with_sketch(bore_plane)
        bore_c = cad.circle2d(cad.point2d(0.0, 0.0), _JACK_BORE_R)
        bore_len = _JACK_HEX_H + _JACK_BARREL_LEN + 2 * _JACK_OVERSHOOT
        bore = cad.extrude(bore_plane, cad.region(loop=[bore_c], inside=(0.0, 0.0)),
                           bore_len, quality=quality, export=False)

        jack = cad.bool_difference(blank, bore, quality=quality, export=False)

        tabs = []
        for deg in (90.0, 210.0, 330.0):
            tx, ty = _rot(deg, _JACK_TAB_RADIUS)
            tab_plane = _plane_at(cad, 0.0)
            cad.with_sketch(tab_plane)
            outline = _rect(cad, tx - _JACK_TAB_W / 2.0, ty - _JACK_TAB_W / 2.0,
                            tx + _JACK_TAB_W / 2.0, ty + _JACK_TAB_W / 2.0)
            tabs.append(cad.extrude(tab_plane, cad.region(loop=outline, inside=(tx, ty)),
                                    _JACK_TAB_LEN, offset=-_JACK_TAB_LEN, quality=quality,
                                    export=False))

        body = cad.bool_union(jack, *tabs, quality=quality)
        cad.set_color(body, "#37474F", finish="matte")
        cad.component_export(body)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("barrel_jack_panel", build, quality=quality or "std",
                          label="Panel-mount DC barrel jack")
