# flywheelcad standard library
"""More common through-hole / PCB-mount electronics hardware.

Five catalog-class parts, mostly extruded boxes/discs plus a PCB slab
(dimensions chosen from typical component datasheets / catalog classes):

    buzzer       Through-hole piezo buzzer can: dia 12 x height 9 (common
                 12mm through-hole piezo buzzer catalog class). A dia 2
                 sound-hole dimple centered on the top face (depth 1.5,
                 representative visual detail -- not an acoustic-accurate
                 port) and 2 pins dia 0.5 x length 4.0, spaced 6.0 mm apart
                 (representative catalog pin footprint; not tied to one
                 exact part). kind="active"/"passive" share the same
                 envelope -- the electrical difference (built-in
                 oscillator vs. driven tone) isn't visible mechanically.
    heat_sink    "TO220": base 20 x 13 x 3 mm with 5 straight fins (each
                 1.2 mm thick x 12 mm tall x the full 20 mm base length),
                 evenly spaced across the 13 mm width -- a representative
                 small clip-on TO-220 heat sink (a typical catalog class,
                 not one exact part).
                 "RPi": base 15 x 15 x 3 mm with a 3x3 grid of square pin
                 fins (each 2 x 2 x 8 mm), evenly spaced -- a
                 representative small adhesive pin-fin heat sink sized
                 for Raspberry-Pi-class SoC packages.
    fuse_holder  A panel/PCB fuse-clip holder for a standard 5x20 mm glass
                 tube fuse: base 26 x 8 x 2 mm; two clip walls (each 6 x 3
                 x 8 mm) standing on the base, centered 20 mm apart
                 (matching the fuse's overall length so the clips grip its
                 end caps); the dia 5 x 20 mm fuse lies along +X, nested
                 between the clips just above the base (representative
                 5x20 fuse-clip catalog geometry, not one exact part
                 number).
    led_matrix   An LED matrix / display module. "8x8": a bare 32 x 32 x
                 1.6 mm PCB (the common single-module MAX7219-class board
                 size) with an 8x8 grid of surface LED bumps. "MAX7219":
                 the same PCB plus a 32 x 32 x 7 mm display block on top
                 (representing the LED-matrix + driver-IC module
                 assembly), with the same 8x8 LED grid on top of the
                 display block. LED bumps: 2.5 x 2.5 x 1.0 mm, 3.0 mm
                 pitch (representative -- chosen so the grid clears the
                 header row, not tied to one exact part). A representative
                 single-row 5-pin header (2.54 mm pitch) sits along one
                 edge.
    rpi_hat      A Raspberry Pi HAT/shield footprint board: PCB 65 x 56 x
                 1.6 mm (the official Raspberry Pi HAT mechanical
                 specification board outline). 4 mounting holes, dia 2.75
                 mm, forming a 58 x 49 mm rectangle inset 3.5 mm from the
                 board edges on every side (matches the Raspberry Pi
                 Foundation's own board mechanical drawings -- see also
                 board_footprints.raspberry_pi -- so a HAT bolts straight
                 to the Pi below). A representative 2x20 (40-pin) GPIO
                 header footprint (2.54 mm pitch, 48.26 x 5.0 mm envelope)
                 sits along one long (65 mm) edge.

Orientation:
    buzzer       axis +Z, base (can bottom) at z=0, pins point -Z
    heat_sink    base sits z=0..thickness, fins/pins stand +Z
    fuse_holder  base at z=0, clips stand +Z, fuse lies along +X
    led_matrix   PCB bottom face at z=0, features stack +Z
    rpi_hat      PCB bottom face at z=0, header protrudes +Z

Per the single-exported-body convention used elsewhere in this library,
heat_sink / led_matrix / rpi_hat are each ONE merged, uniformly colored
body (headers etc. are not separately colored -- same convention as
board_footprints.py). buzzer is one body too. fuse_holder needs two
colors (metal clips vs. glass fuse), so it uses two `cad.component_export()` calls
per the TWO-EXPORT convention (see electronics.tact_button).

Anchor contract:
    buzzer       origin (0,0,0)
    heat_sink    origin (0,0,0)
    fuse_holder  origin (0,0,0)
    led_matrix   origin (0,0,0)
    rpi_hat      origin (0,0,0), mount_0..3 (each mounting hole, z=0)
"""

__library_version__ = "1.0"

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float -- a variable or list(...) call yields NO
# dropdown. So every choice list is spelled out literally here.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "buzzer": {"kind": ["active", "passive"]},
    "heat_sink": {"style": ["TO220", "RPi"]},
    "led_matrix": {"size": ["8x8", "MAX7219"]},
}


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list)."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y).

    Used for a feature whose outline would otherwise share a PARTIAL edge
    with another loop already on "xy" (e.g. a fin that spans the full
    base length, so its side edges lie exactly along a portion of the
    base's own side edges) -- such a T-junction breaks area detection on
    a shared page (a stricter case than the harmless fully-nested,
    non-touching loops used elsewhere in this module), so the feature
    gets its own fresh page instead, same fix as electronics.fan's
    hub/struts."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def buzzer(cad, kind="active", quality=None):
    """A through-hole piezo buzzer can (see module docstring for dims).

    kind: "active" or "passive" -- same mechanical envelope for both.
    Axis +Z, can bottom at z=0, pins point -Z. Anchor: origin (0,0,0)."""
    key = str(kind)
    can_r, can_h = 6.0, 9.0
    hole_r, hole_depth = 1.0, 1.5
    pin_r, pin_len, half_sp = 0.25, 4.0, 3.0

    def build():
        cad.with_sketch("xy")
        can_c = cad.circle2d(cad.point2d(0.0, 0.0), can_r)
        can = cad.extrude("xy", cad.region(loop=[can_c], inside=(0.0, 0.0)),
                          can_h, quality=quality, export=False)

        cad.with_sketch("xy")
        hole_c = cad.circle2d(cad.point2d(0.0, 0.0), hole_r)
        hole = cad.extrude("xy", cad.region(loop=[hole_c], inside=(0.0, 0.0)),
                           hole_depth, offset=can_h - hole_depth, quality=quality,
                           export=False)
        body = cad.bool_difference(can, hole, quality=quality, export=False)

        pins = []
        for px in (-half_sp, half_sp):
            cad.with_sketch("xy")
            pin_c = cad.circle2d(cad.point2d(px, 0.0), pin_r)
            pins.append(cad.extrude("xy", cad.region(loop=[pin_c], inside=(px, 0.0)),
                                    pin_len, offset=-pin_len, quality=quality,
                                    export=False))

        buzz = cad.bool_union(body, *pins, quality=quality)
        cad.set_color(buzz, "#212121", finish="matte")
        cad.component_export(buzz)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric(f"buzzer_{key}", build, quality=quality or "std",
                          label=f"{key.capitalize()} buzzer")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def heat_sink(cad, style="TO220", quality=None):
    """An extruded aluminium heat sink (see module docstring for dims).

    style: "TO220" (base + 5-fin comb) or "RPi" (base + 3x3 pin-fin grid).
    Base sits z=0..thickness, fins/pins stand +Z. Anchor: origin (0,0,0)."""
    key = str(style)

    def build():
        if key == "RPi":
            bx, by, bz = 15.0, 15.0, 3.0
            pin_s, pin_h, grid = 2.0, 8.0, 3
            hbx, hby = bx / 2.0, by / 2.0

            cad.with_sketch("xy")
            base_outline = _rect(cad, -hbx, -hby, hbx, hby)
            base = cad.extrude("xy", cad.region(loop=base_outline, inside=(0.0, 0.0)),
                               bz, quality=quality, export=False)

            # 3x3 grid of disjoint pin fins -- each its OWN region/extrude
            # call, all on the shared "xy" page (nested inside the base
            # footprint, but drawn -- and so resolved -- AFTER the base's
            # own extrude already ran, so the base stays fully solid; see
            # electronics.tact_button for the same technique on its legs).
            pitch = bx / grid
            pins = []
            for i in range(grid):
                px = (i - (grid - 1) / 2.0) * pitch
                for j in range(grid):
                    py = (j - (grid - 1) / 2.0) * pitch
                    cad.with_sketch("xy")
                    outline = _rect(cad, px - pin_s / 2.0, py - pin_s / 2.0,
                                    px + pin_s / 2.0, py + pin_s / 2.0)
                    pins.append(cad.extrude("xy", cad.region(loop=outline, inside=(px, py)),
                                            pin_h, offset=bz, quality=quality,
                                            export=False))

            body = cad.bool_union(base, *pins, quality=quality)
        else:
            bx, by, bz = 20.0, 13.0, 3.0
            fin_t, fin_h, n = 1.2, 12.0, 5
            hbx, hby = bx / 2.0, by / 2.0

            cad.with_sketch("xy")
            base_outline = _rect(cad, -hbx, -hby, hbx, hby)
            base = cad.extrude("xy", cad.region(loop=base_outline, inside=(0.0, 0.0)),
                               bz, quality=quality, export=False)

            # 5 disjoint fins (a "fin comb"), each the full 20 mm base
            # length -- so each fin's side edges run exactly along a
            # PARTIAL stretch of the base outline's own side edges. That
            # T-junction (unlike the RPi pins above, which sit fully
            # clear of the base edges) breaks area detection on a shared
            # page, so the whole comb gets its own fresh plane instead
            # (electronics.fan's hub/struts fix).
            fin_plane = _plane_at(cad, bz)
            pitch = by / n
            fins = []
            for i in range(n):
                fy = (i - (n - 1) / 2.0) * pitch
                cad.with_sketch(fin_plane)
                outline = _rect(cad, -hbx, fy - fin_t / 2.0, hbx, fy + fin_t / 2.0)
                fins.append(cad.extrude(fin_plane, cad.region(loop=outline, inside=(0.0, fy)),
                                        fin_h, quality=quality, export=False))

            body = cad.bool_union(base, *fins, quality=quality)

        cad.set_color(body, "#CFD8DC", finish="metallic")
        cad.component_export(body)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric(f"heatsink_{key.lower()}", build, quality=quality or "std",
                          label=f"{key} heat sink")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def fuse_holder(cad, quality=None):
    """A panel/PCB fuse-clip holder for a 5x20 mm fuse (see module
    docstring for dims). Base at z=0. Two exports: metal clips (+ base)
    and the glass fuse. Anchor: origin (0,0,0)."""
    base_x, base_y, base_z = 26.0, 8.0, 2.0
    clip_x, clip_y, clip_z = 6.0, 3.0, 8.0
    clip_spacing = 20.0
    fuse_r, fuse_len = 2.5, 20.0

    def build():
        hbx, hby = base_x / 2.0, base_y / 2.0
        cad.with_sketch("xy")
        base_outline = _rect(cad, -hbx, -hby, hbx, hby)
        base = cad.extrude("xy", cad.region(loop=base_outline, inside=(0.0, 0.0)),
                           base_z, quality=quality, export=False)

        # Clip outer edges sit exactly flush with the base's ends (by
        # design -- see the module docstring), so each clip's outer edge
        # is a PARTIAL run along the base outline's own edge. That
        # T-junction breaks area detection on a shared page, so the
        # clips get their own fresh plane (electronics.fan's hub/struts
        # fix; see also heat_sink's TO220 fin comb above).
        clip_plane = _plane_at(cad, base_z)
        clip_cx = clip_spacing / 2.0
        clips = []
        for cx in (-clip_cx, clip_cx):
            cad.with_sketch(clip_plane)
            outline = _rect(cad, cx - clip_x / 2.0, -clip_y / 2.0,
                            cx + clip_x / 2.0, clip_y / 2.0)
            clips.append(cad.extrude(clip_plane, cad.region(loop=outline, inside=(cx, 0.0)),
                                     clip_z, quality=quality, export=False))

        holder = cad.bool_union(base, *clips, quality=quality)
        cad.set_color(holder, "#455A64", finish="metallic")
        cad.component_export(holder)

        # Fuse: axis +X (the "yz" plane's normal), centered on the origin,
        # resting just above the base between the two clip walls.
        cad.with_sketch("yz")
        fuse_z = base_z + fuse_r
        fuse_c = cad.circle2d(cad.point2d(0.0, fuse_z), fuse_r)
        fuse = cad.extrude("yz", cad.region(loop=[fuse_c], inside=(0.0, fuse_z)),
                           fuse_len, offset=-fuse_len / 2.0, quality=quality)
        cad.set_color(fuse, "#EEEEEE", finish="glass")
        cad.component_export(fuse)

        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("fuse_holder", build, quality=quality or "std",
                          label="Fuse holder (5x20mm)")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def led_matrix(cad, size="8x8", quality=None):
    """An LED matrix / display module (see module docstring for dims).

    size: "8x8" (bare PCB + LED grid) or "MAX7219" (PCB + display block +
    LED grid). PCB bottom face at z=0. One merged PCB-green body.
    Anchor: origin (0,0,0)."""
    key = str(size)
    pcb_w, pcb_d, pcb_t = 32.0, 32.0, 1.6
    display_h = 7.0 if key == "MAX7219" else 0.0
    bump_s, bump_h, grid, pitch = 2.5, 1.0, 8, 3.0
    hdr_pins, hdr_pitch, hdr_d, hdr_h = 5, 2.54, 2.5, 8.5

    def build():
        half_w, half_d = pcb_w / 2.0, pcb_d / 2.0
        cad.with_sketch("xy")
        pcb_outline = _rect(cad, -half_w, -half_d, half_w, half_d)
        pcb = cad.extrude("xy", cad.region(loop=pcb_outline, inside=(0.0, 0.0)),
                          pcb_t, quality=quality, export=False)
        parts = [pcb]
        top_z = pcb_t

        if display_h > 0.0:
            cad.with_sketch("xy")
            disp_outline = _rect(cad, -half_w, -half_d, half_w, half_d)
            display = cad.extrude("xy", cad.region(loop=disp_outline, inside=(0.0, 0.0)),
                                  display_h, offset=pcb_t, quality=quality, export=False)
            parts.append(display)
            top_z = pcb_t + display_h

        # 8x8 grid of disjoint LED bumps -- each its OWN region/extrude
        # call on the shared "xy" page (nested inside the PCB/display
        # footprint, resolved AFTER those already extruded; see
        # heat_sink's fin comb / pin grid for the same technique).
        for i in range(grid):
            bx = (i - (grid - 1) / 2.0) * pitch
            for j in range(grid):
                by = (j - (grid - 1) / 2.0) * pitch
                cad.with_sketch("xy")
                outline = _rect(cad, bx - bump_s / 2.0, by - bump_s / 2.0,
                                bx + bump_s / 2.0, by + bump_s / 2.0)
                parts.append(cad.extrude("xy", cad.region(loop=outline, inside=(bx, by)),
                                         bump_h, offset=top_z, quality=quality,
                                         export=False))

        # Representative single-row 5-pin header along the -Y edge.
        hdr_len = (hdr_pins - 1) * hdr_pitch
        hdr_y0 = -half_d + 4.0
        cad.with_sketch("xy")
        header_outline = _rect(cad, -hdr_len / 2.0, hdr_y0, hdr_len / 2.0, hdr_y0 + hdr_d)
        parts.append(cad.extrude("xy",
                                 cad.region(loop=header_outline, inside=(0.0, hdr_y0 + hdr_d / 2.0)),
                                 hdr_h, offset=pcb_t, quality=quality, export=False))

        board = cad.bool_union(*parts, quality=quality)
        cad.set_color(board, "#1B5E20", finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric(f"ledmatrix_{key.lower().replace('x', '_')}", build,
                          quality=quality or "std", label=f"LED matrix ({key})")


# Dimensions per Raspberry Pi HAT mechanical specification (Raspberry Pi Foundation)
def rpi_hat(cad, quality=None):
    """A Raspberry Pi HAT/shield footprint board (see module docstring
    for dims). Origin is the board CENTER; z=0 is the PCB bottom face,
    the header protrudes +Z. Anchor: origin (0,0,0), mount_0..3."""
    W, D, T = 65.0, 56.0, 1.6
    hw, hd = W / 2.0, D / 2.0
    inset, hole_w, hole_d = 3.5, 58.0, 49.0
    hole_r = 2.75 / 2.0
    x_left, x_right = inset - hw, inset + hole_w - hw
    y_bottom, y_top = inset - hd, inset + hole_d - hd
    holes = [(x_left, y_bottom), (x_right, y_bottom), (x_left, y_top), (x_right, y_top)]

    hdr_pins, hdr_pitch, hdr_rows_gap, hdr_h = 20, 2.54, 5.0, 8.5
    hdr_len = (hdr_pins - 1) * hdr_pitch
    hdr_cy = -hd + 4.0 + hdr_rows_gap / 2.0

    def build():
        # A fresh plane per sketch, not the shared "xy" one: a HAT sits
        # directly on a Pi, so on one shared sketch the two outlines subdivide
        # each other's regions and the earlier board goes stale.
        pcb_plane = _plane_at(cad, 0.0)
        cad.with_sketch(pcb_plane)
        outline = _rect(cad, -hw, -hd, hw, hd)
        hole_circles = [cad.circle2d(cad.point2d(hx, hy), hole_r) for (hx, hy) in holes]
        pcb = cad.extrude(pcb_plane,
                          cad.region(loop=outline, holes=[[c] for c in hole_circles],
                                    inside=(0.0, 0.0)),
                          T, quality=quality, export=False)

        hdr_plane = _plane_at(cad, 0.0)
        cad.with_sketch(hdr_plane)
        hdr_outline = _rect(cad, -hdr_len / 2.0, hdr_cy - hdr_rows_gap / 2.0,
                            hdr_len / 2.0, hdr_cy + hdr_rows_gap / 2.0)
        header = cad.extrude(hdr_plane, cad.region(loop=hdr_outline, inside=(0.0, hdr_cy)),
                             hdr_h, offset=T, quality=quality, export=False)

        board = cad.bool_union(pcb, header, quality=quality)
        cad.set_color(board, "#1B5E20", finish="matte")
        cad.component_export(board)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))
        for i, (hx, hy) in enumerate(holes):
            cad.component_export_point(f"mount_{i}", cad.point(hx, hy, 0.0))

    return cad.parametric("rpi_hat", build, quality=quality or "std",
                          label="Raspberry Pi HAT")
