# flywheelcad standard library
"""Pneumatic / air-line fittings for bowden-tube (Festo/PISCO/SMC-style push-
to-connect "PC" class) and general shop-air / cable-strain-relief hardware.

Five catalog-class parts:

    pneumatic_fitting  PC-series push-to-connect bowden fitting (the
                        "PC4-M6"-class part used on nearly every FDM 3D
                        printer's hot end / extruder). thread base + hex +
                        collet, bored through for the tube.
                        "PC4-M6":  M6 thread (dia 6), hex af 10, collet dia 9,
                                   4mm tube bore  (generic PC4-M6 catalog spec)
                        "PC4-M10": M10 thread (dia 10), hex af 14, collet
                                   dia 12, 4mm bore (generic PC4-M10 spec)
                        "PC6-M6":  M6 thread (dia 6), hex af 12, collet dia
                                   11, 6mm bore (generic PC6-M6 spec)
                        Thread length 6mm, hex thickness 3mm, collet height
                        12mm are shared across the family (typical PC-series
                        proportions). Where the nominal thread OD would
                        leave zero wall around the bore ("PC6-M6": both are
                        6mm), the effective thread radius is bumped up to
                        keep >= 1mm of wall (see _MIN_WALL) -- a fabrication
                        necessity, not a catalog dimension.
    bowden_coupler      Inline PC4 tube-to-tube coupler: two PC4-M6-class
                        collets (dia 9, 12mm each) back to back, sharing one
                        central hex (af 10, 3mm -- reused from the PC4-M6
                        platform above for family consistency; no separate
                        published spec for the shared hex on this part).
                        Bore = tube_od.
    hose_barb           Generic barbed hose-to-thread adapter: a threaded
                        base (nominal thread dia, 8mm long) + a hex + a
                        barbed spigot (3 ridges over ~18mm, bulge diameter
                        ~= hose_id) with a small flow bore through the
                        whole part. Thread dia + hex across-flats:
                        "M6" -> dia 6, af 10 ; "M8" -> dia 8, af 13 ;
                        "G1_4" -> dia 13.157 (ISO 228 G 1/4 major diameter),
                        af 17. Hex thickness (6mm) and barb proportions
                        (neck = 60% of bulge, 3 ridges + tapered tip) are
                        typical brass-barb-fitting shape, not a formal spec.
    o_ring              Elastomer O-ring: a torus, sized by inner diameter +
                        cross-section diameter per the AS568/ISO 3601
                        sizing convention (revolve a circle of radius
                        cross_d/2 centered at inner_d/2 + cross_d/2).
    cable_gland         Metric / PG-thread cable gland (strain relief):
                        threaded body + hex + a domed compression cap-nut,
                        bored through for the cable. Body/hex/bore are
                        common catalog sizes (e.g. Lapp SKINTOP-style
                        nylon gland lines):
                        "M12" -> body 12, hex 15, bore 6
                        "M16" -> body 16, hex 19, bore 9
                        "PG7" -> body 12.5, hex 15, bore 6
                        "PG9" -> body 15.2, hex 18, bore 8
                        Thread length (10mm), hex thickness (5mm), and cap
                        collar height (4mm) are assumed typical proportions
                        (not separately published per size).

Orientation:
    pneumatic_fitting  hex seat at z = 0; thread -Z, collet +Z
    bowden_coupler      axis +Z; bottom collet base at z = 0, hex in the
                        middle, top collet at the far end
    hose_barb           hex seat at z = 0; thread -Z, barbed spigot +Z
    o_ring              torus centered on the world origin, tube axis is Z
    cable_gland         hex seat at z = 0; thread -Z, domed cap +Z

Anchor contract:
    pneumatic_fitting  base (0,0,0) [hex seat], top [collet tip]
    bowden_coupler      end_a (0,0,0), end_b
    hose_barb           base (0,0,0) [hex seat], tip [barb tip]
    o_ring              center (0,0,0)
    cable_gland         base (0,0,0) [hex seat], top [cap tip]
"""

__library_version__ = "1.0"

import math

# PC-series push-to-connect bowden fitting: thread dia, hex across-flats,
# collet dia, tube bore (mm). Thread length / hex thickness / collet height
# are shared across the family (see module docstring).
PNEUMATIC = {
    "PC4-M6":  dict(thread_d=6.0,  hex_af=10.0, collet_d=9.0,  bore=4.0),
    "PC4-M10": dict(thread_d=10.0, hex_af=14.0, collet_d=12.0, bore=4.0),
    "PC6-M6":  dict(thread_d=6.0,  hex_af=12.0, collet_d=11.0, bore=6.0),
}
_PNEU_THREAD_L = 6.0
_PNEU_HEX_T = 3.0
_PNEU_COLLET_H = 12.0
_MIN_WALL = 1.0  # minimum radial wall enforced around any through-bore

# Bowden tube-to-tube coupler: reuses the PC4-M6 collet + hex platform.
_BC_COLLET_D = 9.0
_BC_COLLET_H = 12.0
_BC_HEX_AF = 10.0
_BC_HEX_T = 3.0

# Barbed hose fitting: thread nominal dia + hex across-flats (mm).
# G1_4 major diameter per ISO 228 (BSPP G 1/4 ~ 13.157mm).
THREAD_BARB = {
    "M6":   dict(dia=6.0,     af=10.0),
    "M8":   dict(dia=8.0,     af=13.0),
    "G1_4": dict(dia=13.157,  af=17.0),
}
_BARB_THREAD_L = 8.0
_BARB_HEX_T = 6.0
_BARB_SPIGOT_LEN = 18.0
_BARB_N = 3
_BARB_ZONE_FRAC = 0.8    # fraction of the spigot used by the ridges; the
                          # remainder is a taper down to a point at the tip
_BARB_RAMP_FRAC = 0.7    # within one ridge: gentle up-ramp fraction (the
                          # rest is the sharp barb face, for hose grip)
_BARB_NECK_FRAC = 0.6    # neck radius as a fraction of the bulge radius

# Cable gland (strain relief): body dia, hex across-flats, cable bore (mm).
GLAND = {
    "M12": dict(body=12.0, hex=15.0, bore=6.0),
    "M16": dict(body=16.0, hex=19.0, bore=9.0),
    "PG7": dict(body=12.5, hex=15.0, bore=6.0),
    "PG9": dict(body=15.2, hex=18.0, bore=8.0),
}
_GLAND_BODY_L = 10.0
_GLAND_HEX_T = 5.0
_GLAND_COLLAR_H = 4.0

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float -- a variable or list(...) call yields NO dropdown.
# So every choice list is spelled out literally here. Continuous params
# (tube_od, hose_id, inner_d, cross_d) stay free-text.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "pneumatic_fitting": {"size": ["PC4-M6", "PC4-M10", "PC6-M6"]},
    "hose_barb": {"thread": ["M6", "M8", "G1_4"]},
    "cable_gland": {"size": ["M12", "M16", "PG7", "PG9"]},
}

_BRASS = "#B08D57"
_BLACK = "#212121"


def _plane_at(cad, z):
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _hexagon(cad, af, cx=0.0, cy=0.0):
    """Hex outline (list of lines) from across-flats width, flats top/bottom."""
    r = (af / 2.0) / math.cos(math.radians(30.0))
    pts = [cad.point2d(cx + r * math.cos(math.radians(60 * k + 30)),
                       cy + r * math.sin(math.radians(60 * k + 30))) for k in range(6)]
    return [cad.line2d(pts[i], pts[(i + 1) % 6]) for i in range(6)]


def _revolve_profile(cad, pts, inside, quality, on_axis=True):
    """Revolve a (radius, height) profile on ZX about the axis at r = 0.

    on_axis=True: the profile touches r = 0, so the closing edge IS the axis.
    on_axis=False: annular profile — a separate r = 0 construction axis is used.
    """
    cad.with_sketch("zx")
    p = [cad.point2d(r, z) for (r, z) in pts]
    lines = [cad.line2d(p[i], p[i + 1]) for i in range(len(p) - 1)]
    lines.append(cad.line2d(p[-1], p[0]))
    if on_axis:
        axis = lines[-1]
    else:
        zmin = min(z for (_, z) in pts)
        zmax = max(z for (_, z) in pts)
        axis = cad.line2d(cad.point2d(0.0, zmin), cad.point2d(0.0, zmax),
                          construction=True)
    return cad.revolve("zx", cad.region(loop=lines, inside=inside),
                       axis_line=axis, angle=360.0, quality=quality, export=False)


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def pneumatic_fitting(cad, size="PC4-M6", quality=None):
    """A PC-series push-to-connect bowden fitting: threaded base (-Z) + hex
    + collet body (+Z), bored through for the tube. Hex seat at z=0.
    Anchors: base (0,0,0), top (collet tip)."""
    key = str(size).upper()
    d = PNEUMATIC[key]
    bore_r = d["bore"] / 2.0
    thread_r = max(d["thread_d"] / 2.0, bore_r + _MIN_WALL)
    apothem = d["hex_af"] / 2.0
    collet_r = d["collet_d"] / 2.0
    z0 = -_PNEU_THREAD_L
    z1 = 0.0
    z2 = _PNEU_HEX_T
    z_top = z2 + _PNEU_COLLET_H

    def build():
        pts = [
            (bore_r, z0), (thread_r, z0), (thread_r, z1),
            (apothem, z1), (apothem, z2),
            (collet_r, z2), (collet_r, z_top), (bore_r, z_top),
        ]
        round_body = _revolve_profile(cad, pts, inside=((bore_r + thread_r) / 2.0, z0 / 2.0),
                                      quality=quality, on_axis=False)

        cad.with_sketch("xy")
        hex_outline = _hexagon(cad, d["hex_af"])
        bore_c = cad.circle2d(cad.point2d(0.0, 0.0), bore_r)
        hex_body = cad.extrude("xy", cad.region(loop=hex_outline, holes=[[bore_c]],
                                                inside=((bore_r + apothem) / 2.0, 0.0)),
                               _PNEU_HEX_T, quality=quality, export=False)

        fitting = cad.bool_union(round_body, hex_body, quality=quality)
        cad.set_color(fitting, _BRASS, finish="metallic")
        cad.component_export(fitting)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, z_top))

    safe = key.replace("-", "_").replace(".", "_")
    return cad.parametric(f"pneufit_{safe}", build, quality=quality or "std",
                          label=f"{key} pneumatic fitting")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def bowden_coupler(cad, tube_od=4.0, quality=None):
    """An inline PC4-class tube-to-tube coupler: two collet bodies back to
    back sharing a central hex. Axis +Z, base at z=0.
    Anchors: end_a (0,0,0), end_b."""
    tube_od = float(tube_od)
    bore_r = tube_od / 2.0
    collet_r = _BC_COLLET_D / 2.0
    apothem = _BC_HEX_AF / 2.0
    collet_h = _BC_COLLET_H
    hex_t = _BC_HEX_T
    total_h = 2.0 * collet_h + hex_t
    z_hex0 = collet_h
    z_hex1 = collet_h + hex_t

    def build():
        pts = [
            (bore_r, 0.0), (collet_r, 0.0), (collet_r, z_hex0),
            (apothem, z_hex0), (apothem, z_hex1),
            (collet_r, z_hex1), (collet_r, total_h), (bore_r, total_h),
        ]
        round_body = _revolve_profile(cad, pts, inside=((bore_r + collet_r) / 2.0, collet_h / 2.0),
                                      quality=quality, on_axis=False)

        hex_plane = _plane_at(cad, z_hex0)
        cad.with_sketch(hex_plane)
        hex_outline = _hexagon(cad, _BC_HEX_AF)
        bore_c = cad.circle2d(cad.point2d(0.0, 0.0), bore_r)
        hex_body = cad.extrude(hex_plane, cad.region(loop=hex_outline, holes=[[bore_c]],
                                                     inside=((bore_r + apothem) / 2.0, 0.0)),
                               hex_t, quality=quality, export=False)

        coupler = cad.bool_union(round_body, hex_body, quality=quality)
        cad.set_color(coupler, _BRASS, finish="metallic")
        cad.component_export(coupler)
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(0.0, 0.0, total_h))

    return cad.parametric("bowden_coupler", build, tube_od=tube_od,
                          quality=quality or "std",
                          label=f"Bowden coupler (tube {tube_od:g}mm)")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def hose_barb(cad, hose_id=6.0, thread="M6", quality=None):
    """A barbed hose-to-thread adapter: threaded base (-Z) + hex + a barbed
    spigot (+Z, 3 ridges tapering to a tip), with a small flow bore through
    the whole part. Hex seat at z=0. Anchors: base (0,0,0), tip."""
    key = str(thread).upper()
    t = THREAD_BARB[key]
    hose_id = float(hose_id)
    thread_r = t["dia"] / 2.0
    apothem = t["af"] / 2.0
    bulge_r = hose_id / 2.0
    neck_r = bulge_r * _BARB_NECK_FRAC
    bore_r = neck_r * 0.55

    z0 = -_BARB_THREAD_L
    z1 = 0.0
    z2 = _BARB_HEX_T
    barb_zone_len = _BARB_SPIGOT_LEN * _BARB_ZONE_FRAC
    z_top = z2 + _BARB_SPIGOT_LEN
    w = barb_zone_len / _BARB_N

    def build():
        pts = [(0.0, z0), (thread_r, z0), (thread_r, z1),
               (apothem, z1), (apothem, z2), (neck_r, z2)]
        for k in range(_BARB_N):
            z_start = z2 + k * w
            z_crest = z_start + w * _BARB_RAMP_FRAC
            z_end = z_start + w
            pts.append((bulge_r, z_crest))
            pts.append((neck_r, z_end))
        pts.append((0.0, z_top))  # taper to a point at the very tip

        solid = _revolve_profile(cad, pts, inside=(thread_r * 0.5, z0 * 0.5), quality=quality)

        cad.with_sketch("xy")
        hex_outline = _hexagon(cad, t["af"])
        hex_body = cad.extrude("xy", cad.region(loop=hex_outline, inside=(0.0, 0.0)),
                               z2 - z1, quality=quality, export=False)

        combined = cad.bool_union(solid, hex_body, quality=quality, export=False)

        cad.with_sketch("xy")
        bore_c = cad.circle2d(cad.point2d(0.0, 0.0), bore_r)
        bore_len = (z_top - z0) + 2.0
        bore = cad.extrude("xy", cad.region(loop=[bore_c], inside=(0.0, 0.0)),
                           bore_len, offset=z0 - 1.0, quality=quality, export=False)

        barb = cad.bool_difference(combined, bore, quality=quality)
        cad.set_color(barb, _BRASS, finish="metallic")
        cad.component_export(barb)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("tip", cad.point(0.0, 0.0, z_top))

    return cad.parametric(f"hosebarb_{key}", build, hose_id=hose_id,
                          quality=quality or "std",
                          label=f"{key} hose barb (hose ID {hose_id:g})")


# Dimensions per AS568 / ISO 3601 O-ring sizing convention (inner diameter + cross-section diameter)
def o_ring(cad, inner_d=10.0, cross_d=2.0, quality=None):
    """An elastomer O-ring: a torus (AS568/ISO 3601 sizing convention —
    inner diameter + cross-section diameter). Anchors: center (0,0,0)."""
    inner_d = float(inner_d)
    cross_d = float(cross_d)
    cx = inner_d / 2.0 + cross_d / 2.0
    cr = cross_d / 2.0

    def build():
        cad.with_sketch("zx")
        circle = cad.circle2d(cad.point2d(cx, 0.0), cr)
        axis = cad.line2d(cad.point2d(0.0, -cr), cad.point2d(0.0, cr), construction=True)
        torus = cad.revolve("zx", cad.region(loop=[circle], inside=(cx, 0.0)),
                            axis_line=axis, angle=360.0, quality=quality)
        cad.set_color(torus, _BLACK, finish="glossy")
        cad.component_export(torus)
        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("o_ring", build, inner_d=inner_d, cross_d=cross_d,
                          quality=quality or "std",
                          label=f"O-ring {inner_d:g}x{cross_d:g}")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def cable_gland(cad, size="M12", quality=None):
    """A metric/PG-thread cable gland: threaded body (-Z) + hex + a domed
    compression cap-nut (+Z), bored through for the cable. Hex seat at z=0.
    Anchors: base (0,0,0), top (cap tip)."""
    key = str(size).upper()
    g = GLAND[key]
    body_r = g["body"] / 2.0
    apothem = g["hex"] / 2.0
    bore_r = g["bore"] / 2.0
    cap_r = min(body_r + 1.5, apothem - 0.5)

    z0 = -_GLAND_BODY_L
    z1 = 0.0
    z2 = _GLAND_HEX_T
    z3 = z2 + _GLAND_COLLAR_H
    dome_r = cap_r - bore_r
    z_top = z3 + dome_r

    def build():
        n = 6
        # Dome arc from the collar equator (cap_r, z3) curving up and IN to
        # the bore edge (bore_r, z_top) — the cable bore continues through
        # the dome rather than closing it off.
        dome = [(bore_r + dome_r * math.cos(math.pi / 2 * a / n),
                 z3 + dome_r * math.sin(math.pi / 2 * a / n)) for a in range(1, n + 1)]
        pts = [(bore_r, z0), (body_r, z0), (body_r, z1),
               (apothem, z1), (apothem, z2),
               (cap_r, z2), (cap_r, z3)] + dome
        round_body = _revolve_profile(cad, pts, inside=((bore_r + body_r) / 2.0, z0 / 2.0),
                                      quality=quality, on_axis=False)

        cad.with_sketch("xy")
        hex_outline = _hexagon(cad, g["hex"])
        bore_c = cad.circle2d(cad.point2d(0.0, 0.0), bore_r)
        hex_body = cad.extrude("xy", cad.region(loop=hex_outline, holes=[[bore_c]],
                                                inside=((bore_r + apothem) / 2.0, 0.0)),
                               _GLAND_HEX_T, quality=quality, export=False)

        gland = cad.bool_union(round_body, hex_body, quality=quality)
        cad.set_color(gland, _BLACK, finish="matte")
        cad.component_export(gland)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, z_top))

    return cad.parametric(f"gland_{key}", build, quality=quality or "std",
                          label=f"{key} cable gland")
