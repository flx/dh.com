# flywheelcad standard library
"""Common through-hole / PCB-mount electronic hardware.

Five catalog-class parts, dimensions chosen from typical component
datasheets (through-hole LED, tactile switch, 0.1" pin header, 5.5x2.1mm
DC barrel jack, and a 4-hole cooling fan):

    led          5mm:  lens/body dia 5.0, cylindrical body height 6.0
                       topped by a hemispherical dome (dome radius ==
                       body radius), flange rim dia 5.9 x 1.0 thick at
                       the base, 2 leads dia 0.5 x length 15, 2.54mm
                       apart (standard 0.1" lead spacing).
                 3mm:  body dia 3.0, body height 4.0, dome radius 1.5,
                       flange dia 3.8 x 1.0; same leads as the 5mm class.
    tact_button  6mm:  body 6.0x6.0x3.5, round plunger dia 3.5 x 1.5
                       tall centered on top, 4 corner legs (0.5x0.5
                       posts, 3.0 long, pointing -Z).
                 12mm: body 12.0x12.0x7.3, same plunger + legs.
    header       0.1" (2.54mm pitch) pin header: plastic base sized to
                 the pin grid x 2.5 tall, 0.64x0.64 square gold pins
                 rising 6.0 above / 3.0 below the base.
    barrel_jack  PCB-mount DC barrel jack, 5.5x2.1mm class: body
                 9.0x13.0x11.0, barrel outer dia 8.0 / bore dia 6.3
                 protruding +Y from the front face, 3 solder pins -Z.
                 Barrel protrusion length (9.5mm) and pin layout are not
                 part of the 5.5x2.1mm spec; chosen as representative
                 catalog values.
    fan          Square cooling fan, mounting hole pattern is the part
                 that must be accurate to bolt to: frame S x S x
                 thickness, corner mounting holes (dia 4.5) on an H x H
                 square (40/60/80/120mm classes per AFB/Sunon-style
                 datasheets), central blade bore ~= 0.86*S, hub disk
                 ~= 0.28*S on 4 radial struts.

Orientation:
    led           flange bottom at z = 0, dome up (+Z), leads down (-Z)
    tact_button   body bottom at z = 0, plunger up (+Z), legs down (-Z)
    header        base bottom at z = 0, pins up (+Z) and through the base
    barrel_jack   body bottom at z = 0, barrel protrudes +Y
    fan           plate on world XY, z = 0 to thickness

Anchor contract:
    led           base (0,0,0), top (dome tip)
    tact_button   center (0,0,0), plunger_top
    header        pin_0 (first pin center, on top)
    barrel_jack   origin (0,0,0)
    fan           center (0,0,0), mount_0..3 (corner holes)
"""

__library_version__ = "1.0"

import math

LED = {
    "3mm": dict(body_r=1.5, body_h=4.0, dome_r=1.5, flange_r=1.9, flange_t=1.0),
    "5mm": dict(body_r=2.5, body_h=6.0, dome_r=2.5, flange_r=2.95, flange_t=1.0),
}
_LED_LEAD_R = 0.25
_LED_LEAD_LEN = 15.0
_LED_LEAD_SPACING = 2.54

TACT = {
    "6mm": dict(body=6.0, height=3.5),
    "12mm": dict(body=12.0, height=7.3),
}
_TACT_PLUNGER_D = 3.5
_TACT_PLUNGER_H = 1.5
_TACT_LEG = 0.5
_TACT_LEG_LEN = 3.0
_TACT_LEG_INSET = 0.65  # leg-center inset from the body edge (corner posts)

_HDR_PITCH = 2.54
_HDR_BASE_H = 2.5
_HDR_PIN_S = 0.64
_HDR_PIN_ABOVE = 6.0
_HDR_PIN_BELOW = 3.0

_JACK_BODY_X = 9.0
_JACK_BODY_Y = 13.0
_JACK_BODY_Z = 11.0
_JACK_BARREL_OD = 8.0
_JACK_BARREL_BORE = 6.3
_JACK_BARREL_LEN = 9.5   # typical protrusion for this connector class (not
                          # part of the 5.5x2.1mm bore spec; representative)
_JACK_PIN_D = 1.0
_JACK_PIN_LEN = 3.0

FAN = {
    "40mm": dict(s=40.0, t=10.0, h=32.0),
    "60mm": dict(s=60.0, t=25.0, h=50.0),
    "80mm": dict(s=80.0, t=25.0, h=71.5),
    "120mm": dict(s=120.0, t=25.0, h=105.0),
}
_FAN_HOLE_D = 4.5
_FAN_BORE_FRAC = 0.86
_FAN_HUB_FRAC = 0.28

# Dropdown choices for the browser's "Insert from Library" parameter form.
# NOTE: the app scans this dict with Python's AST and only reads LITERAL
# lists of str/int/float -- a variable or list(...) call yields NO dropdown.
# So every choice list is spelled out literally here. Continuous numeric
# params (pin count, etc.) stay free-text.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "led": {"size": ["3mm", "5mm"]},
    "tact_button": {"size": ["6mm", "12mm"]},
    "header": {"rows": [1, 2]},
    "fan": {"size": ["40mm", "60mm", "80mm", "120mm"]},
}


def _rect(cad, x0, y0, x1, y1):
    """Axis-aligned rectangle outline (lines list)."""
    p1 = cad.point2d(x0, y0)
    p2 = cad.point2d(x1, y0)
    p3 = cad.point2d(x1, y1)
    p4 = cad.point2d(x0, y1)
    return [cad.line2d(p1, p2), cad.line2d(p2, p3),
            cad.line2d(p3, p4), cad.line2d(p4, p1)]


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y).

    Used to give a shape group its OWN sketch page even when it sits at the
    same height as other geometry: elements sharing one sketch page get
    intersected/split by area detection, which breaks a region() call that
    names an untouched loop -- e.g. a radial strut rectangle that crosses a
    concentric hub/bore circle on the SAME page. A fresh plane keeps such
    overlapping-by-design shapes (later fused by bool_union) independent."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


def _revolve_profile(cad, pts, inside, quality, on_axis=True):
    """Revolve a (radius, height) profile on ZX about the axis at r = 0.

    on_axis=True: the profile touches r = 0, so the closing edge IS the axis.
    on_axis=False: annular profile -- a separate r = 0 construction axis.
    """
    cad.with_sketch("zx")
    p = [cad.point2d(r, z) for (r, z) in pts]
    lines = [cad.line2d(p[i], p[i + 1]) for i in range(len(p) - 1)]
    lines.append(cad.line2d(p[-1], p[0]))
    if on_axis:
        axis = lines[-1]
    else:
        zmin = min(z for (_, z) in pts)
        zmax = max(z for (_, z) in pts)
        axis = cad.line2d(cad.point2d(0.0, zmin), cad.point2d(0.0, zmax),
                          construction=True)
    return cad.revolve("zx", cad.region(loop=lines, inside=inside),
                       axis_line=axis, angle=360.0, quality=quality, export=False)


# Dimensions per EIA T-1 (3mm) / T-1 3/4 (5mm) LED lamp package standard
def led(cad, size="5mm", quality=None):
    """A through-hole LED. size: "3mm" or "5mm".

    Anchors: base (z=0, flange bottom), top (dome tip). Dome up (+Z),
    leads down (-Z)."""
    key = str(size)
    d = LED[key]

    def build():
        body_r, body_h, dome_r = d["body_r"], d["body_h"], d["dome_r"]
        flange_r, flange_t = d["flange_r"], d["flange_t"]
        cyl_top = flange_t + body_h
        top_z = cyl_top + dome_r

        # Dome approximated by an arc of points from the body rim up to the
        # crown; the crown sits on the axis so the profile closes cleanly.
        n = 6
        dome = [(body_r * math.cos(math.pi / 2 * t / n),
                 cyl_top + body_r * math.sin(math.pi / 2 * t / n))
                for t in range(1, n + 1)]
        pts = [(0.0, 0.0), (flange_r, 0.0), (flange_r, flange_t),
               (body_r, flange_t), (body_r, cyl_top)] + dome
        lens = _revolve_profile(cad, pts,
                                inside=(body_r * 0.5, flange_t + body_h * 0.5),
                                quality=quality)

        half_sp = _LED_LEAD_SPACING / 2.0
        cad.with_sketch("xy")
        lead_c1 = cad.circle2d(cad.point2d(half_sp, 0.0), _LED_LEAD_R)
        lead1 = cad.extrude("xy", cad.region(loop=[lead_c1], inside=(half_sp, 0.0)),
                            _LED_LEAD_LEN, offset=-_LED_LEAD_LEN, quality=quality,
                            export=False)
        cad.with_sketch("xy")
        lead_c2 = cad.circle2d(cad.point2d(-half_sp, 0.0), _LED_LEAD_R)
        lead2 = cad.extrude("xy", cad.region(loop=[lead_c2], inside=(-half_sp, 0.0)),
                            _LED_LEAD_LEN, offset=-_LED_LEAD_LEN, quality=quality,
                            export=False)

        body = cad.bool_union(lens, lead1, lead2, quality=quality)
        cad.set_color(body, "#E53935", finish="glass")
        cad.component_export(body)
        cad.component_export_point("base", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("top", cad.point(0.0, 0.0, top_z))

    return cad.parametric(f"led_{key}", build, quality=quality or "std",
                          label=f"{key} LED")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def tact_button(cad, size="6mm", quality=None):
    """A tactile push button. size: "6mm" or "12mm".

    Anchors: center (z=0, body bottom), plunger_top. Plunger up (+Z),
    legs down (-Z)."""
    key = str(size)
    d = TACT[key]
    body_s, body_h = d["body"], d["height"]

    def build():
        half = body_s / 2.0
        corner = half - _TACT_LEG_INSET

        cad.with_sketch("xy")
        body_outline = _rect(cad, -half, -half, half, half)
        body_box = cad.extrude("xy", cad.region(loop=body_outline, inside=(0.0, 0.0)),
                               body_h, quality=quality, export=False)

        legs = []
        for (lx, ly) in [(corner, corner), (-corner, corner),
                        (-corner, -corner), (corner, -corner)]:
            cad.with_sketch("xy")
            leg_outline = _rect(cad, lx - _TACT_LEG / 2.0, ly - _TACT_LEG / 2.0,
                                lx + _TACT_LEG / 2.0, ly + _TACT_LEG / 2.0)
            legs.append(cad.extrude("xy", cad.region(loop=leg_outline, inside=(lx, ly)),
                                    _TACT_LEG_LEN, offset=-_TACT_LEG_LEN,
                                    quality=quality, export=False))

        base = cad.bool_union(body_box, *legs, quality=quality)
        cad.set_color(base, "#212121", finish="matte")
        cad.component_export(base)

        cad.with_sketch("xy")
        plunger_c = cad.circle2d(cad.point2d(0.0, 0.0), _TACT_PLUNGER_D / 2.0)
        plunger = cad.extrude("xy", cad.region(loop=[plunger_c], inside=(0.0, 0.0)),
                              _TACT_PLUNGER_H, offset=body_h, quality=quality)
        cad.set_color(plunger, "#9E9E9E", finish="matte")
        cad.component_export(plunger)

        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("plunger_top", cad.point(0.0, 0.0, body_h + _TACT_PLUNGER_H))

    return cad.parametric(f"tact_{key}", build, quality=quality or "std",
                          label=f"{key} tactile button")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def header(cad, pins=4, rows=1, quality=None):
    """A 0.1" (2.54mm pitch) pin header. pins: count per row (free text);
    rows: 1 or 2.

    Anchors: pin_0 (first pin center, on top). Base bottom at z=0, pins up."""
    n_pins = int(pins)
    n_rows = int(rows)

    def build():
        half_x = _HDR_PITCH * n_pins / 2.0
        half_y = _HDR_PITCH * n_rows / 2.0

        cad.with_sketch("xy")
        base_outline = _rect(cad, -half_x, -half_y, half_x, half_y)
        base = cad.extrude("xy", cad.region(loop=base_outline, inside=(0.0, 0.0)),
                           _HDR_BASE_H, quality=quality, export=False)
        cad.set_color(base, "#212121", finish="matte")
        cad.component_export(base)

        pin_len = _HDR_BASE_H + _HDR_PIN_ABOVE + _HDR_PIN_BELOW
        pins_list = []
        pin0 = None
        for r in range(n_rows):
            y = (r - (n_rows - 1) / 2.0) * _HDR_PITCH
            for c in range(n_pins):
                x = (c - (n_pins - 1) / 2.0) * _HDR_PITCH
                cad.with_sketch("xy")
                outline = _rect(cad, x - _HDR_PIN_S / 2.0, y - _HDR_PIN_S / 2.0,
                                x + _HDR_PIN_S / 2.0, y + _HDR_PIN_S / 2.0)
                post = cad.extrude("xy", cad.region(loop=outline, inside=(x, y)),
                                   pin_len, offset=-_HDR_PIN_BELOW, quality=quality,
                                   export=False)
                pins_list.append(post)
                if pin0 is None:
                    pin0 = (x, y)

        if len(pins_list) > 1:
            pins_body = cad.bool_union(*pins_list, quality=quality)
        else:
            pins_body = pins_list[0]
            pins_body.set_export(True)
        cad.set_color(pins_body, "#FFC107", finish="metallic")
        cad.component_export(pins_body)

        cad.component_export_point("pin_0", cad.point(pin0[0], pin0[1], _HDR_BASE_H + _HDR_PIN_ABOVE))

    return cad.parametric(f"header_{n_pins}x{n_rows}", build,
                          pins=n_pins, rows=n_rows, quality=quality or "std",
                          label=f"{n_pins}x{n_rows} pin header")


# Dimensions per EIAJ RC-5320A (5.5x2.1mm DC barrel connector class)
def barrel_jack(cad, quality=None):
    """A PCB-mount DC barrel jack (5.5x2.1mm class).

    Anchor: origin (0,0,0). Body sits on z=0; the barrel protrudes +Y
    from the front face; 3 solder pins point -Z."""

    def build():
        hx, hy = _JACK_BODY_X / 2.0, _JACK_BODY_Y / 2.0
        y_front = hy
        z_center = _JACK_BODY_Z / 2.0
        barrel_r = _JACK_BARREL_OD / 2.0
        bore_r = _JACK_BARREL_BORE / 2.0
        bore_depth = _JACK_BARREL_LEN + 3.0

        cad.with_sketch("xy")
        body_outline = _rect(cad, -hx, -hy, hx, hy)
        body_box = cad.extrude("xy", cad.region(loop=body_outline, inside=(0.0, 0.0)),
                               _JACK_BODY_Z, quality=quality, export=False)

        # Barrel + bore sit on the world X=0 axis, so they are sketched on
        # the "zx" plane (u=-X, v=+Z there) with local a=0 -- the u-axis
        # sign never matters because the features are centered on X=0.
        cad.with_sketch("zx")
        barrel_c = cad.circle2d(cad.point2d(0.0, z_center), barrel_r)
        barrel = cad.extrude("zx", cad.region(loop=[barrel_c], inside=(0.0, z_center)),
                             _JACK_BARREL_LEN, offset=y_front, quality=quality,
                             export=False)

        pins = []
        for px in (-3.0, 0.0, 3.0):
            cad.with_sketch("xy")
            pin_c = cad.circle2d(cad.point2d(px, 0.0), _JACK_PIN_D / 2.0)
            pins.append(cad.extrude("xy", cad.region(loop=[pin_c], inside=(px, 0.0)),
                                    _JACK_PIN_LEN, offset=-_JACK_PIN_LEN,
                                    quality=quality, export=False))

        solid = cad.bool_union(body_box, barrel, *pins, quality=quality, export=False)

        cad.with_sketch("zx")
        bore_c = cad.circle2d(cad.point2d(0.0, z_center), bore_r)
        y_tip = y_front + _JACK_BARREL_LEN
        bore = cad.extrude("zx", cad.region(loop=[bore_c], inside=(0.0, z_center)),
                           bore_depth, offset=(y_tip - bore_depth), quality=quality,
                           export=False)

        jack = cad.bool_difference(solid, bore, quality=quality)
        cad.set_color(jack, "#37474F", finish="matte")
        cad.component_export(jack)
        cad.component_export_point("origin", cad.point(0.0, 0.0, 0.0))

    return cad.parametric("barrel_jack", build, quality=quality or "std",
                          label="DC barrel jack (5.5x2.1mm)")


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def fan(cad, size="40mm", quality=None):
    """A square cooling fan. size: "40mm", "60mm", "80mm", or "120mm".

    The mounting-hole square (dia 4.5 corner holes) is the accurate part
    -- that's what bolts to a case. Anchors: center (0,0,0), mount_0..3
    (corner holes, CCW starting at (+x,+y)). Plate on XY, z=0 to thickness."""
    key = str(size)
    d = FAN[key]
    s, t, h = d["s"], d["t"], d["h"]

    def build():
        half = s / 2.0
        hh = h / 2.0
        bore_r = s * _FAN_BORE_FRAC / 2.0
        hub_r = s * _FAN_HUB_FRAC / 2.0
        hole_r = _FAN_HOLE_D / 2.0
        strut_w = max(2.0, s * 0.035)

        bolt_xy = [(hh, hh), (-hh, hh), (-hh, -hh), (hh, -hh)]

        cad.with_sketch("xy")
        outline = _rect(cad, -half, -half, half, half)
        bore_c = cad.circle2d(cad.point2d(0.0, 0.0), bore_r)
        hole_circles = [cad.circle2d(cad.point2d(bx, by), hole_r) for (bx, by) in bolt_xy]
        inside_x = (bore_r + half) / 2.0
        frame = cad.extrude("xy",
                            cad.region(loop=outline,
                                      holes=[[bore_c]] + [[c] for c in hole_circles],
                                      inside=(inside_x, 0.0)),
                            t, quality=quality, export=False)

        # Hub and struts are drawn on THEIR OWN fresh planes (still at z=0,
        # so they extrude over the same [0, t] span as the frame) rather
        # than "xy": the struts radially overlap the frame's bore circle
        # and the hub circle by design (so bool_union fuses them solidly),
        # and elements that cross on ONE sketch page get split by area
        # detection, which breaks a region() naming the original loop.
        hub_plane = _plane_at(cad, 0.0)
        cad.with_sketch(hub_plane)
        hub_c = cad.circle2d(cad.point2d(0.0, 0.0), hub_r)
        hub = cad.extrude(hub_plane, cad.region(loop=[hub_c], inside=(0.0, 0.0)),
                          t, quality=quality, export=False)

        r_in = max(0.0, hub_r - 1.0)
        r_out = min(bore_r + 1.5, half - 0.5)
        strut_plane = _plane_at(cad, 0.0)
        struts = []
        for deg in (0.0, 90.0, 180.0, 270.0):
            a = math.radians(deg)
            ca, sa = math.cos(a), math.sin(a)

            def rot(x, y):
                return (x * ca - y * sa, x * sa + y * ca)

            corners = [(r_in, -strut_w / 2.0), (r_out, -strut_w / 2.0),
                      (r_out, strut_w / 2.0), (r_in, strut_w / 2.0)]
            cad.with_sketch(strut_plane)
            spts = [cad.point2d(*rot(x, y)) for (x, y) in corners]
            outline_s = [cad.line2d(spts[i], spts[(i + 1) % 4]) for i in range(4)]
            mid = rot((r_in + r_out) / 2.0, 0.0)
            struts.append(cad.extrude(strut_plane, cad.region(loop=outline_s, inside=mid),
                                      t, quality=quality, export=False))

        body = cad.bool_union(frame, hub, *struts, quality=quality)
        cad.set_color(body, "#455A64", finish="matte")
        cad.component_export(body)

        cad.component_export_point("center", cad.point(0.0, 0.0, 0.0))
        for i, (bx, by) in enumerate(bolt_xy):
            cad.component_export_point(f"mount_{i}", cad.point(bx, by, 0.0))

    return cad.parametric(f"fan_{key}", build, quality=quality or "std",
                          label=f"{key} cooling fan")
