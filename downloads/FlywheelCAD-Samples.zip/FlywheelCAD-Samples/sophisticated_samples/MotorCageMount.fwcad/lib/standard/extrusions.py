# flywheelcad standard library
"""T-slot aluminum extrusion (metric 20/30/40 series framing).

Parametric rails with the standard slot profile approximated as a
T-groove per face cell: slot opening, neck, and inner cavity, plus the
center bore of each cell. Profiles: 2020, 2040, 4020, 3030, 4040 (cell
grid × 20 or 30/40 mm module).

Anchor contract:
    end_a          profile center at z = 0 (the near end face)
    end_b          profile center at z = length
    corner_a       the profile's (0, 0) outline corner at z = 0 -- off the
                   long axis, so a second point-mate here (alongside end_a)
                   pins rotation about the rail's length
    corner_b       same corner at z = length
    bore_a_<i>     each cell's center-bore on the z = 0 face
    bore_b_<i>     same on the far face (tap them for end joining)

Orientation: profile in the world XY plane, rail extruded up +Z from
z = 0 to z = length. The cell grid extends +X/+Y from the first cell.
"""

__library_version__ = "1.0"

# series module: cell size, slot opening width, slot depth to cavity,
# neck depth, cavity width, center bore Ø (tap size in comments).
# Cavity sizes are trimmed slightly from catalog values so the cavities
# of ADJACENT faces never overlap at the profile corners (real profiles
# keep a thin diagonal web there; the outline must stay a single loop):
# cavity_w/2 + (neck + cavity_d) < cell/2.
SERIES = {
    20: dict(cell=20.0, slot_w=6.2,  neck=1.8, cavity_w=8.8,  cavity_d=3.4, bore_d=4.2),   # M5 tap
    30: dict(cell=30.0, slot_w=8.2,  neck=2.4, cavity_w=14.5, cavity_d=4.4, bore_d=6.8),   # M8 tap
    40: dict(cell=40.0, slot_w=10.3, neck=3.0, cavity_w=20.0, cavity_d=5.5, bore_d=8.5),   # M10 tap
}

PROFILES = {
    "2020": (20, 1, 1), "2040": (20, 1, 2), "4020": (20, 2, 1),
    "2060": (20, 1, 3), "3030": (30, 1, 1), "3060": (30, 1, 2),
    "4040": (40, 1, 1), "4080": (40, 1, 2),
}

# Dropdown choices for the browser's "Insert from Library" parameter form.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "rail": {"profile": ["2020", "2040", "4020", "2060", "3030", "3060", "4040", "4080"]},
}


def _slot_notch(cx, t, s):
    """Outline points of one T-slot notch, walking the perimeter in the
    +walk direction. `cx` is the slot center along the walked edge; the
    points are (along, depth-into-profile) pairs."""
    half_open = s["slot_w"] / 2.0
    half_cavity = s["cavity_w"] / 2.0
    neck = s["neck"]
    inner = neck + s["cavity_d"]
    return [
        (cx - half_open, 0.0),
        (cx - half_open, neck),
        (cx - half_cavity, neck),
        (cx - half_cavity, inner),
        (cx + half_cavity, inner),
        (cx + half_cavity, neck),
        (cx + half_open, neck),
        (cx + half_open, 0.0),
    ]


def _profile_outline(nx, ny, s):
    """Closed outline of an nx×ny cell T-slot profile as (x, y) points,
    counter-clockwise, with one T-notch per cell edge on every face."""
    cell = s["cell"]
    w, h = nx * cell, ny * cell
    pts = []

    def edge(from_pt, to_pt, n_cells):
        """Walk one straight edge, inserting a notch per cell."""
        (x0, y0), (x1, y1) = from_pt, to_pt
        ex, ey = x1 - x0, y1 - y0
        elen = (ex * ex + ey * ey) ** 0.5
        ux, uy = ex / elen, ey / elen          # along the edge
        # Inward normal for a CCW outline is the edge direction rotated
        # +90°: (-uy, ux).
        nxv, nyv = -uy, ux
        pts.append((x0, y0))
        for c in range(n_cells):
            center = (c + 0.5) * cell
            for (along, depth) in _slot_notch(center, None, s):
                pts.append((x0 + ux * along + nxv * depth,
                            y0 + uy * along + nyv * depth))
        # end corner appended by the next edge's start

    edge((0.0, 0.0), (w, 0.0), nx)     # bottom, walking +X
    edge((w, 0.0), (w, h), ny)         # right, walking +Y
    edge((w, h), (0.0, h), nx)         # top, walking -X
    edge((0.0, h), (0.0, 0.0), ny)     # left, walking -Y
    return pts


# Dimensions per manufacturer-neutral catalog envelope (no single governing standard)
def rail(cad, profile="2020", length=100.0, quality=None):
    """A T-slot extrusion rail.

    profile: "2020", "2040", "4020", "2060", "3030", "3060", "4040", "4080"
    length:  rail length along +Z, mm

    Returns a component name for cad.instance(...). Anchors: end_a/end_b
    (profile centers), corner_a/corner_b (the profile's off-axis (0, 0)
    corner, for pinning rotation about the rail's length), and bore_a_i /
    bore_b_i per cell center bore.
    """
    key = str(profile)
    series, nx, ny = PROFILES[key]
    s = SERIES[series]
    length = float(length)

    def build():
        cell = s["cell"]
        outline_pts = _profile_outline(nx, ny, s)
        cad.with_sketch("xy")
        pts = [cad.point2d(x, y) for (x, y) in outline_pts]
        lines = [cad.line2d(pts[i], pts[(i + 1) % len(pts)]) for i in range(len(pts))]

        bores = []
        centers = []
        for j in range(ny):
            for i in range(nx):
                cx, cy = (i + 0.5) * cell, (j + 0.5) * cell
                centers.append((cx, cy))
                bores.append(cad.circle2d(cad.point2d(cx, cy), s["bore_d"] / 2.0))

        # Inside point: the first cell's corner block — outside the slot
        # cavities' along-edge span and clear of the center bore in every
        # series.
        ix = centers[0][0] + cell * 0.375
        iy = centers[0][1] + cell * 0.375
        body = cad.extrude("xy",
                           cad.region(loop=lines, holes=[[c] for c in bores],
                                      inside=(ix, iy)),
                           length, quality=quality)
        cad.set_color(body, "#CFD8DC", finish="matte")
        cad.component_export(body)

        w, h = nx * cell, ny * cell
        cad.component_export_point("end_a", cad.point(w / 2.0, h / 2.0, 0.0))
        cad.component_export_point("end_b", cad.point(w / 2.0, h / 2.0, length))
        # Off-axis reference at the profile's (0, 0) outline corner (a real
        # solid corner of every profile, per _profile_outline) so a second
        # point-mate here fully constrains rotation about the rail's length
        # -- end_a/end_b alone only fix position along the axis.
        cad.component_export_point("corner_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("corner_b", cad.point(0.0, 0.0, length))
        for k, (cx, cy) in enumerate(centers):
            cad.component_export_point(f"bore_a_{k}", cad.point(cx, cy, 0.0))
            cad.component_export_point(f"bore_b_{k}", cad.point(cx, cy, length))

    return cad.parametric(f"rail_{key}", build,
                          length=length, quality=quality or "std",
                          label=f"{key} rail x {length:g}mm")
