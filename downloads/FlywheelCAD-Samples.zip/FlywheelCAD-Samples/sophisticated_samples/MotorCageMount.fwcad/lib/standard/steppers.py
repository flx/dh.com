# flywheelcad standard library
"""NEMA stepper motors.

Parametric stepper-motor bodies with the standard mounting interface as
named anchor points. Dimensions follow the published NEMA faceplate
standard (faceplate width, mounting-bolt square, pilot boss, shaft), with
catalog-style detailing: front/rear end bells with an inset center stack,
real bolt holes through the front bell, a shaft flat, and a wire exit.

Two body styles, matching the two common catalog forms:
    body="square"   chamfered-square frame (end bells + laminated stack)
    body="round"    cylindrical can behind a square mounting flange

Anchor contract (all motors):
    mount_face  center of the mounting flange face (the plane a bracket
                bolts against; the pilot boss protrudes through it)
    shaft_tip   free end of the output shaft
    shaft_base  shaft where it leaves the pilot boss
    bolt_0..3   mounting-bolt positions on the flange face, counter-
                clockwise starting at (+x, +y)

Orientation: the mount face lies in the world XY plane at z = 0 with the
shaft pointing +Z and the motor can extending -Z. Place and orient the
instance with transforms or mates.
"""

__library_version__ = "2.0"

# NEMA faceplate table (mm): faceplate width, mounting-bolt square, tap
# hole radius, pilot boss diameter and height, shaft diameter, and typical
# default can/shaft lengths for the common catalog size of each frame.
NEMA = {
    8:  dict(face=20.3, bolt=16.0,  hole_r=1.0,  boss=15.0, boss_h=1.5,
             shaft_d=4.0,  length=30.0, shaft_len=10.0, bolt_thread="M2"),
    11: dict(face=28.2, bolt=23.0,  hole_r=1.25, boss=22.0, boss_h=2.0,
             shaft_d=5.0,  length=32.0, shaft_len=20.0, bolt_thread="M2.5"),
    14: dict(face=35.2, bolt=26.0,  hole_r=1.5,  boss=22.0, boss_h=2.0,
             shaft_d=5.0,  length=28.0, shaft_len=24.0, bolt_thread="M3"),
    17: dict(face=42.3, bolt=31.0,  hole_r=1.5,  boss=22.0, boss_h=2.0,
             shaft_d=5.0,  length=40.0, shaft_len=24.0, bolt_thread="M3"),
    23: dict(face=56.4, bolt=47.14, hole_r=2.15, boss=38.1, boss_h=1.6,
             shaft_d=6.35, length=56.0, shaft_len=20.6, bolt_thread="M4 (through)"),
    34: dict(face=86.0, bolt=69.6,  hole_r=2.75, boss=73.0, boss_h=1.9,
             shaft_d=14.0, length=80.0, shaft_len=37.0, bolt_thread="M6 (through)"),
}

# Dropdown choices for the browser's "Insert from Library" parameter form.
# `size` matches the NEMA table's (integer) keys, not strings.
PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "stepper": {
        "size": [8, 11, 14, 17, 23, 34],
        "body": ["square", "round"],
    },
}


def _octagon(cad, half, cham, cx=0.0, cy=0.0):
    """Chamfered-square outline (lines list) centered on (cx, cy)."""
    corners = [
        (half - cham, -half), (half, -half + cham),
        (half, half - cham), (half - cham, half),
        (-half + cham, half), (-half, half - cham),
        (-half, -half + cham), (-half + cham, -half),
    ]
    pts = [cad.point2d(cx + x, cy + y) for (x, y) in corners]
    return [cad.line2d(pts[i], pts[(i + 1) % len(pts)]) for i in range(len(pts))]


def _plane_at(cad, z):
    """A sketch plane parallel to XY at height z (frame: u=+X, v=+Y)."""
    p0 = cad.point(0.0, 0.0, z)
    px = cad.point(1.0, 0.0, z)
    py = cad.point(0.0, 1.0, z)
    return cad.create_sketch_plane(p0, px, py)


# Dimensions per NEMA (MG1 / ICS 16) stepper motor faceplate standard
def stepper(cad, size=17, length=None, shaft_length=None, body="square", quality=None):
    """A NEMA stepper motor with catalog-style detailing.

    size:         NEMA frame size (8, 11, 14, 17, 23, or 34)
    length:       can length in mm (default: a typical catalog length)
    shaft_length: output-shaft length in mm (default: typical for size)
    body:         "square" (end-bell frame) or "round" (cylindrical can
                  behind a square mounting flange)
    quality:      mesh quality preset forwarded to the body commands

    Returns a component name for cad.instance(...). Instances expose the
    anchor contract documented in the module docstring.
    """
    d = NEMA[int(size)]
    length = float(length if length is not None else d["length"])
    shaft_len = float(shaft_length if shaft_length is not None else d["shaft_len"])
    style = str(body)

    def build():
        face, bolt, hole_r = d["face"], d["bolt"], d["hole_r"]
        boss_r, boss_h = d["boss"] / 2.0, d["boss_h"]
        shaft_r = d["shaft_d"] / 2.0
        half = face / 2.0
        # Corner chamfer: catalog look is ~15% of the face, but it must
        # clear the bolt holes (NEMA 11's bolt square runs close to the
        # corners, where a full-size chamfer would cut into the holes).
        cham = max(1.0, min(face * 0.15,
                            2.0 * half - bolt - 1.42 * (hole_r + 0.6)))
        b = bolt / 2.0
        bolt_xy = [(b, b), (-b, b), (-b, -b), (b, -b)]

        parts = []

        # ---- mount-face plate on XY: chamfered square with REAL bolt
        # holes (the nested circles become holes of the region).
        cad.with_sketch("xy")
        outline = _octagon(cad, half, cham)
        hole_circles = [cad.circle2d(cad.point2d(bx, by), hole_r) for (bx, by) in bolt_xy]
        face_region = cad.region(loop=outline,
                                 holes=[[c] for c in hole_circles],
                                 inside=(0.0, 0.0))

        if style == "round":
            # Square mounting flange, then a cylindrical can behind it.
            flange_t = max(4.5, boss_h + 2.5)
            parts.append(cad.extrude("xy", face_region, flange_t,
                                     offset=-flange_t, quality=quality, export=False))
            can_plane = _plane_at(cad, -flange_t)
            cad.with_sketch(can_plane)
            can_r = half * 0.94
            can_circle = cad.circle2d(cad.point2d(0.0, 0.0), can_r)
            can_len = length - flange_t
            parts.append(cad.extrude(can_plane,
                                     cad.region(loop=[can_circle], inside=(0.0, 0.0)),
                                     can_len, offset=-can_len, quality=quality, export=False))
        else:
            # Square frame: front bell (with the bolt holes), inset center
            # stack, rear bell — the classic laminated-stepper silhouette.
            bell = min(max(6.0, length * 0.22), length / 3.0)
            parts.append(cad.extrude("xy", face_region, bell,
                                     offset=-bell, quality=quality, export=False))
            inset = max(0.5, face * 0.02)
            mid_plane = _plane_at(cad, -bell)
            cad.with_sketch(mid_plane)
            mid_outline = _octagon(cad, half - inset, max(cham - inset, 1.0))
            mid_len = length - 2.0 * bell
            parts.append(cad.extrude(mid_plane,
                                     cad.region(loop=mid_outline, inside=(0.0, 0.0)),
                                     mid_len, offset=-mid_len, quality=quality, export=False))
            rear_plane = _plane_at(cad, -length + bell)
            cad.with_sketch(rear_plane)
            rear_outline = _octagon(cad, half, cham)
            parts.append(cad.extrude(rear_plane,
                                     cad.region(loop=rear_outline, inside=(0.0, 0.0)),
                                     bell, offset=-bell, quality=quality, export=False))

        # ---- pilot boss + shaft: one stepped profile revolved about the
        # motor axis. Sketch frames keep sketch-"up" at world +Z, so on the
        # zx plane the profile reads (radius, height) and the revolve axis
        # is the vertical radius-0 edge.
        cad.with_sketch("zx")
        q1 = cad.point2d(0.0, 0.0)
        q2 = cad.point2d(boss_r, 0.0)
        q3 = cad.point2d(boss_r, boss_h)
        q4 = cad.point2d(shaft_r, boss_h)
        q5 = cad.point2d(shaft_r, shaft_len)
        q6 = cad.point2d(0.0, shaft_len)
        e1 = cad.line2d(q1, q2)
        e2 = cad.line2d(q2, q3)
        e3 = cad.line2d(q3, q4)
        e4 = cad.line2d(q4, q5)
        e5 = cad.line2d(q5, q6)
        e6 = cad.line2d(q6, q1)  # closes along the revolve axis (radius 0)
        parts.append(cad.revolve("zx",
                                 cad.region(loop=[e1, e2, e3, e4, e5, e6],
                                            inside=(boss_r / 2.0, boss_h / 2.0)),
                                 axis_line=e6, angle=360.0, quality=quality, export=False))

        # ---- wire exit: a small block low on the -Y side of the can.
        we_w, we_d, we_h = face * 0.28, 4.0, 6.0
        we_top = -length + we_h + 2.0
        we_plane = _plane_at(cad, we_top)
        cad.with_sketch(we_plane)
        w1 = cad.point2d(-we_w / 2.0, -half - we_d)
        w2 = cad.point2d(we_w / 2.0, -half - we_d)
        w3 = cad.point2d(we_w / 2.0, -half + 1.5)
        w4 = cad.point2d(-we_w / 2.0, -half + 1.5)
        wl1 = cad.line2d(w1, w2)
        wl2 = cad.line2d(w2, w3)
        wl3 = cad.line2d(w3, w4)
        wl4 = cad.line2d(w4, w1)
        parts.append(cad.extrude(we_plane,
                                 cad.region(loop=[wl1, wl2, wl3, wl4],
                                            inside=(0.0, -half - we_d / 2.0)),
                                 we_h, offset=-we_h, quality=quality, export=False))

        solid = cad.bool_union(*parts, quality=quality)

        # ---- shaft flat: subtract a small block near the tip.
        flat_len = min(shaft_len * 0.6, 20.0)
        flat_depth = max(0.4, shaft_r * 0.2)
        fx = shaft_r - flat_depth
        f_plane = _plane_at(cad, shaft_len + 1.0)
        cad.with_sketch(f_plane)
        f1 = cad.point2d(fx, -shaft_r - 1.0)
        f2 = cad.point2d(shaft_r + 1.0, -shaft_r - 1.0)
        f3 = cad.point2d(shaft_r + 1.0, shaft_r + 1.0)
        f4 = cad.point2d(fx, shaft_r + 1.0)
        fl1 = cad.line2d(f1, f2)
        fl2 = cad.line2d(f2, f3)
        fl3 = cad.line2d(f3, f4)
        fl4 = cad.line2d(f4, f1)
        cut_h = flat_len + 2.0
        flat_box = cad.extrude(f_plane,
                               cad.region(loop=[fl1, fl2, fl3, fl4],
                                          inside=(fx + 0.5, 0.0)),
                               cut_h, offset=-cut_h, quality=quality, export=False)

        motor = cad.bool_difference(solid, flat_box, quality=quality)
        cad.set_color(motor, "#37474F", finish="matte")
        cad.component_export(motor)

        cad.component_export_point("mount_face", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("shaft_tip", cad.point(0.0, 0.0, shaft_len))
        cad.component_export_point("shaft_base", cad.point(0.0, 0.0, boss_h))
        for i, (bx, by) in enumerate(bolt_xy):
            cad.component_export_point(f"bolt_{i}", cad.point(bx, by, 0.0))

    return cad.parametric(f"nema{int(size)}", build,
                          length=length, shaft=shaft_len, body=style,
                          quality=quality or "std",
                          label=f"NEMA {int(size)} {length:g}mm")
