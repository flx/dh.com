# flywheelcad standard library
"""Shaft hardware: the parts that locate things ON a shaft.

`bearings`/`bearings_more` support the shaft and `motion` drives it, but
nothing previously held a part in place along it. A shaft collar is the most
used part in any rotating assembly and had to be hand-modelled every time.

Anchor contract:
    shaft         : end_a (z=0), end_b (z=length), mid
    shaft_collar  : center (bore axis, mid-height), face_a, face_b, screw
    key           : center, end_a, end_b  (a parallel/DIN 6885 key blank)
    thrust_washer : center, face_a, face_b

Orientation: bore axis along +Z, part starting at z = 0.
"""

__library_version__ = "1.0"

import math

_STEEL = "#B0BEC5"
_BRASS = "#C9A227"

# Parallel key cross-sections per DIN 6885 sheet 1, by shaft diameter band:
# (over, up_to) -> (width, height). Standard stock sizes.
_KEY_STOCK = [
    (6, 8, 2.0, 2.0), (8, 10, 3.0, 3.0), (10, 12, 4.0, 4.0),
    (12, 17, 5.0, 5.0), (17, 22, 6.0, 6.0), (22, 30, 8.0, 7.0),
    (30, 38, 10.0, 8.0), (38, 44, 12.0, 8.0), (44, 50, 14.0, 9.0),
]

PARAM_CHOICES = {
    "*": {"quality": ["preview", "standard", "high", "ultra"]},
    "shaft_collar": {"style": ["solid", "split"]},
    "shaft": {"end": ["plain", "chamfered"]},
}


def _disc(cad, plane, r):
    c = cad.circle2d(cad.point2d(0.0, 0.0), r)
    return cad.region(loop=[c], inside=(0.0, 0.0))


def _plane_at(cad, z):
    return cad.create_sketch_plane(cad.point(0, 0, z), cad.point(1, 0, z), cad.point(0, 1, z))


def key_stock_for(diameter):
    """The DIN 6885 parallel-key section (width, height) for a shaft of
    `diameter` mm. Raises for sizes outside the tabulated bands rather than
    silently extrapolating — a made-up key section is worse than an error."""
    d = float(diameter)
    for lo, hi, w, h in _KEY_STOCK:
        if lo < d <= hi:
            return w, h
    raise ValueError(f"no tabulated key section for a {d:g} mm shaft "
                     f"(table covers {_KEY_STOCK[0][0]}-{_KEY_STOCK[-1][1]} mm)")


def shaft(cad, diameter=8.0, length=100.0, end="plain", quality=None):
    """A plain round shaft. `end="chamfered"` breaks both ends with a 45 deg
    lead-in (the usual stock finish, and it matters when it has to enter a
    bearing bore). Anchors: end_a (z=0), end_b, mid."""
    d = float(diameter)
    length = float(length)
    end = str(end).lower()
    r = d / 2.0
    ch = min(0.8, r * 0.15)

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        body = cad.extrude(p, _disc(cad, p, r), length, quality=quality, export=False)
        if end == "chamfered":
            # A chamfer is a cone subtracted at each end: revolve a right
            # triangle sitting outside the shaft's corner.
            for z, sign in ((0.0, 1.0), (length, -1.0)):
                cad.with_sketch("zx")
                a = cad.point2d(z, r + 0.01)
                b = cad.point2d(z + sign * ch, r + 0.01)
                c = cad.point2d(z, r - ch)
                ls = [cad.line2d(a, b), cad.line2d(b, c), cad.line2d(c, a)]
                axis = cad.line2d(cad.point2d(z - 2 * ch, 0.0),
                                  cad.point2d(z + 2 * ch, 0.0), construction=True)
                cone = cad.revolve("zx", cad.region(loop=ls, inside=(z + sign * ch * 0.3, r)),
                                   axis_line=axis, angle=360.0, quality=quality, export=False)
                body = cad.bool_difference(body, cone, quality=quality, export=False)
        cad.set_color(body, _STEEL, finish="metallic")
        cad.component_export(body)
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(0.0, 0.0, length))
        cad.component_export_point("mid", cad.point(0.0, 0.0, length / 2.0))

    return cad.parametric("shaft", build,
                          d=d, length=length, end=end, quality=quality or "std",
                          label=f"Shaft Ø{d:g}x{length:g}")


def shaft_collar(cad, bore=8.0, style="solid", quality=None):
    """A set-screw shaft collar: a ring clamped to a shaft to locate a part
    axially.

    style: "solid" — one piece with a radial set screw.
           "split" — a clamp collar, cut through one side, with the screw
                     across the split (holds without marking the shaft).

    OD and width follow the usual catalog proportions (OD ~ 2x bore, width
    ~ 0.5x bore). Anchors: center, face_a (z=0), face_b, screw (the set-screw
    axis, on the OD)."""
    bore = float(bore)
    style = str(style).lower()
    od = bore * 2.0
    width = max(bore * 0.5, 5.0)
    screw_d = max(3.0, round(bore * 0.4))
    r_o, r_i = od / 2.0, bore / 2.0

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        outer = cad.extrude(p, _disc(cad, p, r_o), width, quality=quality, export=False)
        inner = cad.extrude(p, _disc(cad, p, r_i), width + 2.0, quality=quality, export=False)
        inner = cad.move(inner, translate=(0, 0, -1.0), export=False)
        part = cad.bool_difference(outer, inner, quality=quality, export=False)
        # Radial set screw, drilled from +X inward.
        sp = cad.create_sketch_plane(cad.point(r_o + 1.0, 0, width / 2.0),
                                     cad.point(r_o + 1.0, 1, width / 2.0),
                                     cad.point(r_o + 1.0, 0, width / 2.0 + 1))
        cad.with_sketch(sp)
        sc = cad.circle2d(cad.point2d(0.0, 0.0), screw_d / 2.0)
        drill = cad.extrude(sp, cad.region(loop=[sc], inside=(0.0, 0.0)),
                            r_o + 2.0, quality=quality, export=False)
        part = cad.bool_difference(part, drill, quality=quality, export=False)
        if style == "split":
            # A narrow slit from the OD through to the bore, opposite nothing
            # in particular — aligned with the screw so the screw closes it.
            gap = max(1.2, bore * 0.12)
            gp = _plane_at(cad, -1.0)
            cad.with_sketch(gp)
            x0 = 0.0
            pts = [cad.point2d(x0, -gap / 2.0), cad.point2d(r_o + 1.0, -gap / 2.0),
                   cad.point2d(r_o + 1.0, gap / 2.0), cad.point2d(x0, gap / 2.0)]
            ls = [cad.line2d(pts[i], pts[(i + 1) % 4]) for i in range(4)]
            slit = cad.extrude(gp, cad.region(loop=ls, inside=(r_o / 2.0, 0.0)),
                               width + 2.0, quality=quality, export=False)
            part = cad.bool_difference(part, slit, quality=quality, export=False)
        cad.set_color(part, _STEEL, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("center", cad.point(0.0, 0.0, width / 2.0))
        cad.component_export_point("face_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("face_b", cad.point(0.0, 0.0, width))
        cad.component_export_point("screw", cad.point(r_o, 0.0, width / 2.0))

    return cad.parametric("shaft_collar", build,
                          bore=bore, style=style, quality=quality or "std",
                          label=f"Shaft collar Ø{bore:g} {style}")


def key(cad, shaft_d=8.0, length=20.0, quality=None):
    """A parallel key blank (DIN 6885 A, square ends), sized from the shaft
    diameter via `key_stock_for`. Lies along +Z with its width on X.

    Anchors: center, end_a (z=0), end_b."""
    shaft_d = float(shaft_d)
    length = float(length)
    w, h = key_stock_for(shaft_d)

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        x0, y0 = -w / 2.0, -h / 2.0
        pts = [cad.point2d(x0, y0), cad.point2d(x0 + w, y0),
               cad.point2d(x0 + w, y0 + h), cad.point2d(x0, y0 + h)]
        ls = [cad.line2d(pts[i], pts[(i + 1) % 4]) for i in range(4)]
        body = cad.extrude(p, cad.region(loop=ls, inside=(0.0, 0.0)), length,
                           quality=quality, export=False)
        cad.set_color(body, _STEEL, finish="metallic")
        cad.component_export(body)
        cad.component_export_point("center", cad.point(0.0, 0.0, length / 2.0))
        cad.component_export_point("end_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("end_b", cad.point(0.0, 0.0, length))

    return cad.parametric("key", build,
                          shaft=shaft_d, w=w, h=h, length=length,
                          quality=quality or "std",
                          label=f"Key {w:g}x{h:g}x{length:g}")


def thrust_washer(cad, bore=8.0, quality=None):
    """A plain thrust/shim washer for a shaft: a flat annulus, bronze-coloured
    to read as a bearing surface rather than a fastener washer.
    Anchors: center, face_a, face_b."""
    bore = float(bore)
    od = bore * 1.9
    t = max(1.0, bore * 0.12)
    r_o, r_i = od / 2.0, bore / 2.0

    def build():
        p = _plane_at(cad, 0.0)
        cad.with_sketch(p)
        outer = cad.extrude(p, _disc(cad, p, r_o), t, quality=quality, export=False)
        inner = cad.move(cad.extrude(p, _disc(cad, p, r_i), t + 2.0,
                                     quality=quality, export=False),
                         translate=(0, 0, -1.0), export=False)
        part = cad.bool_difference(outer, inner, quality=quality, export=False)
        cad.set_color(part, _BRASS, finish="metallic")
        cad.component_export(part)
        cad.component_export_point("center", cad.point(0.0, 0.0, t / 2.0))
        cad.component_export_point("face_a", cad.point(0.0, 0.0, 0.0))
        cad.component_export_point("face_b", cad.point(0.0, 0.0, t))

    return cad.parametric("thrust_washer", build,
                          bore=bore, quality=quality or "std",
                          label=f"Thrust washer Ø{bore:g}")
