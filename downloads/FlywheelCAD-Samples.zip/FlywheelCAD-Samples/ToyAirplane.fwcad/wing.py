"""
wing.py — a parametric toy-airplane wing component.

A flat, tapered, swept planform (chord along x, span along y) extruded thin.
`wing(...)` is a parametric component: calling it with different spans/chords
builds distinct components (memoized per parameter set), and it returns a handle
to instance. Exports the body plus root/tip quarter-chord mount points.
"""

from flywheelcad import *
cad = FlywheelCAD()


def wing(span=40, root_chord=16, tip_chord=8, sweep=5, thickness=2):
    def build():
        cad.with_sketch("xy")
        # Root section at y = 0, tip section swept back at y = span.
        le_root = cad.point2d(0, 0)
        te_root = cad.point2d(root_chord, 0)
        te_tip = cad.point2d(sweep + tip_chord, span)
        le_tip = cad.point2d(sweep, span)
        l1 = cad.line2d(le_root, te_root)
        l2 = cad.line2d(te_root, te_tip)
        l3 = cad.line2d(te_tip, le_tip)
        l4 = cad.line2d(le_tip, le_root)
        planform = cad.region(loop=[l1, l2, l3, l4], inside=(root_chord / 2.0, span / 3.0))
        body = cad.extrude("xy", planform, thickness, direction="symmetric")
        cad.component_export(body)
        # Mount the wing by its root quarter-chord; tip exposed for struts etc.
        cad.component_export_point("root", cad.point(root_chord * 0.25, 0, 0))
        cad.component_export_point("tip", cad.point(sweep + tip_chord * 0.25, span, 0))

    return cad.parametric("wing", build,
                          span=span, root_chord=root_chord,
                          tip_chord=tip_chord, sweep=sweep, thickness=thickness)


if __name__ == "__main__":
    wing()   # preview with defaults when this file is run/edited directly
