# flywheelcad-format: 1
"""
main.py — the toy-airplane assembly.

Imports the fuselage, wing and tail components, places them as instances, and
mates them to the fuselage's mount points so the parts follow the fuselage
parametrically. Open this file as the document; the component files live beside
it and are pulled in via `import`.
"""

from flywheelcad import *
cad = FlywheelCAD()

import fuselage              # defines component "fuselage"
import tail                 # defines component "tail"
from wing import wing       # parametric wing factory

# Fuselage at the origin.
fus = cad.instance("fuselage")

# One wing shape, instanced twice (right as-is, left mirrored across zx).
main_wing = wing(span=40, root_chord=16, tip_chord=8, sweep=5)
wing_r = cad.instance(main_wing)
wing_l = cad.instance(main_wing, mirror_plane="zx")

# Tail at the back.
tail_i = cad.instance("tail")

# Mate the parts to the fuselage mounts (closed-form coincident snaps — each
# part's mount point follows the fuselage station it's attached to).
cad.mate_coincident(wing_r, "root", fus.wing_mount)
cad.mate_coincident(wing_l, "root", fus.wing_mount)
cad.mate_coincident(tail_i, "mount", fus.tail_mount)
