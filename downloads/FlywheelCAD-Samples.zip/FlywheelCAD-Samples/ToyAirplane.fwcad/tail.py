"""
tail.py — a toy-airplane tail component (empennage).

Two bodies exported from one component: a horizontal stabilizer (flat, in the xy
plane) and a vertical fin (in the zx plane). A multi-body component — an instance
places the union of both. Exports a `mount` point at the front that mates to the
fuselage's tail mount.
"""

from flywheelcad import *
cad = FlywheelCAD()

with cad.component("tail"):
    # --- Horizontal stabilizer: flat plate spanning ±y ---
    cad.with_sketch("xy")
    h_chord = 10
    h_span = 14
    hp1 = cad.point2d(0, -h_span)
    hp2 = cad.point2d(h_chord, -h_span)
    hp3 = cad.point2d(h_chord, h_span)
    hp4 = cad.point2d(0, h_span)
    hl1 = cad.line2d(hp1, hp2)
    hl2 = cad.line2d(hp2, hp3)
    hl3 = cad.line2d(hp3, hp4)
    hl4 = cad.line2d(hp4, hp1)
    h_stab = cad.extrude("xy",
                         cad.region(loop=[hl1, hl2, hl3, hl4], inside=(h_chord / 2.0, 0)),
                         1.5, direction="symmetric")
    cad.component_export(h_stab)

    # --- Vertical fin: triangular plate rising in z ---
    cad.with_sketch("zx")
    fp1 = cad.point2d(0, 0)
    fp2 = cad.point2d(0, 16)
    fp3 = cad.point2d(12, 16)
    fl1 = cad.line2d(fp1, fp2)
    fl2 = cad.line2d(fp2, fp3)
    fl3 = cad.line2d(fp3, fp1)
    fin = cad.extrude("zx",
                      cad.region(loop=[fl1, fl2, fl3], inside=(2, 8)),
                      1.5, direction="symmetric")
    cad.component_export(fin)

    mount = cad.point(0, 0, 0)
    cad.component_export_point("mount", mount)
