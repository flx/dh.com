"""
stabilizer.py — parametric tail-surface leaf component.

A small flat tapered plate (chord along x, span along y) extruded thin. Used by
the empennage for both the horizontal stabilizers and the vertical fin (the fin
is just a stabilizer rotated 90° about the fore-aft axis). Exports the body plus
a `tip` point.
"""

from flywheelcad import *
cad = FlywheelCAD()


def stabilizer(span=14, chord=9, thickness=1.5):
    def build():
        cad.with_sketch("xy")
        p1 = cad.point2d(0, 0)
        p2 = cad.point2d(chord, 0)
        p3 = cad.point2d(chord * 0.8, span)
        p4 = cad.point2d(chord * 0.1, span)
        l1 = cad.line2d(p1, p2)
        l2 = cad.line2d(p2, p3)
        l3 = cad.line2d(p3, p4)
        l4 = cad.line2d(p4, p1)
        body = cad.extrude("xy",
                           cad.region(loop=[l1, l2, l3, l4], inside=(chord / 2.0, span / 3.0)),
                           thickness, direction="symmetric")
        cad.export(body)
        cad.export_point("tip", cad.point(chord * 0.4, span, 0))

    return cad.parametric("stab", build, span=span, chord=chord, thickness=thickness)


if __name__ == "__main__":
    stabilizer()
