"""
airplane.py — the nested toy-airplane assembly.

A two-level assembly. Leaf parts (fuselage, wing, engine, stabilizer) are nested
into sub-assemblies (powered_wing = wing + engine; empennage = three stabilizers),
which this top assembly places and mates to the fuselage:

    airplane
    ├── fuselage
    ├── powered_wing  (× 2, left mirrored)   →  wing panel + engine nacelle + spinner
    └── empennage                            →  h-stab ×2 + vertical fin

Each sub-assembly is opaque: only what it re-exports is visible here. Open this
file as the document; the component files live beside it.
"""

from flywheelcad import *
cad = FlywheelCAD()

import fuselage          # leaf component "fuselage"
import powered_wing      # sub-assembly "powered_wing" (defines engine + wing too)
import empennage         # sub-assembly "empennage" (defines stabilizer too)

# Fuselage at the origin.
fus = cad.instance("fuselage")

# A powered wing on each side (left mirrored across zx).
pw_r = cad.instance("powered_wing")
pw_l = cad.instance("powered_wing", mirror="zx")

# The tail.
emp = cad.instance("empennage")

# Mate the sub-assemblies to the fuselage mounts via their promoted anchors.
cad.mate_coincident(pw_r, "root", fus.wing_mount)
cad.mate_coincident(pw_l, "root", fus.wing_mount)
cad.mate_coincident(emp, "mount", fus.tail_mount)
